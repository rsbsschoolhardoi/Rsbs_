# Login Integration Module — Design Specification

## 1. Overview

| Property | Value |
|---|---|
| **Module Name** | Login Integration |
| **Location** | System Administration → Authentication → Login Integration |
| **Purpose** | Configure and manage Nexus (Inolas) OIDC/SSO authentication for the RSBS School Management System |
| **Access Level** | Admin only (permission: `manage_nexus_integration`; Master Login always has access) |
| **Target Screen** | Admin Panel settings page |

---

## 2. Page Architecture

### 2.1 High-level Layout

The page is a single-scrollable settings form organized into **collapsible cards**. Each card represents a logical configuration domain. The top card always shows the **Integration Status** so the admin can see at a glance whether Nexus is enabled and healthy.

```
+-------------------------------------------------------------+
|  Admin Header                                               |
+-------------------------------------------------------------+
|                                                             |
|  Page Title: Login Integration                              |
|  Subtitle: Manage Nexus (Inolas) OIDC / SSO authentication  |
|                                                             |
|  [Save Configuration]  [Discard Changes]  [Reset to Defaults]|
|                                                             |
+-------------------------------------------------------------+
|  CARD 1: Integration Status (expanded by default)           |
|  ---------------------------------------------------------  |
|  [Enable Nexus Integration] toggle        Status: Active   |
|  Health: 100%                               Last Test: ... |
|  [Test Connection]                                          |
+-------------------------------------------------------------+
|  CARD 2: Nexus Configuration                                |
|  ---------------------------------------------------------  |
|  Identity Provider URL     [________________________]       |
|  Authorization Endpoint    [________________________]       |
|  Token Endpoint            [________________________]       |
|  User Info Endpoint        [________________________]       |
|  Logout Endpoint           [________________________]       |
+-------------------------------------------------------------+
|  CARD 3: Application Credentials                            |
|  ---------------------------------------------------------  |
|  Client ID                 [________________] [Copy]        |
|  Client Secret             [***************] [Show/Hide]     |
|  Redirect URI              [________________] [Copy] [Edit] |
|  Post Logout Redirect URI  [________________] [Copy]       |
+-------------------------------------------------------------+
|  CARD 4: Login Options                                      |
|  ---------------------------------------------------------  |
|  [ ] Show "Continue with Inolas" button                    |
|  [x] Allow local login                                       |
|  [ ] Force Nexus login                                       |
|  [ ] Auto redirect to Nexus                                  |
|  [x] Allow Single Sign-On (SSO)                            |
+-------------------------------------------------------------+
|  CARD 5: Requested Permissions (Scopes)                     |
|  ---------------------------------------------------------  |
|  [Select All] [Deselect All]                                |
|  [x] Basic Profile   [x] Email   [ ] Username               |
|  [ ] Profile Photo   [x] Verified Identity   [ ] Org Memb. |
|  [ ] Offline Access                                         |
+-------------------------------------------------------------+
|  CARD 6: Security                                           |
|  ---------------------------------------------------------  |
|  [x] PKCE Enabled            [x] State Validation          |
|  ▶ Additional Security Options (collapsed)                  |
+-------------------------------------------------------------+
|  CARD 7: Audit & Advanced Actions                           |
|  ---------------------------------------------------------  |
|  [View Audit Log]  [Export Configuration]  [Import Config]  |
|  [Test Login Flow]  [Rollback to Previous Configuration]      |
+-------------------------------------------------------------+
```

### 2.2 Component Tree

```
LoginIntegrationPage
├── PageHeader
│   ├── Title + Icon
│   ├── Subtitle
│   └── ActionBar (Save, Discard, Reset)
├── UnsavedChangesPrompt (beforeunload guard)
├── IntegrationStatusCard
│   ├── EnableToggle
│   ├── StatusBadge
│   ├── HealthIndicator
│   ├── LastTestTimestamp
│   └── TestConnectionButton
├── CollapsibleCard (Nexus Configuration)
│   └── EndpointInputGroup
│       ├── IdentityProviderUrlInput
│       ├── AuthorizationEndpointInput
│       ├── TokenEndpointInput
│       ├── UserInfoEndpointInput
│       └── LogoutEndpointInput
├── CollapsibleCard (Application Credentials)
│   ├── ClientIdInput (copyable)
│   ├── ClientSecretInput (show/hide)
│   ├── RedirectUriInput (read-only / edit mode)
│   └── PostLogoutRedirectUriInput (copyable)
├── CollapsibleCard (Login Options)
│   ├── ShowContinueButtonToggle
│   ├── AllowLocalLoginToggle
│   ├── ForceNexusLoginToggle
│   ├── AutoRedirectToNexusToggle
│   └── AllowSsoToggle
├── CollapsibleCard (Requested Permissions)
│   ├── SelectAllButton
│   ├── DeselectAllButton
│   └── ScopeCheckboxList
│       └── ScopeCheckbox (with tooltip)
├── CollapsibleCard (Security)
│   ├── PkceToggle
│   ├── StateValidationToggle
│   └── AdditionalSecurityAccordion
├── AdvancedActionsCard
│   ├── ViewAuditLogButton
│   ├── ExportConfigurationButton
│   ├── ImportConfigurationButton (file input)
│   ├── TestLoginFlowButton
│   └── RollbackButton
└── Toasts / Notifications (success / error / connection result)
```

---

## 3. Wireframe Detail

### Desktop Layout (≥1024px)

```text
+----------------------------------------------------------------------------------+
|  [Logo]  RSBS School Management   [Search]   [Notifications]  [Profile]         |
+----+-----------------------------------------------------------------------------+
|    |                                                                             |
|    |  Login Integration                              [Save] [Discard] [Reset]    |
|    |  Manage Nexus (Inolas) OIDC / SSO authentication                           |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▼ Integration Status                                                │   |
|    |  │                                                                     │   |
|    |  │  Enable Nexus Integration  [●]                    Status: Connected │   |
|    |  │  Health: 100%                                      Last Test: ...   │   |
|    |  │                                              [ Test Connection ]    │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Nexus Configuration                                               │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Application Credentials                                           │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Login Options                                                     │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Requested Permissions                                             │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Security                                                          │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
|    |  ┌─────────────────────────────────────────────────────────────────────┐   |
|    |  │ ▶ Audit & Advanced Actions                                          │   |
|    |  └─────────────────────────────────────────────────────────────────────┘   |
|    |                                                                             |
+----+-----------------------------------------------------------------------------+
```

### Mobile Layout (<1023px)

On mobile, the sidebar becomes a hamburger drawer, and each card stacks vertically with the same content. The action bar moves under the subtitle and remains sticky at the top of the form while scrolling.

```text
+--------------------------------+
|  ≡  Login Integration   [Save] |
+--------------------------------+
|  Manage Nexus (Inolas)...      |
|                                |
|  ┌──────────────────────────┐  |
|  │ ▼ Integration Status   │  |
|  │ Enable Nexus ... [●]    │  |
|  │ Status: Connected       │  |
|  │ [Test Connection]     │  |
|  └──────────────────────────┘  |
|                                |
|  ┌──────────────────────────┐  |
|  │ ▶ Nexus Configuration  │  |
|  └──────────────────────────┘  |
|                                |
|  ┌──────────────────────────┐  |
|  │ ▶ Application Cred.    │  |
|  └──────────────────────────┘  |
|                                |
|  ... remaining cards ...       |
+--------------------------------+
```

---

## 4. Field Organization

### 4.1 Integration Status

| Field / Element | Type | Default | Behavior |
|---|---|---|---|
| Enable Nexus Integration | Toggle | OFF | Master switch. When OFF, status is grey/disabled and all Nexus login UI is hidden system-wide. |
| Status Indicator | Badge | Not Configured | Grey / Yellow / Green / Red based on enabled + last test result. |
| Health Metric | Progress + label | Unknown | 100% on success, 0% on failure, indeterminate if never tested. |
| Last Connection Test | Timestamp | Never tested | Updates after every Test Connection run. |
| Test Connection | Button | — | Validates endpoints and credentials, shows result, writes audit log. |

### 4.2 Nexus Configuration

| Field | Required | Validation |
|---|---|---|
| Identity Provider URL | Yes | Valid URL |
| Authorization Endpoint | Yes | Valid URL |
| Token Endpoint | Yes | Valid URL |
| User Info Endpoint | Yes | Valid URL |
| Logout Endpoint | No | Valid URL if provided |

### 4.3 Application Credentials

| Field | Type | Required | Notes |
|---|---|---|---|
| Client ID | Plain text | Yes | Copy-to-clipboard button. |
| Client Secret | Password (toggle show/hide) | Yes | Encrypted at rest. |
| Redirect URI | Read-only / editable | Yes | Defaults to the system's Nexus callback URL. Edit mode requires explicit save. |
| Post Logout Redirect URI | Plain text | Yes | Copy-to-clipboard. |

### 4.4 Login Options

| Option | Default | Conditional Logic |
|---|---|---|
| Show "Continue with Inolas" button | OFF | Disabled when Auto Redirect to Nexus is ON. |
| Allow local login | ON | Disabled when Force Nexus Login is ON. |
| Force Nexus Login | OFF | When ON, Allow local login is forced OFF and disabled. |
| Auto Redirect to Nexus | OFF | When ON, Continue with Inolas button is disabled (auto redirect supersedes it). |
| Allow SSO | ON | Can be disabled independently. |

### 4.5 Requested Permissions

| Permission | Scope Value | Default | Description on Hover |
|---|---|---|---|
| Basic Profile | openid, profile | Selected | Access to core identity claims such as sub and name. |
| Email Address | email | Selected | Access to the user's verified email address. |
| Username | preferred_username | Unselected | Access to the user's preferred username. |
| Profile Photo | picture | Unselected | Access to the user's profile image URL. |
| Verified Identity | verified | Unselected | Confirmation that the user's identity has been verified. |
| Organization Membership | groups, roles | Unselected | Access to group and role membership claims. |
| Offline Access | offline_access | Unselected | Allows refresh tokens for extended sessions. |

---

## 5. Interaction Flows

### 5.1 First Load

```
Admin opens System Administration → Authentication → Login Integration
         │
         ▼
Page fetches latest nexus_config record (or defaults)
         │
         ▼
Sections render with current values; toggle states reflect DB
         │
         ▼
Status badge resolves to Connected / Warning / Error / Not Configured
```

### 5.2 Edit & Save

```
Admin edits one or more fields
         │
         ▼
Page tracks dirty state (isDirty = true)
         │
         ▼
Admin clicks Save Configuration
         │
         ▼
Client validates all required fields and URL formats
         │
         ▼
On valid: API call saves config + creates audit log entry
         │
         ▼
Success toast shown; dirty state cleared
```

### 5.3 Test Connection

```
Admin clicks Test Connection
         │
         ▼
Client checks required fields are populated
         │
         ▼
Edge Function tests reachability of each endpoint
         │
         ▼
Result returned: success / failure with details
         │
         ▼
Status indicator, health metric, and last test timestamp updated
         │
         ▼
Audit log entry created; toast displayed
```

### 5.4 Conditional Toggle Logic

```
Force Nexus Login turned ON
         │
         ▼
Allow local login set to OFF and disabled (greyed)
         │
         ▼
Continue with Inolas button option hidden or disabled

Auto Redirect to Nexus turned ON
         │
         ▼
Show Continue with Inolas button set to OFF and disabled
```

### 5.5 Export / Import

```
Export Configuration
         │
         ▼
System serializes current form values (excluding Client Secret)
         │
         ▼
Browser downloads nexus-config-export.json

Import Configuration
         │
         ▼
Admin selects JSON file
         │
         ▼
System validates schema and value types
         │
         ▼
On valid: form fields populated; admin must click Save to persist
```

### 5.6 Rollback

```
Admin clicks Rollback to Previous Configuration
         │
         ▼
Confirmation dialog appears
         │
         ▼
System fetches prior configuration snapshot
         │
         ▼
Form repopulated with rolled-back values
         │
         ▼
Admin must click Save to persist the rollback
```

### 5.7 Unsaved Changes Guard

```
Admin has unsaved changes
         │
         ▼
Attempts to navigate away or close tab
         │
         ▼
Browser-native beforeunload prompt:
"You have unsaved changes. Are you sure you want to leave?"
```

---

## 6. Data Model Summary

### 6.1 `nexus_config` Table

| Column | Type | Default | Notes |
|---|---|---|---|
| id | serial / uuid | generated | Primary key |
| enabled | boolean | false | Master toggle |
| identity_provider_url | text | null | Required when enabled |
| authorization_endpoint | text | null | Required when enabled |
| token_endpoint | text | null | Required when enabled |
| user_info_endpoint | text | null | Required when enabled |
| logout_endpoint | text | null | Optional |
| client_id | text | null | Required when enabled |
| client_secret | text | null | Encrypted at rest |
| redirect_uri | text | null | System-generated default |
| post_logout_redirect_uri | text | null | Required when enabled |
| show_continue_button | boolean | false | Show "Continue with Inolas" |
| allow_local_login | boolean | true | Allow username/password login |
| force_nexus_login | boolean | false | Disable other methods |
| auto_redirect_to_nexus | boolean | false | Auto redirect on login load |
| allow_sso | boolean | true | Allow SSO |
| requested_scopes | JSON | ["openid","profile","email"] | Array of scopes |
| pkce_enabled | boolean | true | PKCE toggle |
| state_validation_enabled | boolean | true | State validation toggle |
| last_test_timestamp | timestamptz | null | Last connection test time |
| last_test_result | text | null | "success" or error message |
| created_at / updated_at | timestamptz | now() | Audit timestamps |
| created_by / updated_by | uuid | null | Foreign key to admin profiles |

### 6.2 `nexus_audit_log` Table

| Column | Type | Notes |
|---|---|---|
| id | serial / uuid | Primary key |
| timestamp | timestamptz | Event time |
| admin_user_id | uuid | Who made the change |
| admin_username | text | Cached username |
| action_type | text | e.g., CONFIG_SAVED, CONNECTION_TESTED, INTEGRATION_ENABLED, IMPORTED, ROLLED_BACK |
| changes_summary | JSON / text | Snapshot of changed fields or result payload |
| created_at | timestamptz | Record time |

---

## 7. Accessibility & Responsive Notes

- **Keyboard navigation:** All toggles, checkboxes, buttons, and inputs have visible focus rings.
- **Screen readers:** Status badge includes `aria-live="polite"` and a textual label alongside color.
- **Color coding:**
  - Green = Active / Healthy
  - Yellow = Warning / Untested
  - Red = Error / Disabled
  - Grey = Not configured
- **Touch targets:** Buttons and toggles are at least 44×44px.
- **Mobile:** Cards stack vertically; action bar becomes a sticky top bar; sidebar is replaced by a drawer.
- **Reduced motion:** Respect `prefers-reduced-motion` for status animations.

---

## 8. Security Notes

- Client Secret is **never returned to the frontend in plaintext** unless explicitly revealed by the Show toggle; ideally the backend returns a masked placeholder.
- Client Secret is encrypted at rest using a backend secret key.
- Import/Export JSON excludes the Client Secret.
- Audit log captures every configuration change and test action.
- Connection tests are executed server-side (Edge Function) to avoid exposing credentials to the browser console.
- Permission gate `manage_nexus_integration` enforced on all read/write APIs.

---

## 9. Implementation Roadmap (Suggested Order)

1. **Database:** Create `nexus_config` and `nexus_audit_log` tables with RLS policies.
2. **Backend:** Build an Edge Function for `test-nexus-connection` and `save-nexus-config`.
3. **API Layer:** Add typed API methods in `api.ts` for fetch/save, export, import, audit log.
4. **Route:** Register `/admin/login-integration` in `routes.tsx` and add sidebar item under System Administration → Authentication.
5. **Page:** Build `LoginIntegration.tsx` with collapsible sections, form state, and conditional toggles.
6. **Validation:** Add Zod schema for URL validation and required fields.
7. **UX Polish:** Add tooltips, beforeunload guard, toast notifications, and responsive adjustments.
8. **Audit & Rollback:** Implement change diffing, audit log panel, and rollback snapshot storage.

---

*This design document is intended to serve as the single source of truth for the visual layout, field organization, and interaction flow of the Login Integration module before implementation begins.*
