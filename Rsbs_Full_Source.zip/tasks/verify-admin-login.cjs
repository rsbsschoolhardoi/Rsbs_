const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://qknbvvkzrscikmqjrisd.supabase.co';
const ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFrbmJ2dmt6cnNjaWttcWpyaXNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQzNzQ3MTIsImV4cCI6MjA4OTk1MDcxMn0.TqvkR4TE5b9rVgC2n6wrfRYbZh2rizc4sjKud33gp5E';

const supabase = createClient(SUPABASE_URL, ANON_KEY);

(async () => {
  const email = 'rsbsmaster@miaoda.com';
  const password = process.argv[2];

  if (!password) {
    console.error('Usage: node verify-admin-login.cjs <password>');
    process.exit(1);
  }

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    console.error('Login failed:', error.message);
    process.exit(1);
  }

  console.log('Login successful. User ID:', data.user.id);

  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('username, role, is_master, login_access_enabled, account_status, email_verified')
    .eq('id', data.user.id)
    .maybeSingle();

  if (profileError) {
    console.error('Profile fetch failed:', profileError.message);
    process.exit(1);
  }

  console.log('Profile:', profile);
  process.exit(0);
})();
