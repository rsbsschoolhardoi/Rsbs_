import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { RefreshCw, LogIn, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { toast } from 'sonner';

export default function NexusLogin() {
  const navigate = useNavigate();
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [configLoading, setConfigLoading] = useState(true);
  const [nexusConfig, setNexusConfig] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadConfig = async () => {
      setConfigLoading(true);
      const { data, error } = await api.getNexusConfig();
      if (error) {
        setError('Failed to load Nexus configuration.');
      } else if (!data) {
        setError('Nexus configuration not found.');
      } else if (!data.enabled) {
        setError('Nexus Authentication is currently disabled.');
      } else if (!data.nexus_api_base_url || !data.application_id || !data.client_id || !data.client_secret) {
        setError('Nexus configuration is incomplete. Missing required fields.');
      } else {
        setNexusConfig(data);
      }
      setConfigLoading(false);
    };
    loadConfig();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please enter both username and password.');
      return;
    }
    
    if (!nexusConfig) {
      setError('Nexus configuration is not loaded.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: funcError } = await api.testNexusLogin({
        username,
        password,
        config: nexusConfig
      });

      if (funcError) {
        setError(funcError.message || 'Authentication failed (Network Error)');
      } else if (data && data.success) {
        toast.success('Authentication successful!');
        
        // Securely store the token (mocking the session integration)
        localStorage.setItem('nexus_access_token', data.token);
        localStorage.setItem('nexus_refresh_token', data.refreshToken);
        
        // Redirect to School Dashboard
        navigate('/admin');
      } else {
        setError(data?.message || 'Invalid Credentials');
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  if (configLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <RefreshCw className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-muted/30">
      <Card className="w-full max-w-md shadow-lg border-primary/20">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <ShieldAlert className="w-6 h-6 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">Nexus Authentication</CardTitle>
          <CardDescription>Sign in using your Inolas ID via Nexus Central</CardDescription>
        </CardHeader>
        
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Authentication Failed</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {!nexusConfig ? (
             <Alert variant="destructive" className="mb-6">
               <AlertCircle className="h-4 w-4" />
               <AlertTitle>Configuration Error</AlertTitle>
               <AlertDescription>Nexus Integration is not properly configured or disabled. Please check the admin settings.</AlertDescription>
             </Alert>
          ) : (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Inolas ID (Username)</Label>
                <Input 
                  id="username" 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)} 
                  placeholder="Enter your Inolas ID"
                  required
                  disabled={loading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input 
                  id="password" 
                  type="password" 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  placeholder="••••••••"
                  required
                  disabled={loading}
                />
              </div>
              
              <Button type="submit" className="w-full mt-6" disabled={loading}>
                {loading ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <LogIn className="w-4 h-4 mr-2" />
                )}
                Sign In with Nexus
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="text-center text-xs text-muted-foreground justify-center pt-2 pb-6">
          Testing Mode: No local account will be created.
        </CardFooter>
      </Card>
    </div>
  );
}