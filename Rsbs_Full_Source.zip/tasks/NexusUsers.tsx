import React, { useEffect, useMemo, useState } from 'react';
import { api } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import {
  Users,
  Server,
  RefreshCw,
  Save,
  Key,
  Copy,
  Check,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  ShieldAlert,
  LogIn
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { NexusConfigRecord } from '@/types';

interface NexusConfig {
  enabled: boolean;
  nexusApiBaseUrl: string;
  applicationId: string;
  clientId: string;
  clientSecret: string;
  allowLocalLogin: boolean;
  lastTestTimestamp: string | null;
  lastTestResult: 'success' | 'error' | null;
}

const defaultConfig: NexusConfig = {
  enabled: false,
  nexusApiBaseUrl: 'https://accounts.inolas.com',
  applicationId: '',
  clientId: '',
  clientSecret: '',
  allowLocalLogin: true,
  lastTestTimestamp: null,
  lastTestResult: null,
};

function isValidUrl(value: string): boolean {
  if (!value) return false;
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

function formatTimestamp(date: string | null): string {
  if (!date) return 'Never tested';
  return new Date(date).toLocaleString();
}

function fromRecord(record: NexusConfigRecord | null): NexusConfig {
  if (!record) return defaultConfig;
  return {
    enabled: record.enabled,
    nexusApiBaseUrl: record.nexus_api_base_url || 'https://accounts.inolas.com',
    applicationId: record.application_id || '',
    clientId: record.client_id || '',
    clientSecret: record.client_secret || '',
    allowLocalLogin: record.allow_local_login ?? true,
    lastTestTimestamp: record.last_test_timestamp,
    lastTestResult: (record.last_test_result as 'success' | 'error') || null,
  };
}

function toRecord(config: NexusConfig, existingId?: string): Partial<NexusConfigRecord> {
  const record: Partial<NexusConfigRecord> = {
    enabled: config.enabled,
    nexus_api_base_url: config.nexusApiBaseUrl || null,
    application_id: config.applicationId || null,
    client_id: config.clientId || null,
    client_secret: config.clientSecret || null,
    allow_local_login: config.allowLocalLogin,
    last_test_timestamp: config.lastTestTimestamp,
    last_test_result: config.lastTestResult,
  };
  if (existingId) record.id = existingId;
  return record;
}

export default function NexusUsers() {
  const { profile } = useAuth();
  const [config, setConfig] = useState<NexusConfig>(defaultConfig);
  const [savedConfig, setSavedConfig] = useState<NexusConfig>(defaultConfig);
  const [recordId, setRecordId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showSecret, setShowSecret] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testMessage, setTestMessage] = useState<string | null>(null);
  const [serverInfo, setServerInfo] = useState<{
    status: string;
    version: string;
    serverTime: string;
    latencyMs: number;
  } | null>(null);
  
  // Test Auth state
  const [authTestUsername, setAuthTestUsername] = useState('');
  const [authTestPassword, setAuthTestPassword] = useState('');
  const [authTesting, setAuthTesting] = useState(false);
  const [authTestResult, setAuthTestResult] = useState<{success: boolean, message: string} | null>(null);

  const isDirty = useMemo(() => {
    return JSON.stringify(config) !== JSON.stringify(savedConfig);
  }, [config, savedConfig]);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      const { data, error } = await api.getNexusConfig();
      if (!mounted) return;
      if (error) {
        toast.error('Failed to load Nexus configuration.');
      } else {
        const cfg = fromRecord(data);
        setConfig(cfg);
        setSavedConfig(cfg);
        setRecordId(data?.id || null);
      }
      setLoading(false);
    };
    load();
    return () => { mounted = false; };
  }, []);

  const updateField = <K extends keyof NexusConfig>(field: K, value: NexusConfig[K]) => {
    setConfig((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: '' }));
  };

  const validate = (): boolean => {
    const nextErrors: Record<string, string> = {};
    if (!config.nexusApiBaseUrl || !isValidUrl(config.nexusApiBaseUrl)) {
      nextErrors.nexusApiBaseUrl = 'A valid API Base URL is required.';
    }
    if (!config.applicationId) {
       nextErrors.applicationId = 'Application ID is required.';
    }
    if (!config.clientId) {
       nextErrors.clientId = 'Client ID is required.';
    }
    if (!config.clientSecret) {
       nextErrors.clientSecret = 'Client Secret is required.';
    }
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validate()) {
      toast.error('Please fix the validation errors before saving.');
      return;
    }
    const record = toRecord(config, recordId || undefined);
    const { data, error } = await api.upsertNexusConfig(record);
    if (error || !data) {
      toast.error('Failed to save configuration.');
      return;
    }
    const saved = fromRecord(data);
    setSavedConfig(saved);
    setConfig(saved);
    setRecordId(data.id);
    
    // Audit Logging
    if (profile?.id && profile?.username) {
      await api.createNexusAuditLog({
        timestamp: new Date().toISOString(),
        admin_user_id: profile.id,
        admin_username: profile.username,
        action_type: 'UPDATE_NEXUS_CONFIG',
        changes_summary: 'Updated Nexus Application Configuration credentials and settings.'
      });
    }

    toast.success('Configuration saved successfully.');
  };

  const handleDiscard = () => {
    if (!isDirty) return;
    if (window.confirm('Discard all unsaved changes?')) {
      setConfig({ ...savedConfig });
      setErrors({});
    }
  };

  const handleTestConnection = async () => {
    if (!config.nexusApiBaseUrl || !config.applicationId || !config.clientId || !config.clientSecret) {
      setTestMessage('Please complete all required Nexus configuration fields.');
      setConfig((prev) => ({ ...prev, lastTestResult: 'error' }));
      return;
    }
    if (!validate()) {
      setTestMessage('Configuration incomplete. Please fix validation errors.');
      setConfig((prev) => ({ ...prev, lastTestResult: 'error' }));
      return;
    }
    setTesting(true);
    setTestMessage(null);
    setServerInfo(null);
    
    let success = false;
    let message = '';
    let fetchedServerInfo = null;

    const payload = {
        nexus_api_base_url: config.nexusApiBaseUrl,
        application_id: config.applicationId,
        client_id: config.clientId,
        client_secret: config.clientSecret
    };
    
    // Connection retry logic with exponential backoff
    const maxRetries = 3;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const { data, error } = await api.testNexusIntegration(payload);
            if (error) {
                 success = false;
                 message = error.message || 'Network Error';
            } else if (data) {
                 success = data.success;
                 message = data.message || (success ? 'Connected' : 'Unknown Error');
                 if (success && data.serverInfo) {
                     fetchedServerInfo = data.serverInfo;
                 }
            } else {
                 success = false;
                 message = 'Network Error';
            }
            
            // Break loop if successful or if it's an authorization/validation error rather than network timeout
            if (success || (data && data.success === false && data.message !== 'Network Error: Nexus Server Unreachable (Timeout)')) {
                break;
            }
        } catch(err: any) {
             success = false;
             message = err.message || 'Network Error';
        }
        
        // Exponential backoff
        if (!success && attempt < maxRetries) {
             const delay = Math.pow(2, attempt) * 500; // 1s, 2s
             setTestMessage(`Attempt ${attempt} failed. Retrying in ${delay/1000}s...`);
             await new Promise(r => setTimeout(r, delay));
        }
    }

    if (success) {
      if (fetchedServerInfo) setServerInfo(fetchedServerInfo);
    }

    const now = new Date().toISOString();
    const result = success ? 'success' : 'error';
    const nextConfig: NexusConfig = { ...config, lastTestTimestamp: now, lastTestResult: result };
    setConfig(nextConfig);

    if (recordId) {
      const record = toRecord(nextConfig, recordId);
      await api.upsertNexusConfig({
        id: recordId,
        last_test_timestamp: record.last_test_timestamp,
        last_test_result: record.last_test_result,
      });
    }

    if (success) {
      setTestMessage(message);
      toast.success(message);
    } else {
      setTestMessage(message);
      toast.error(message);
    }
    setTesting(false);
  };

  const handleTestAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authTestUsername || !authTestPassword) return;
    setAuthTesting(true);
    setAuthTestResult(null);
    
    const payload = {
        username: authTestUsername,
        password: authTestPassword,
        config: config
    };
    
    const { data, error } = await api.testNexusLogin(payload);
    if (error) {
       setAuthTestResult({ success: false, message: error.message || 'Error testing auth' });
    } else {
       setAuthTestResult({ success: data?.success || false, message: data?.message || 'Unknown Error' });
    }
    setAuthTesting(false);
  };

  const getConnectionStatusInfo = () => {
    if (!config.enabled) return { label: 'Disabled', color: 'bg-muted-foreground', text: 'Nexus Integration Disabled' };
    if (!config.clientId || !config.clientSecret) return { label: 'Disconnected', color: 'bg-amber-500', text: 'Missing Credentials' };
    if (config.lastTestResult === 'success') return { label: 'Connected', color: 'bg-green-500', text: 'Active Connection' };
    if (config.lastTestResult === 'error') return { label: 'Invalid Credentials', color: 'bg-red-500', text: 'Authentication Failed' };
    return { label: 'Untested', color: 'bg-blue-500', text: 'Pending Verification' };
  };

  const statusInfo = getConnectionStatusInfo();

  if (loading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="flex items-center gap-2 text-muted-foreground">
          <RefreshCw className="w-5 h-5 animate-spin" />
          <span>Loading configuration...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-background text-foreground p-4 md:p-8">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight flex items-center gap-2">
              <Users className="w-7 h-7 text-primary" />
              Nexus Users
            </h1>
            <p className="text-muted-foreground mt-1">Manage the connection between School and Inolas Nexus Central Authentication Service.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={handleDiscard} disabled={!isDirty}>
              Discard Changes
            </Button>
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save Configuration
            </Button>
          </div>
        </div>

        {isDirty && (
          <Alert className="border-amber-200 bg-amber-50 text-amber-900">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <AlertTitle>Unsaved changes</AlertTitle>
            <AlertDescription>You have unsaved changes. Save or discard them before leaving.</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="connection">
          <TabsList className="mb-4">
            <TabsTrigger value="connection" className="flex items-center gap-2">
              <Server className="w-4 h-4" />
              Connection
            </TabsTrigger>
            <TabsTrigger value="test" className="flex items-center gap-2">
              <Key className="w-4 h-4" />
              Test Authentication
            </TabsTrigger>
          </TabsList>

          <TabsContent value="connection" className="space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <Server className="w-5 h-5 text-primary" />
                  Integration Status
                </CardTitle>
                <CardDescription>Current state of the Nexus connection.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-muted/30 border">
                  <div className="flex items-center gap-3">
                    <div className={cn('w-3 h-3 rounded-full', statusInfo.color)} aria-hidden="true" />
                    <div>
                      <p className="font-bold text-sm">{statusInfo.label}</p>
                      <p className="text-xs text-muted-foreground">{statusInfo.text} (Tested: {formatTimestamp(config.lastTestTimestamp)})</p>
                    </div>
                  </div>
                  <Button onClick={handleTestConnection} disabled={testing} variant="outline" className="w-full sm:w-auto">
                    {testing ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                    Test Connection
                  </Button>
                </div>

                {testMessage && (
                  <Alert variant={config.lastTestResult === 'success' ? 'default' : 'destructive'}>
                    {config.lastTestResult === 'success' ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                    <AlertTitle>{config.lastTestResult === 'success' ? 'Test Result' : 'Test failed'}</AlertTitle>
                    <AlertDescription>{testMessage}</AlertDescription>
                  </Alert>
                )}

                {config.lastTestResult === 'success' && serverInfo && (
                   <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-4 rounded-xl border bg-card text-card-foreground">
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium">Server Status</p>
                        <div className="flex items-center gap-1.5">
                           <div className={cn("w-2 h-2 rounded-full", serverInfo.status === 'Online' ? 'bg-green-500' : 'bg-amber-500')} />
                           <p className="text-sm font-semibold">{serverInfo.status}</p>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium">API Version</p>
                        <p className="text-sm font-semibold">{serverInfo.version}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium">Last Success</p>
                        <p className="text-sm font-semibold truncate" title={formatTimestamp(config.lastTestTimestamp)}>{formatTimestamp(config.lastTestTimestamp)}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium">Server Time</p>
                        <p className="text-sm font-semibold truncate" title={new Date(serverInfo.serverTime).toLocaleString()}>{new Date(serverInfo.serverTime).toLocaleTimeString()}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground font-medium">Latency</p>
                        <p className={cn("text-sm font-semibold", serverInfo.latencyMs > 500 ? "text-amber-500" : "text-green-500")}>
                          {serverInfo.latencyMs} ms
                        </p>
                      </div>
                   </div>
                )}

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-start justify-between gap-4 p-4 rounded-2xl border">
                    <div className="space-y-1 min-w-0">
                      <Label className="font-medium">Enable Nexus Authentication</Label>
                      <p className="text-xs text-muted-foreground">The School project will authenticate users through Nexus when enabled.</p>
                    </div>
                    <Switch checked={config.enabled} onCheckedChange={(v) => updateField('enabled', v)} />
                  </div>
                  <div className="flex items-start justify-between gap-4 p-4 rounded-2xl border">
                    <div className="space-y-1 min-w-0">
                      <Label className="font-medium">Allow Local Login</Label>
                      <p className="text-xs text-muted-foreground">Let users sign in using local database verification as a fallback.</p>
                    </div>
                    <Switch checked={config.allowLocalLogin} onCheckedChange={(v) => updateField('allowLocalLogin', v)} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Nexus Server</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="nexusApiBaseUrl" className="flex items-center gap-1">Nexus API Base URL<span className="text-destructive">*</span></Label>
                    <Input
                      id="nexusApiBaseUrl"
                      value={config.nexusApiBaseUrl}
                      onChange={(e) => updateField('nexusApiBaseUrl', e.target.value)}
                      placeholder="https://..."
                      className={cn(errors.nexusApiBaseUrl && 'border-destructive')}
                    />
                    {errors.nexusApiBaseUrl && <p className="text-xs text-destructive">{errors.nexusApiBaseUrl}</p>}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Application Identity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="applicationId" className="flex items-center gap-1">Application ID<span className="text-destructive">*</span></Label>
                    <Input 
                      id="applicationId" 
                      value={config.applicationId || ''} 
                      onChange={(e) => updateField('applicationId', e.target.value)}
                      placeholder="Enter Application ID"
                      className={cn(errors.applicationId && 'border-destructive')}
                    />
                    {errors.applicationId && <p className="text-xs text-destructive">{errors.applicationId}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="clientId" className="flex items-center gap-1">Client ID<span className="text-destructive">*</span></Label>
                    <div className="flex gap-2">
                      <Input 
                        id="clientId" 
                        value={config.clientId || ''} 
                        onChange={(e) => updateField('clientId', e.target.value)}
                        placeholder="Enter Client ID"
                        className={cn(errors.clientId && 'border-destructive')}
                      />
                      <CopyButton value={config.clientId || ''} />
                    </div>
                    {errors.clientId && <p className="text-xs text-destructive">{errors.clientId}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="clientSecret" className="flex items-center gap-1">Client Secret<span className="text-destructive">*</span></Label>
                    <div className="flex gap-2">
                      <Input
                        id="clientSecret"
                        type={showSecret ? 'text' : 'password'}
                        value={config.clientSecret || ''}
                        onChange={(e) => updateField('clientSecret', e.target.value)}
                        placeholder="Enter Client Secret"
                        className={cn(errors.clientSecret && 'border-destructive')}
                      />
                      <Button type="button" variant="outline" size="icon" onClick={() => setShowSecret((s) => !s)}>
                        {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                    {errors.clientSecret && <p className="text-xs text-destructive">{errors.clientSecret}</p>}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="test">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle>Test Authentication</CardTitle>
                <CardDescription>Verify user credentials against the live Nexus API. No local session will be created.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleTestAuth} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="testUsername">Inolas ID (Username)</Label>
                    <Input
                      id="testUsername"
                      value={authTestUsername}
                      onChange={(e) => setAuthTestUsername(e.target.value)}
                      placeholder="Enter username"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="testPassword">Password</Label>
                    <Input
                      id="testPassword"
                      type="password"
                      value={authTestPassword}
                      onChange={(e) => setAuthTestPassword(e.target.value)}
                      placeholder="Enter password"
                      required
                    />
                  </div>
                  
                  {authTestResult && (
                    <Alert variant={authTestResult.success ? 'default' : 'destructive'}>
                      {authTestResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                      <AlertTitle>{authTestResult.success ? 'Success' : 'Failed'}</AlertTitle>
                      <AlertDescription>{authTestResult.message}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full" disabled={authTesting || !authTestUsername || !authTestPassword}>
                    {authTesting ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <LogIn className="w-4 h-4 mr-2" />}
                    Test Login
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      type="button"
      variant="outline"
      size="icon"
      onClick={async () => {
        if (!value) return;
        await navigator.clipboard.writeText(value);
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      }}
      disabled={!value}
    >
      {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
    </Button>
  );
}