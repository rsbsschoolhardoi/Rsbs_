const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL = 'https://qknbvvkzrscikmqjrisd.supabase.co';
const SERVICE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFrbmJ2dmt6cnNjaWttcWpyaXNkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3NDM3NDcxMiwiZXhwIjoyMDg5OTUwNzEyfQ.hG-6IApHZj15LmiZuAicuYTUUGX_PExsvOmI9cieF40';

const admin = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

const FULL_MASTER_PERMISSIONS = [
  'dashboard', 'students', 'classes', 'fees', 'attendance', 'exams', 'notices',
  'gallery', 'school_home', 'push_notifications', 'queries', 'certificates',
  'parents', 'parent_portal_visibility', 'parent_help_desk', 'parent_feedback',
  'parent_appointments', 'admin_management', 'timetable', 'appointments',
  'admissions', 'allow_teacher_public_notices', 'teachers', 'certificate_download',
  'id_card_download', 'templates', 'system_logs', 'active_sessions', 'module_registry',
  'system_settings', 'secondary_login_id', 'public_home_redirect', 'pin_security',
  'otp_management'
];

function generateStrongPassword(length = 20) {
  const upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lower = 'abcdefghijklmnopqrstuvwxyz';
  const digits = '0123456789';
  const symbols = '!@#$%^&*-_=+?';
  const all = upper + lower + digits + symbols;
  let password = '';
  password += upper[Math.floor(Math.random() * upper.length)];
  password += lower[Math.floor(Math.random() * lower.length)];
  password += digits[Math.floor(Math.random() * digits.length)];
  password += symbols[Math.floor(Math.random() * symbols.length)];
  for (let i = 4; i < length; i++) {
    password += all[Math.floor(Math.random() * all.length)];
  }
  return password.split('').sort(() => 0.5 - Math.random()).join('');
}

(async () => {
  try {
    console.log('Fetching existing admin accounts...');
    const { data: existingAdmins, error: fetchError } = await admin
      .from('profiles')
      .select('id, username, email')
      .eq('role', 'admin');

    if (fetchError) throw fetchError;

    console.log(`Found ${existingAdmins?.length || 0} admin account(s) to remove.`);

    for (const a of existingAdmins || []) {
      console.log(`Deleting admin: ${a.username} (${a.email})`);
      const { error: delError } = await admin.auth.admin.deleteUser(a.id);
      if (delError) {
        console.error(`Failed to delete ${a.username}:`, delError.message);
      } else {
        console.log(`Deleted ${a.username}`);
      }
    }

    const username = 'rsbsmaster';
    const email = `${username}@miaoda.com`;
    const password = generateStrongPassword();

    console.log(`\nCreating fresh master admin: ${username}`);
    const { data: newUser, error: createError } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { username },
    });

    if (createError) throw createError;
    if (!newUser || !newUser.user) throw new Error('User creation returned empty');

    console.log(`Auth user created: ${newUser.user.id}`);

    const { error: profileError } = await admin
      .from('profiles')
      .update({
        role: 'admin',
        username,
        email,
        is_master: true,
        permissions: FULL_MASTER_PERMISSIONS,
        email_verified: true,
        login_access_enabled: true,
        account_status: 'active',
        require_email_verification: false,
        pin_setup_required: false,
      })
      .eq('id', newUser.user.id);

    if (profileError) throw profileError;

    console.log('\n=== FRESH SUPER ADMIN CREATED ===');
    console.log(`Username: ${username}`);
    console.log(`Password: ${password}`);
    console.log(`Email:    ${email}`);
    console.log('===================================\n');
  } catch (err) {
    console.error('Reset failed:', err.message || err);
    process.exit(1);
  }
})();
