import { supabase } from './supabase';
import { Student, Attendance, Exam, Notice, GalleryItem, Profile, SchoolInfo, Leadership, StudentQuery, TeacherQuery, Module, ModuleSetting, Appointment, Admission, StudentSession, SocialMediaLink, Teacher, ClassTeacherAssignment, AttendanceConfig, BrandingSettings, Certificate, Subject, TimetableSession, TimetableEntry, Parent, DocumentTemplate, AiSettings, AiStudentConfig, AiClassConfig, AiUsage, AiChatSession, AiChatMessage, EarlyLeave, ApiKey, ApiEndpoint, ApiLog, ModuleApi, ApiConfig, Chatbot, MasterFee, ExtraFee, FeePayment } from '@/types';

export const api = {
  // Timetable
  async getSubjects() {
    const { data, error } = await supabase
      .from('subjects')
      .select('*')
      .order('name');
    return { data: (data || []) as Subject[], error };
  },

  async createSubject(subject: Omit<Subject, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('subjects')
      .insert(subject)
      .select()
      .maybeSingle();
    return { data: data as Subject | null, error };
  },

  async updateSubject(id: string, updates: Partial<Subject>) {
    const { data, error } = await supabase
      .from('subjects')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Subject | null, error };
  },

  async deleteSubject(id: string) {
    const { error } = await supabase
      .from('subjects')
      .delete()
      .eq('id', id);
    return { error };
  },

  async getTimetableSessions() {
    const { data, error } = await supabase
      .from('timetable_sessions')
      .select('*')
      .order('created_at', { ascending: false });
    return { data: (data || []) as TimetableSession[], error };
  },

  async getActiveTimetableSession() {
    const { data, error } = await supabase
      .from('timetable_sessions')
      .select('*')
      .eq('is_active', true)
      .maybeSingle();
    return { data: data as TimetableSession | null, error };
  },

  async createTimetableSession(session: Omit<TimetableSession, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('timetable_sessions')
      .insert(session)
      .select()
      .maybeSingle();
    return { data: data as TimetableSession | null, error };
  },

  async updateTimetableSession(id: string, updates: Partial<TimetableSession>) {
    const { data, error } = await supabase
      .from('timetable_sessions')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as TimetableSession | null, error };
  },

  async deleteTimetableSession(id: string) {
    const { error } = await supabase
      .from('timetable_sessions')
      .delete()
      .eq('id', id);
    return { error };
  },

  async getTimetableEntries(sessionId: string, classId?: string, sectionId?: string, teacherId?: string) {
    let query = supabase
      .from('timetable_entries')
      .select('*, subjects(name), teachers(name), classes(name), sections(name)')
      .eq('session_id', sessionId);
    
    if (classId) query = query.eq('class_id', classId);
    if (sectionId) query = query.eq('section_id', sectionId);
    if (teacherId) query = query.eq('teacher_id', teacherId);

    const { data, error } = await query;
    
    const transformed = (data || []).map((entry: any) => ({
      ...entry,
      subject_name: entry.subjects?.name,
      teacher_name: entry.teachers?.name,
      class_name: entry.classes?.name,
      section_name: entry.sections?.name
    }));

    return { data: transformed as TimetableEntry[], error };
  },

  async createTimetableEntry(entry: Omit<TimetableEntry, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('timetable_entries')
      .insert(entry)
      .select()
      .maybeSingle();
    return { data: data as TimetableEntry | null, error };
  },

  async updateTimetableEntry(id: string, updates: Partial<TimetableEntry>) {
    const { data, error } = await supabase
      .from('timetable_entries')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as TimetableEntry | null, error };
  },

  async deleteTimetableEntry(id: string) {
    const { error } = await supabase
      .from('timetable_entries')
      .delete()
      .eq('id', id);
    return { error };
  },

  async bulkCopyTimetable(fromClassId: string, fromSectionId: string, toClassId: string, toSectionId: string, sessionId: string) {
    const { data: entries, error: fetchError } = await this.getTimetableEntries(sessionId, fromClassId, fromSectionId);
    if (fetchError) return { error: fetchError };

    const newEntries = entries.map(({ id, created_at, class_id, section_id, ...rest }) => ({
      ...rest,
      class_id: toClassId,
      section_id: toSectionId,
      session_id: sessionId
    }));

    const { data, error } = await supabase
      .from('timetable_entries')
      .upsert(newEntries, { onConflict: 'session_id,class_id,section_id,day_of_week,period_number' })
      .select();

    return { data, error };
  },

  async updateProfile(id: string, updates: Partial<Profile>) {
    const normalizedUpdates = { ...updates };
    if (normalizedUpdates.email) {
      normalizedUpdates.email = normalizedUpdates.email.trim().toLowerCase();
    }
    const { data, error } = await supabase
      .from('profiles')
      .update(normalizedUpdates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async updateProfileByEntityId(entityType: 'student' | 'teacher' | 'parent', entityId: string, updates: Partial<Profile>) {
    const column = entityType === 'student' ? 'student_id' : entityType === 'teacher' ? 'teacher_id' : 'parent_profile_id';
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq(column, entityId)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async getProfileByEntityId(entityType: 'student' | 'teacher' | 'parent', entityId: string) {
    const column = entityType === 'student' ? 'student_id' : entityType === 'teacher' ? 'teacher_id' : 'parent_profile_id';
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq(column, entityId)
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async getProfileByUsername(username: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', username)
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async getProfileByEmail(email: string) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('email', email.trim().toLowerCase())
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async updateGlobalModuleSetting(moduleId: string, updates: { is_enabled?: boolean, state?: 'enabled' | 'disabled' | 'deactivated' }) {
    const { data, error } = await supabase
      .from('module_settings')
      .update(updates)
      .eq('module_id', moduleId)
      .is('role', null)
      .is('user_id', null)
      .select()
      .maybeSingle();
    return { data: data as ModuleSetting | null, error };
  },

  async getGlobalModuleSetting(moduleId: string) {
    const { data, error } = await supabase
      .from('module_settings')
      .select('*')
      .eq('module_id', moduleId)
      .is('role', null)
      .is('user_id', null)
      .maybeSingle();
    return { data: data as ModuleSetting | null, error };
  },

  async getAdminProfiles() {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'admin')
      .order('username');
    return { data: (data || []) as Profile[], error };
  },

  async getAllNonAdminProfiles() {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .neq('role', 'admin')
      .order('username');
    return { data: (data || []) as Profile[], error };
  },

  // Teachers
  async getTeachers() {
    const { data, error } = await supabase
      .from('teachers')
      .select('*, class_teachers(*, classes(name), sections(name))')
      .order('name');
    
    // Transform to include helpful join data
    const transformed = (data || []).map((t: any) => ({
      ...t,
      class_assignments: t.class_teachers.map((ct: any) => ({
        ...ct,
        class_name: ct.classes?.name,
        section_name: ct.sections?.name
      }))
    }));

    return { data: transformed as Teacher[], error };
  },

  generateVerificationId() {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = 'RSBS0';
    for (let i = 0; i < 4; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  },

  async createTeacher(teacher: Omit<Teacher, 'id' | 'created_at' | 'updated_at' | 'verification_id'>) {
    const normalizedTeacher = { 
      ...teacher, 
      email: teacher.email.trim().toLowerCase(),
      verification_id: this.generateVerificationId()
    };
    const { data, error } = await supabase
      .from('teachers')
      .insert(normalizedTeacher)
      .select()
      .maybeSingle();
    return { data: data as Teacher | null, error };
  },

  async updateTeacher(id: string, updates: Partial<Teacher>) {
    const normalizedUpdates = { ...updates };
    if (normalizedUpdates.email) {
      normalizedUpdates.email = normalizedUpdates.email.trim().toLowerCase();
    }
    const { data, error } = await supabase
      .from('teachers')
      .update({ ...normalizedUpdates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Teacher | null, error };
  },

  async deleteTeacher(id: string) {
    const { error } = await supabase
      .from('teachers')
      .delete()
      .eq('id', id);
    return { error };
  },

  async assignTeacherToClass(assignment: Omit<ClassTeacherAssignment, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('class_teachers')
      .upsert(assignment, { onConflict: 'class_id,section_id' })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async removeTeacherAssignment(id: string) {
    const { error } = await supabase
      .from('class_teachers')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Parents
  async getParents() {
    const { data, error } = await supabase
      .from('parents')
      .select(`
        *,
        parent_student_links(
          relationship,
          student:students(*)
        )
      `)
      .order('created_at', { ascending: false });
    
    // Transform to include nested student data properly
    const formattedData = (data || []).map((parent: any) => ({
      ...parent,
      linked_students: parent.parent_student_links?.map((link: any) => ({
        ...link.student,
        relationship: link.relationship
      }))
    }));

    return { data: formattedData as Parent[], error };
  },

  async getParentById(id: string) {
    const { data, error } = await supabase
      .from('parents')
      .select(`
        *,
        parent_student_links(
          relationship,
          student:students(*)
        )
      `)
      .eq('id', id)
      .maybeSingle();

    if (data) {
      (data as any).linked_students = (data as any).parent_student_links?.map((link: any) => ({
        ...link.student,
        relationship: link.relationship
      }));
    }

    return { data: data as Parent | null, error };
  },

  async createParent(parent: Omit<Parent, 'id' | 'created_at' | 'updated_at' | 'linked_students' | 'parent_id'> & { parent_id?: string }) {
    // 1. Pre-Insertion ID Generation (Requirement 1 & 3)
    let finalParentId = parent.parent_id;
    if (!finalParentId || finalParentId.startsWith('PENDING') || finalParentId.startsWith('TEMP')) {
      const { data: lastRecord, error: fetchError } = await supabase
        .from('parents')
        .select('parent_id')
        .ilike('parent_id', 'RSBSP%')
        .order('parent_id', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (fetchError) throw new Error(`Failed to generate Parent Login ID: ${fetchError.message}`);

      let nextNumber = 1;
      if (lastRecord?.parent_id) {
        const match = lastRecord.parent_id.match(/RSBSP(\d{4})/);
        if (match) {
          nextNumber = parseInt(match[1], 10) + 1;
        }
      }

      if (nextNumber > 9999) {
        throw new Error('Parent Login ID sequence exhausted (maximum 9999 reached).');
      }

      finalParentId = `RSBSP${nextNumber.toString().padStart(4, '0')}`;
    }

    // 2. Pre-Save Validation (Requirement 4)
    if (!finalParentId) {
      throw new Error('Parent Login ID is required.');
    }

    if (!/^RSBSP\d{4}$/.test(finalParentId)) {
      throw new Error(`Invalid Parent Login ID format: ${finalParentId}. Must be RSBSP followed by 4 digits.`);
    }

    // Final Uniqueness Check (Requirement 3.Uniqueness Guarantee)
    const { data: existingId } = await supabase
      .from('parents')
      .select('id')
      .eq('parent_id', finalParentId)
      .maybeSingle();

    if (existingId) {
      throw new Error(`Parent Login ID ${finalParentId} already exists. Please try again.`);
    }

    const normalizedParent = { 
      ...parent,
      parent_id: finalParentId,
      email: parent.email.trim().toLowerCase() 
    };

    const { data, error } = await supabase
      .from('parents')
      .insert(normalizedParent)
      .select()
      .maybeSingle();

    return { data: data as Parent | null, error };
  },

  async updateParent(id: string, updates: Partial<Parent>) {
    const normalizedUpdates = { ...updates };
    if (normalizedUpdates.email) {
      normalizedUpdates.email = normalizedUpdates.email.trim().toLowerCase();
    }
    const { data, error } = await supabase
      .from('parents')
      .update({ ...normalizedUpdates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Parent | null, error };
  },

  async deleteParent(id: string) {
    const { error } = await supabase
      .from('parents')
      .delete()
      .eq('id', id);
    return { error };
  },

  async linkParentToStudent(parentId: string, studentId: string, relationship: string) {
    const { data, error } = await supabase
      .from('parent_student_links')
      .insert({ parent_id: parentId, student_id: studentId, relationship })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async unlinkParentFromStudent(parentId: string, studentId: string) {
    await supabase
      .from('parent_student_links')
      .delete()
      .eq('parent_id', parentId)
      .eq('student_id', studentId);
    return { error: null as any };
  },

  async getTeacherAssignments(teacherId: string) {
    const { data, error } = await supabase
      .from('class_teachers')
      .select('*, classes(name), sections(name)')
      .eq('teacher_id', teacherId);
    
    const transformed = (data || []).map((ct: any) => ({
      ...ct,
      class_name: ct.classes?.name,
      section_name: ct.sections?.name
    }));

    return { data: transformed as ClassTeacherAssignment[], error };
  },

  async getClassTeacherAssignments() {
    const { data, error } = await supabase
      .from('class_teachers')
      .select('*, classes(name), sections(name)');
    
    const transformed = (data || []).map((ct: any) => ({
      ...ct,
      class_name: ct.classes?.name,
      section_name: ct.sections?.name
    }));

    return { data: transformed as ClassTeacherAssignment[], error };
  },

  async deleteUser(username: string) {
    // Resolve the auth UUID from the profiles table first so the edge function
    // never needs to call auth.admin.listUsers() (which causes "Database error loading user").
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .select('id')
      .eq('username', username)
      .maybeSingle();

    if (profileError) return { data: null, error: profileError };

    // If profile not found, treat as already deleted — no auth record to remove.
    if (!profileData?.id) {
      return { data: { message: 'User not found, nothing to delete' }, error: null };
    }

    const { data, error } = await supabase.functions.invoke('delete-user', {
      body: { userId: profileData.id },
    });
    return { data, error };
  },

  // Students
  async getStudents() {
    const { data, error } = await supabase
      .from('students')
      .select(`
        *,
        parent_student_links(
          relationship,
          parent:parents(*)
        )
      `)
      .order('name');
    
    // Transform to include linked parents
    const formatted = (data || []).map((student: any) => ({
      ...student,
      linked_parents: student.parent_student_links?.map((link: any) => ({
        ...link.parent,
        relationship: link.relationship
      }))
    }));

    return { data: formatted as Student[], error };
  },

  async getStudentByLoginId(id: string) {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .or(`login_id.eq."${id}",verification_id.eq."${id}"`)
      .maybeSingle();
    return { data: data as Student | null, error };
  },

  async getStudentById(id: string) {
    const { data, error } = await supabase
      .from('students')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    return { data: data as Student | null, error };
  },

  async passOutStudents(studentIds: string[]) {
    const { data, error } = await supabase.functions.invoke('passout-students', {
      body: { studentIds }
    });
    return { data, error };
  },

  async createStudent(student: Omit<Student, 'id' | 'created_at' | 'verification_id'>) {
    const normalizedStudent = { 
      ...student, 
      email: student.email.trim().toLowerCase(),
      verification_id: this.generateVerificationId()
    };
    const { data, error } = await supabase
      .from('students')
      .insert(normalizedStudent)
      .select()
      .maybeSingle();
    return { data: data as Student | null, error };
  },

  async updateStudent(id: string, updates: Partial<Student>) {
    const normalizedUpdates = { ...updates };
    if (normalizedUpdates.email) {
      normalizedUpdates.email = normalizedUpdates.email.trim().toLowerCase();
    }
    const { data, error } = await supabase
      .from('students')
      .update(normalizedUpdates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Student | null, error };
  },

  async updateStudentVisibility(id: string, updates: { certificate_visible?: boolean, id_card_visible?: boolean }) {
    const { data, error } = await supabase
      .from('students')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data, error };
  },

  async deleteStudent(id: string) {
    const { error } = await supabase
      .from('students')
      .delete()
      .eq('id', id);
    return { error };
  },

  async checkLoginIdExists(loginId: string, excludeProfileId?: string) {
    let query = supabase
      .from('profiles')
      .select('id')
      .eq('username', loginId);
    
    if (excludeProfileId) {
      query = query.neq('id', excludeProfileId);
    }
    
    const { data } = await query.maybeSingle();
    return !!data;
  },

  validateLoginIdFormat(loginId: string, type: 'student' | 'teacher' | 'admin'): boolean {
    if (type === 'student') {
      return /^RSBS\d+$/.test(loginId);
    } else if (type === 'teacher') {
      return /^RSBST\d+$/.test(loginId);
    }
    return true; // Admin doesn't have a fixed prefix
  },

  // Attendance
  async getAttendance(studentId: string, startDate?: string, endDate?: string) {
    let query = supabase
      .from('attendance')
      .select('*, students(name)')
      .eq('student_id', studentId)
      .order('date', { ascending: false });

    if (startDate) query = query.gte('date', startDate);
    if (endDate) query = query.lte('date', endDate);

    const { data, error } = await query;
    return { data: (data || []) as (Attendance & { students: { name: string } })[], error };
  },

  async markAttendance(studentId: string, date: string, status: string, classId?: string, sectionId?: string, markedBy?: string) {
    const { data, error } = await supabase
      .from('attendance')
      .upsert({ student_id: studentId, date, status, class_id: classId, section_id: sectionId, marked_by: markedBy })
      .select()
      .maybeSingle();
    return { data: data as Attendance | null, error };
  },

  async getAttendanceByClassAndDate(classId: string, sectionId: string, date: string) {
    const { data, error } = await supabase
      .from('attendance')
      .select('*, students(name)')
      .eq('class_id', classId)
      .eq('section_id', sectionId)
      .eq('date', date);
    return { data: (data || []) as (Attendance & { students: { name: string } })[], error };
  },

  async markBulkAttendance(attendanceEntries: Omit<Attendance, 'id' | 'created_at'>[]) {
    const { data, error } = await supabase
      .from('attendance')
      .upsert(attendanceEntries, { onConflict: 'student_id,date' })
      .select();
    return { data: (data || []) as Attendance[], error };
  },

  async getAttendanceHistory(filters: { 
    classId?: string; 
    sectionId?: string; 
    studentId?: string; 
    startDate?: string; 
    endDate?: string; 
  }) {
    let query = supabase
      .from('attendance')
      .select('*, students(name, class, section)')
      .order('date', { ascending: false });

    if (filters.classId) query = query.eq('class_id', filters.classId);
    if (filters.sectionId) query = query.eq('section_id', filters.sectionId);
    if (filters.studentId) query = query.eq('student_id', filters.studentId);
    if (filters.startDate) query = query.gte('date', filters.startDate);
    if (filters.endDate) query = query.lte('date', filters.endDate);

    const { data, error } = await query;
    return { data: (data || []) as any[], error };
  },

  // Early Leaves
  async getEarlyLeavesByDate(date: string) {
    const { data, error } = await supabase
      .from('early_leaves')
      .select('*, students(name, class, section)')
      .eq('date', date);
    return { data: (data || []) as (EarlyLeave & { students: { name: string, class: string, section: string } })[], error };
  },

  async createEarlyLeave(entry: Omit<EarlyLeave, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('early_leaves')
      .insert(entry)
      .select()
      .maybeSingle();
    return { data: data as EarlyLeave | null, error };
  },

  async updateEarlyLeave(id: string, updates: Partial<EarlyLeave>) {
    const { data, error } = await supabase
      .from('early_leaves')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as EarlyLeave | null, error };
  },

  async deleteEarlyLeave(id: string) {
    const { error } = await supabase
      .from('early_leaves')
      .delete()
      .eq('id', id);
    return { error };
  },

  async getEarlyLeavesHistory(filters: { 
    classId?: string; 
    sectionId?: string; 
    studentId?: string; 
    startDate?: string; 
    endDate?: string; 
  }) {
    let query = supabase
      .from('early_leaves')
      .select('*, students(name, class, section, class_id, section_id)')
      .order('date', { ascending: false });

    if (filters.classId) query = query.eq('students.class_id', filters.classId);
    if (filters.sectionId) query = query.eq('students.section_id', filters.sectionId);
    if (filters.studentId) query = query.eq('student_id', filters.studentId);
    if (filters.startDate) query = query.gte('date', filters.startDate);
    if (filters.endDate) query = query.lte('date', filters.endDate);

    const { data, error } = await query;
    return { data: (data || []) as any[], error };
  },



  // Exams
  async getExams() {
    const { data, error } = await supabase
      .from('exams')
      .select('*')
      .order('date', { ascending: true });
    return { data: (data || []) as Exam[], error };
  },

  async createExam(exam: Omit<Exam, 'id'>) {
    const { data, error } = await supabase
      .from('exams')
      .insert(exam)
      .select()
      .maybeSingle();
    return { data: data as Exam | null, error };
  },

  async deleteExam(id: string) {
    const { error } = await supabase
      .from('exams')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Notices
  async getNotices() {
    const { data, error } = await supabase
      .from('notices')
      .select('*')
      .order('created_at', { ascending: false });
    return { data: (data || []) as Notice[], error };
  },

  async getPublicNotices() {
    const { data, error } = await supabase
      .from('notices')
      .select('*')
      .eq('target_type', 'all')
      .order('created_at', { ascending: false });
    return { data: (data || []) as Notice[], error };
  },

  // Classes & Sections
  async getClasses() {
    const { data, error } = await supabase
      .from('classes')
      .select('*, sections(*)')
      .order('name');
    return { data: (data || []) as any[], error };
  },

  async createClass(name: string) {
    const { data, error } = await supabase
      .from('classes')
      .insert({ name })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async updateClass(id: string, name: string) {
    const { data, error } = await supabase
      .from('classes')
      .update({ name })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data, error };
  },

  async deleteClass(id: string) {
    const { error } = await supabase
      .from('classes')
      .delete()
      .eq('id', id);
    return { error };
  },

  async createSection(class_id: string, name: string) {
    const { data, error } = await supabase
      .from('sections')
      .insert({ class_id, name })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async updateSection(id: string, name: string) {
    const { data, error } = await supabase
      .from('sections')
      .update({ name })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data, error };
  },

  async deleteSection(id: string) {
    const { error } = await supabase
      .from('sections')
      .delete()
      .eq('id', id);
    return { error };
  },

  async bulkPromote(studentIds: string[], class_id: string, section_id: string, className: string, sectionName: string) {
    const { error } = await supabase
      .from('students')
      .update({ class_id, section_id, class: className, section: sectionName })
      .in('id', studentIds);
    return { error };
  },

  async createNotice(notice: any) {
    const { data, error } = await supabase
      .from('notices')
      .insert(notice)
      .select()
      .maybeSingle();
    return { data: data as Notice | null, error };
  },

  async deleteNotice(id: string) {
    const { error } = await supabase
      .from('notices')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Gallery
  async getGallery() {
    const { data, error } = await supabase
      .from('gallery')
      .select('*')
      .order('event_date', { ascending: false });
    return { data: (data || []) as GalleryItem[], error };
  },

  async createGalleryItem(item: Omit<GalleryItem, 'id'>) {
    const { data, error } = await supabase
      .from('gallery')
      .insert(item)
      .select()
      .maybeSingle();
    return { data: data as GalleryItem | null, error };
  },

  async deleteGalleryItem(id: string) {
    const { error } = await supabase
      .from('gallery')
      .delete()
      .eq('id', id);
    return { error };
  },

  // School Info
  async getSchoolInfo() {
    const { data, error } = await supabase
      .from('school_info')
      .select('*')
      .eq('is_visible', true)
      .order('order_index', { ascending: true });
    return { data: (data || []) as SchoolInfo[], error };
  },

  async getAllSchoolInfo() {
    const { data, error } = await supabase
      .from('school_info')
      .select('*')
      .order('order_index', { ascending: true });
    return { data: (data || []) as SchoolInfo[], error };
  },

  async updateSchoolInfo(id: string, updates: Partial<SchoolInfo>) {
    const { data, error } = await supabase
      .from('school_info')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as SchoolInfo | null, error };
  },

  // Leadership & Legacy
  async getLeadership() {
    const { data, error } = await supabase
      .from('leadership')
      .select('*')
      .order('order_index', { ascending: true });
    return { data: (data || []) as Leadership[], error };
  },

  async createLeadership(item: Omit<Leadership, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('leadership')
      .insert(item)
      .select()
      .maybeSingle();
    return { data: data as Leadership | null, error };
  },

  async updateLeadership(id: string, updates: Partial<Leadership>) {
    const { data, error } = await supabase
      .from('leadership')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Leadership | null, error };
  },

  async deleteLeadership(id: string) {
    const { error } = await supabase
      .from('leadership')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Admin Management
  async createAdminAccount(username: string, password: string, is_admin: boolean = true) {
    const { data, error } = await supabase.functions.invoke('create-admin', {
      body: { username, password, is_admin }
    });
    return { data, error };
  },

  async resendVerificationLink(userId: string) {
    const { data, error } = await supabase.functions.invoke('resend-verification-link', {
      body: { userId }
    });
    return { data, error };
  },

  async resendVerificationByEmail(email: string) {
    const { data, error } = await supabase.functions.invoke('resend-verification-by-email', {
      body: { email }
    });
    return { data, error };
  },

  async verifyAdminToken(token: string) {
    const { data, error } = await supabase.functions.invoke('verify-admin-token', {
      body: { token }
    });
    return { data, error };
  },

  async updateAdminProfile(id: string, updates: Partial<Profile>) {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  // Student Targeted Content
  async getStudentNotices(student: Student) {
    const { data, error } = await supabase
      .from('notices')
      .select('*')
      .or(`target_type.eq.all,and(target_type.eq.class,target_id.eq.${student.class_id}),and(target_type.eq.section,target_id.eq.${student.section_id}),and(target_type.eq.student,target_id.eq.${student.id})`)
      .order('created_at', { ascending: false });
    return { data: (data || []) as Notice[], error };
  },

  // Branding Settings
  async getBrandingSettings() {
    const { data, error } = await supabase
      .from('branding_settings')
      .select('*')
      .limit(1)
      .maybeSingle();
    return { data: data as BrandingSettings | null, error };
  },

  async updateBrandingSettings(id: string, updates: Partial<BrandingSettings>) {
    const { data, error } = await supabase
      .from('branding_settings')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as BrandingSettings | null, error };
  },

  // Certificates
  async getCertificates(type?: 'certificate' | 'id_card') {
    let query = supabase.from('certificates').select('*');
    if (type) query = query.eq('document_type', type);
    const { data, error } = await query;
    return { data: (data || []) as Certificate[], error };
  },

  async getCertificateByStudent(studentId: string, type: 'certificate' | 'id_card' = 'certificate') {
    const { data, error } = await supabase
      .from('certificates')
      .select('*')
      .eq('student_id', studentId)
      .eq('document_type', type)
      .maybeSingle();
    return { data: data as Certificate | null, error };
  },

  async generateCertificate(studentId: string, type: 'certificate' | 'id_card' = 'certificate') {
    const { data, error } = await supabase.functions.invoke('generate-certificate', {
      body: { studentId, type }
    });
    return { data, error };
  },


  async getStudentExams(student: Student) {
    const { data, error } = await supabase
      .from('exams')
      .select('*')
      .or(`target_type.eq.all,and(target_type.eq.class,target_id.eq.${student.class_id}),and(target_type.eq.section,target_id.eq.${student.section_id}),and(target_type.eq.student,target_id.eq.${student.id})`)
      .order('date', { ascending: true });
    return { data: (data || []) as Exam[], error };
  },


  /**
   * Public student verification - ONLY use verification_id for security.
   * Search by login_id is strictly prohibited in this context to separate public identifiers from private login credentials.
   * We only select necessary public fields to avoid leaking private data.
   */
  async verifyStudent(id: string) {
    const { data, error } = await supabase
      .from('public_student_verification' as any)
      .select('name, verification_id, session_info, class, section, profile_picture_url, status, school_name, school_logo_url')
      .eq('verification_id', id)
      .maybeSingle();
    return { data, error };
  },

  // Student Queries
  async getQueries(studentId?: string, targetTeacherId?: string) {
    let query = supabase.from('student_queries').select('*').order('created_at', { ascending: false });
    if (studentId) {
      // For student: visible if public OR their own
      query = query.or(`is_public.eq.true,student_id.eq.${studentId}`);
    } else if (targetTeacherId) {
      // For teacher: visible if targeted to them
      query = query.eq('target_teacher_id', targetTeacherId);
    }
    const { data, error } = await query;
    return { data: (data || []) as StudentQuery[], error };
  },

  async createQuery(studentId: string, studentName: string, content: string, is_public: boolean, target_type: 'admin' | 'teacher' = 'admin', target_teacher_id?: string) {
    const { data, error } = await supabase
      .from('student_queries')
      .insert({ student_id: studentId, student_name: studentName, content, is_public, target_type, target_teacher_id })
      .select()
      .maybeSingle();
    return { data: data as StudentQuery | null, error };
  },

  async replyToQuery(id: string, replyContent: string, is_public?: boolean) {
    const updates: any = {
      reply_content: replyContent,
      replied_at: new Date().toISOString(),
      status: 'replied',
    };
    if (is_public !== undefined) updates.is_public = is_public;
    
    const { data, error } = await supabase
      .from('student_queries')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as StudentQuery | null, error };
  },

  async togglePinQuery(id: string, isPinned: boolean) {
    const { data, error } = await supabase
      .from('student_queries')
      .update({ is_pinned: isPinned })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as StudentQuery | null, error };
  },

  async deleteQuery(id: string) {
    const { error } = await supabase
      .from('student_queries')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Teacher Queries
  async getTeacherQueries(teacherId?: string) {
    let query = supabase.from('teacher_queries').select('*').order('created_at', { ascending: false });
    if (teacherId) {
      query = query.or(`is_public.eq.true,teacher_id.eq.${teacherId}`);
    }
    const { data, error } = await query;
    return { data: (data || []) as TeacherQuery[], error };
  },

  async createTeacherQuery(teacherId: string, teacherName: string, content: string, is_public: boolean) {
    const { data, error } = await supabase
      .from('teacher_queries')
      .insert({ teacher_id: teacherId, teacher_name: teacherName, content, is_public })
      .select()
      .maybeSingle();
    return { data: data as TeacherQuery | null, error };
  },

  async replyToTeacherQuery(id: string, reply_content: string) {
    const { data, error } = await supabase
      .from('teacher_queries')
      .update({
        status: 'replied',
        reply_content,
        replied_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as TeacherQuery | null, error };
  },

  // Module Settings
  async getModules() {
    const { data, error } = await supabase
      .from('modules')
      .select('*')
      .order('label');
    return { data: (data || []) as Module[], error };
  },

  async getModuleSettings() {
    const { data, error } = await supabase
      .from('module_settings')
      .select('*')
      .order('module_id');
    return { data: (data || []) as ModuleSetting[], error };
  },

  // AI Management
  async getAiSettings() {
    const { data, error } = await supabase
      .from('ai_settings')
      .select('*')
      .limit(1)
      .maybeSingle();
    return { data: data as AiSettings | null, error };
  },

  async updateAiSettings(id: string, updates: Partial<AiSettings>) {
    const { data, error } = await supabase
      .from('ai_settings')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as AiSettings | null, error };
  },

  async getAiStudentConfigs() {
    const { data, error } = await supabase
      .from('ai_student_configs')
      .select('*, students(name, class, section)')
      .order('updated_at', { ascending: false });
    
    const transformed = (data || []).map((c: any) => ({
      ...c,
      student_name: c.students?.name,
      class_name: c.students?.class,
      section_name: c.students?.section
    }));

    return { data: transformed as AiStudentConfig[], error };
  },

  async upsertAiStudentConfig(config: any) {
    const { data, error } = await supabase
      .from('ai_student_configs')
      .upsert(config, { onConflict: 'student_id' })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async getAiClassConfigs() {
    const { data, error } = await supabase
      .from('ai_class_configs')
      .select('*, classes(name)')
      .order('updated_at', { ascending: false });
    
    const transformed = (data || []).map((c: any) => ({
      ...c,
      class_name: c.classes?.name
    }));

    return { data: transformed as AiClassConfig[], error };
  },

  async upsertAiClassConfig(config: any) {
    const { data, error } = await supabase
      .from('ai_class_configs')
      .upsert(config, { onConflict: 'class_id' })
      .select()
      .maybeSingle();
    return { data, error };
  },

  async getAiUsage(studentId?: string, date?: string) {
    let query = supabase
      .from('ai_usage')
      .select('*, students(name)');
    
    if (studentId) query = query.eq('student_id', studentId);
    if (date) query = query.eq('usage_date', date);

    const { data, error } = await query.order('usage_date', { ascending: false });
    
    const transformed = (data || []).map((u: any) => ({
      ...u,
      student_name: u.students?.name
    }));

    return { data: transformed as AiUsage[], error };
  },

  async incrementAiUsage(studentId: string) {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase.rpc('increment_ai_usage', { 
      p_student_id: studentId,
      p_date: today
    });
    return { data, error };
  },

  async getAiConfigForStudent(studentId: string, classId: string) {
    const { data: globalSettings } = await this.getAiSettings();
    const { data: studentConfig } = await supabase
      .from('ai_student_configs')
      .select('*')
      .eq('student_id', studentId)
      .maybeSingle();
    
    const { data: classConfig } = await supabase
      .from('ai_class_configs')
      .select('*')
      .eq('class_id', classId)
      .maybeSingle();

    const today = new Date().toISOString().split('T')[0];
    const { data: usage } = await supabase
      .from('ai_usage')
      .select('*')
      .eq('student_id', studentId)
      .eq('usage_date', today)
      .maybeSingle();

    return {
      globalSettings,
      usage
    };
  },

  // AI Chat Sessions
  async getAiChatSessions(studentId: string) {
    const { data, error } = await supabase
      .from('ai_chat_sessions')
      .select('*')
      .eq('student_id', studentId)
      .order('updated_at', { ascending: false });
    return { data: (data || []) as AiChatSession[], error };
  },

  async createAiChatSession(studentId: string, title: string = 'New Chat') {
    const { data, error } = await supabase
      .from('ai_chat_sessions')
      .insert({ student_id: studentId, title })
      .select()
      .maybeSingle();
    return { data: data as AiChatSession | null, error };
  },

  async updateAiChatSession(id: string, updates: Partial<AiChatSession>) {
    const { data, error } = await supabase
      .from('ai_chat_sessions')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as AiChatSession | null, error };
  },

  async deleteAiChatSession(id: string) {
    const { error } = await supabase
      .from('ai_chat_sessions')
      .delete()
      .eq('id', id);
    return { error };
  },

  async getAiChatMessages(sessionId: string) {
    const { data, error } = await supabase
      .from('ai_chat_messages')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: true });
    return { data: (data || []) as AiChatMessage[], error };
  },

  async addAiChatMessage(message: Omit<AiChatMessage, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('ai_chat_messages')
      .insert(message)
      .select()
      .maybeSingle();
    
    // Trigger session updated_at refresh
    if (!error && message.session_id) {
      await this.updateAiChatSession(message.session_id, { updated_at: new Date().toISOString() });
    }

    return { data: data as AiChatMessage | null, error };
  },

  async isGlobalModuleEnabled(moduleId: string) {
    const { data, error } = await supabase
      .from('module_settings')
      .select('is_enabled')
      .eq('module_id', moduleId)
      .is('role', null)
      .is('user_id', null)
      .maybeSingle();
    
    if (error || !data) return false;
    return data.is_enabled;
  },

  async togglePinTeacherQuery(id: string, isPinned: boolean) {
    const { data, error } = await supabase
      .from('teacher_queries')
      .update({ is_pinned: isPinned })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as TeacherQuery | null, error };
  },

  async deleteTeacherQuery(id: string) {
    const { error } = await supabase
      .from('teacher_queries')
      .delete()
      .eq('id', id);
    return { error };
  },

  async updateModuleSetting(id: string, isEnabled: boolean, state: string = 'enabled', role?: string, userId?: string) {
    const { data, error } = await supabase
      .from('module_settings')
      .update({ is_enabled: isEnabled, state, role, user_id: userId, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as ModuleSetting | null, error };
  },

  async upsertModuleSetting(moduleId: string, isEnabled: boolean) {
    const { data: existing } = await supabase
      .from('module_settings')
      .select('id')
      .eq('module_id', moduleId)
      .is('role', null)
      .is('user_id', null)
      .maybeSingle();

    if (existing) {
      return this.updateModuleSetting(existing.id, isEnabled);
    } else {
      const { data, error } = await supabase
        .from('module_settings')
        .insert({
          module_id: moduleId,
          is_enabled: isEnabled,
          state: 'enabled'
        })
        .select()
        .maybeSingle();
      return { data: data as ModuleSetting | null, error };
    }
  },

  // Student Sessions
  async createStudentSession(session: Omit<StudentSession, 'id' | 'created_at' | 'login_time' | 'last_activity' | 'status'>) {
    const { data, error } = await supabase
      .from('student_sessions')
      .insert(session)
      .select()
      .maybeSingle();
    return { data: data as StudentSession | null, error };
  },

  async updateStudentSessionActivity(id: string) {
    const { error } = await supabase
      .from('student_sessions')
      .update({ last_activity: new Date().toISOString() })
      .eq('id', id);
    return { error };
  },

  async getActiveSessions() {
    const { data, error } = await supabase
      .from('student_sessions')
      .select('*')
      .eq('status', 'active')
      .order('login_time', { ascending: false });
    return { data: (data || []) as StudentSession[], error };
  },

  // Document Templates
  async getDocumentTemplates() {
    const { data, error } = await supabase
      .from('document_templates')
      .select('*')
      .order('created_at', { ascending: false });
    return { data: data as DocumentTemplate[] | null, error };
  },

  async getDocumentTemplateById(id: string) {
    const { data, error } = await supabase
      .from('document_templates')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    return { data: data as DocumentTemplate | null, error };
  },

  async createDocumentTemplate(template: Omit<DocumentTemplate, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('document_templates')
      .insert(template)
      .select()
      .maybeSingle();
    return { data: data as DocumentTemplate | null, error };
  },

  async updateDocumentTemplate(id: string, template: Partial<Omit<DocumentTemplate, 'id' | 'created_at' | 'updated_at'>>) {
    const { data, error } = await supabase
      .from('document_templates')
      .update({ ...template, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as DocumentTemplate | null, error };
  },

  /** Check if a template name already exists (excluding a known id for edit flows) */
  async checkDocumentTemplateName(name: string, excludeId?: string) {
    let query = supabase
      .from('document_templates')
      .select('id, name')
      .eq('name', name);
    if (excludeId) query = query.neq('id', excludeId);
    const { data, error } = await query;
    return { exists: (data?.length ?? 0) > 0, data, error };
  },

  async deleteDocumentTemplate(id: string) {
    const { error } = await supabase
      .from('document_templates')
      .delete()
      .eq('id', id);
    return { error };
  },

  // API Configurations
  async getApiConfigs() {
    const { data, error } = await supabase
      .from('api_configs')
      .select('*')
      .order('created_at', { ascending: false });
    
    const transformed = (data || []).map((config: any) => ({
      ...config,
      responseField: config.response_field,
      apiKey: config.api_key
    }));

    return { data: transformed as ApiConfig[], error };
  },

  async createApiConfig(config: Omit<ApiConfig, 'id' | 'created_at' | 'last_applied' | 'is_active'>) {
    const { data, error } = await supabase
      .from('api_configs')
      .insert({
        name: config.name,
        endpoint: config.endpoint,
        method: config.method,
        headers: config.headers,
        variables: config.variables,
        bodies: config.bodies,
        response_field: config.responseField,
        auth_type: config.auth_type,
        api_key: config.apiKey,
        is_active: false
      })
      .select()
      .maybeSingle();
    
    const transformed = data ? {
      ...data,
      responseField: data.response_field,
      apiKey: data.api_key
    } : null;

    return { data: transformed as ApiConfig | null, error };
  },

  async updateApiConfig(id: string, updates: Partial<ApiConfig>) {
    const dbUpdates: any = { ...updates };
    if ('responseField' in updates) {
      dbUpdates.response_field = updates.responseField;
      delete dbUpdates.responseField;
    }
    if ('apiKey' in updates) {
      dbUpdates.api_key = updates.apiKey;
      delete dbUpdates.apiKey;
    }

    const { data, error } = await supabase
      .from('api_configs')
      .update(dbUpdates)
      .eq('id', id)
      .select()
      .maybeSingle();
    
    const transformed = data ? {
      ...data,
      responseField: data.response_field,
      apiKey: data.api_key
    } : null;

    return { data: transformed as ApiConfig | null, error };
  },

  async deleteApiConfig(id: string) {
    const { error } = await supabase
      .from('api_configs')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Chatbots (Module Connections)
  async getChatbots() {
    const { data, error } = await supabase
      .from('chatbots')
      .select('*')
      .order('id');
    return { data: (data || []) as Chatbot[], error };
  },

  async updateChatbotApiIds(chatbotId: string, apiIds: string[]) {
    const { data, error } = await supabase
      .from('chatbots')
      .update({
        api_ids: apiIds,
        updated_at: new Date().toISOString()
      })
      .eq('id', chatbotId)
      .select()
      .maybeSingle();
    return { data: data as Chatbot | null, error };
  },


  async forceLogout(id: string) {
    const { error } = await supabase
      .from('student_sessions')
      .update({ status: 'forced_logout' })
      .eq('id', id);
    return { error };
  },

  async forceLogoutAll() {
    const { error } = await supabase
      .from('student_sessions')
      .update({ status: 'forced_logout' })
      .eq('status', 'active');
    return { error };
  },

  async blockStudent(id: string, reason?: string) {
    const { error } = await supabase
      .from('students')
      .update({ is_blocked: true, block_reason: reason || null })
      .eq('id', id);
    
    // Also logout all active sessions for this student
    if (!error) {
      await supabase
        .from('student_sessions')
        .update({ status: 'forced_logout' })
        .eq('student_id', id)
        .eq('status', 'active');
    }
    return { error };
  },

  async unblockStudent(id: string) {
    const { error } = await supabase
      .from('students')
      .update({ is_blocked: false, block_reason: null })
      .eq('id', id);
    return { error };
  },

  // Appointments
  async createAppointment(appointment: Omit<Appointment, 'id' | 'status' | 'created_at'>) {
    const { data, error } = await supabase
      .from('appointments')
      .insert([appointment])
      .select()
      .maybeSingle();
    return { data: data as Appointment | null, error };
  },

  async getAppointments() {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .order('created_at', { ascending: false });
    return { data: (data || []) as Appointment[], error };
  },

  async updateAppointmentStatus(id: string, status: Appointment['status']) {
    const { data, error } = await supabase
      .from('appointments')
      .update({ status })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Appointment | null, error };
  },

  // Admissions
  async createAdmission(admission: Omit<Admission, 'id' | 'status' | 'created_at'>) {
    const { data, error } = await supabase
      .from('admissions')
      .insert([admission])
      .select()
      .maybeSingle();
    return { data: data as Admission | null, error };
  },

  async getAdmissions() {
    const { data, error } = await supabase
      .from('admissions')
      .select('*')
      .order('created_at', { ascending: false });
    return { data: (data || []) as Admission[], error };
  },

  async updateAdmissionStatus(id: string, status: Admission['status']) {
    const { data, error } = await supabase
      .from('admissions')
      .update({ status })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as Admission | null, error };
  },

  // Social Media Links
  async getSocialMediaLinks() {
    const { data, error } = await supabase
      .from('social_media_links')
      .select('*')
      .order('created_at', { ascending: true });
    return { data: (data || []) as SocialMediaLink[], error };
  },

  async createSocialMediaLink(link: Omit<SocialMediaLink, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('social_media_links')
      .insert([link])
      .select()
      .maybeSingle();
    return { data: data as SocialMediaLink | null, error };
  },

  async updateSocialMediaLink(id: string, link: Partial<SocialMediaLink>) {
    const { data, error } = await supabase
      .from('social_media_links')
      .update({ ...link, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as SocialMediaLink | null, error };
  },

  async deleteSocialMediaLink(id: string) {
    const { error } = await supabase
      .from('social_media_links')
      .delete()
      .eq('id', id);
    return { error };
  },

  // Attendance Config
  async getAttendanceConfig() {
    const { data, error } = await supabase
      .from('attendance_config')
      .select('*')
      .limit(1)
      .maybeSingle();
    return { data: data as AttendanceConfig | null, error };
  },

  async updateAttendanceConfig(id: string, updates: Partial<AttendanceConfig>) {
    const { data, error } = await supabase
      .from('attendance_config')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select()
      .maybeSingle();
    return { data: data as AttendanceConfig | null, error };
  },

  // Parent Portal Specific
  async getParentLinkedStudents(profileId: string) {
    const { data, error } = await supabase.rpc('get_parent_linked_students', { p_profile_id: profileId });
    return { data, error };
  },

  async getStudentAttendanceForParent(studentId: string, parentProfileId: string) {
    const { data, error } = await supabase.rpc('get_student_attendance_for_parent', { 
      p_student_id: studentId, 
      p_parent_profile_id: parentProfileId 
    });
    return { data, error };
  },

  async getNoticesForParent(studentId: string, parentProfileId: string) {
    const { data, error } = await supabase.rpc('get_notices_for_parent', { 
      p_student_id: studentId, 
      p_parent_profile_id: parentProfileId 
    });
    return { data, error };
  },

  async getTimetableForParent(studentId: string, parentProfileId: string) {
    const { data, error } = await supabase.rpc('get_timetable_for_parent', { 
      p_student_id: studentId, 
      p_parent_profile_id: parentProfileId 
    });
    return { data, error };
  },

  async getNoticesByClass(_className: string) {
    const { data, error } = await supabase
      .from('notices')
      .select('*')
      .order('date', { ascending: false });
    return { data, error };
  },

  async getTimetableByClass(className: string, sectionName: string) {
    const { data, error } = await supabase
      .from('timetable')
      .select('*')
      .eq('class', className)
      .eq('section', sectionName);
    return { data, error };
  },


  async getVerificationLogs() {
    return supabase
      .from('verification_logs' as any)
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
  },

  async getDeploymentAuditLogs() {
    return supabase
      .from('deployment_audit_logs' as any)
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
  },

  async getOauthAuditLogs() {
    return supabase
      .from('oauth_audit_logs' as any)
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
  },

  // PIN Security
  async verifyPIN(userId: string, pin: string) {
    const { data, error } = await supabase.rpc('verify_user_pin', { p_user_id: userId, p_pin: pin });
    return { data: data as { success: boolean, message?: string, lockout_until?: string, remaining_attempts?: number }, error };
  },

  async updatePIN(userId: string, newPin: string) {
    const { data, error } = await supabase.rpc('update_user_pin', { p_user_id: userId, p_new_pin: newPin });
    return { data, error };
  },

  async adminResetPIN(userId: string, newPin: string) {
    const { data, error } = await supabase
      .from('profiles')
      .update({ 
        pin: newPin,
        pin_setup_required: true,
        pin_attempt_count: 0,
        pin_lockout_until: null
      })
      .eq('id', userId)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async adminClearPIN(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .update({ 
        pin: null,
        pin_setup_required: true,
        pin_attempt_count: 0,
        pin_lockout_until: null
      })
      .eq('id', userId)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async adminRemoveLock(userId: string) {
    const { data, error } = await supabase
      .from('profiles')
      .update({ pin_attempt_count: 0, pin_lockout_until: null })
      .eq('id', userId)
      .select()
      .maybeSingle();
    return { data: data as Profile | null, error };
  },

  async toggleMasterStatus(userId: string, status: boolean) {
    const { error } = await supabase.rpc('toggle_master_status', {
      p_user_id: userId,
      p_status: status
    });
    return { error };
  },

  async toggleAccountStatus(userId: string, status: 'active' | 'restricted') {
    const { error } = await supabase.rpc('toggle_account_status', {
      p_user_id: userId,
      p_status: status
    });
    return { error };
  },

  async getPublicTables() {
    const { data, error } = await supabase.rpc('get_public_tables');
    return { data: (data || []) as { table_name: string }[], error };
  },

  async getTableData(tableName: string) {
    const { data, error } = await supabase.from(tableName).select('*');
    return { data: (data || []) as any[], error };
  },

  // API Management
  async getApiKeys() {
    const { data, error } = await supabase.from('api_keys').select('*').order('created_at', { ascending: false });
    return { data: (data || []) as ApiKey[], error };
  },

  async createApiKey(name: string, rateLimit: number = 60) {
    const { data, error } = await supabase.from('api_keys').insert({
      name,
      rate_limit_minute: rateLimit
    }).select().single();
    return { data: data as ApiKey | null, error };
  },

  async toggleApiKeyStatus(id: string, isActive: boolean) {
    const { error } = await supabase.from('api_keys').update({ is_active: isActive }).eq('id', id);
    return { error };
  },

  async deleteApiKey(id: string) {
    const { error } = await supabase.from('api_keys').delete().eq('id', id);
    return { error };
  },

  async regenerateApiKey(id: string) {
    const newKey = Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    const { error } = await supabase.from('api_keys').update({ key_value: newKey }).eq('id', id);
    return { error };
  },

  async getApiEndpoints() {
    const { data, error } = await supabase.from('api_endpoints').select('*').order('path', { ascending: true });
    return { data: (data || []) as ApiEndpoint[], error };
  },

  async createApiEndpoint(endpoint: Partial<ApiEndpoint>) {
    const { data, error } = await supabase.from('api_endpoints').insert(endpoint).select().single();
    return { data: data as ApiEndpoint | null, error };
  },

  async updateApiEndpoint(id: string, endpoint: Partial<ApiEndpoint>) {
    const { data, error } = await supabase.from('api_endpoints').update({ ...endpoint, updated_at: new Date().toISOString() }).eq('id', id).select().single();
    return { data: data as ApiEndpoint | null, error };
  },

  async toggleApiEndpointStatus(id: string, isActive: boolean) {
    const { error } = await supabase.from('api_endpoints').update({ is_active: isActive, updated_at: new Date().toISOString() }).eq('id', id);
    return { error };
  },

  async deleteApiEndpoint(id: string) {
    const { error } = await supabase.from('api_endpoints').delete().eq('id', id);
    return { error };
  },

  async getApiLogs(limit: number = 100, moduleApiId?: string) {
    let query = supabase.from('api_logs').select('*, api_keys(name), api_endpoints(path), module_apis(api_name, module_name)');
    if (moduleApiId) {
      query = query.eq('module_api_id', moduleApiId);
    }
    const { data, error } = await query.order('created_at', { ascending: false }).limit(limit);
    return { data: (data || []) as any[], error };
  },

  async getModuleApis(moduleName?: string) {
    let query = supabase.from('module_apis').select('*');
    if (moduleName) {
      query = query.eq('module_name', moduleName);
    }
    const { data, error } = await query.order('created_at', { ascending: false });
    return { data: (data || []) as ModuleApi[], error };
  },

  async analyzeAndEnableModuleApi(moduleName: string) {
    // 1. Run Analysis Engine
    const { data: analysisData, error: analysisError } = await supabase.rpc('analyze_module_schema', { p_table_name: moduleName });
    if (analysisError) return { error: analysisError };

    const { complexity, schema_json, api_name } = analysisData;
    const apiKey = `sk_${Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')}`;
    
    // Auto-generate standardized endpoint path: /api/[module_name]
    const endpointPath = `/api/${moduleName.toLowerCase()}`;

    // 2. Upsert Module API config
    const { data, error } = await supabase
      .from('module_apis')
      .upsert({
        module_name: moduleName,
        api_name: api_name,
        api_key: apiKey,
        complexity,
        schema_json,
        endpoint_path: endpointPath,
        is_active: true,
        allowed_methods: ['POST'], // Default method is POST
        rate_limit_minute: complexity === 'complex' ? 50 : 100,
        description: `Auto-generated inbound-only API for ${moduleName} module.`
      }, { onConflict: 'module_name' })
      .select()
      .single();

    return { data: data as ModuleApi | null, error };
  },

  async updateModuleApiMethods(id: string, methods: string[]) {
    const { data, error } = await supabase
      .from('module_apis')
      .update({ allowed_methods: methods })
      .eq('id', id)
      .select()
      .single();
    return { data: data as ModuleApi | null, error };
  },

  async migrateLegacyApis() {
    // Legacy mapping: Look for api_keys and api_endpoints and try to link them to modules
    const { data: legacyKeys } = await supabase.from('api_keys').select('*');
    const { data: legacyEndpoints } = await supabase.from('api_endpoints').select('*');
    const { data: existingModuleApis } = await supabase.from('module_apis').select('module_name');

    const existingModules = new Set(existingModuleApis?.map(a => a.module_name) || []);
    
    // For each legacy endpoint that matches a known module and is not yet in module_apis
    if (legacyEndpoints) {
      for (const endpoint of legacyEndpoints) {
        if (!existingModules.has(endpoint.module_name)) {
          // Find a matching key or create one
          const matchingKey = legacyKeys?.find(k => k.id === endpoint.id); // Placeholder logic
          await this.analyzeAndEnableModuleApi(endpoint.module_name);
          existingModules.add(endpoint.module_name);
        }
      }
    }
    return { success: true };
  },

  async updateModuleApi(id: string, apiData: Partial<ModuleApi>) {
    const { data, error } = await supabase.from('module_apis').update(apiData).eq('id', id).select().single();
    return { data: data as ModuleApi | null, error };
  },

  async deleteModuleApi(id: string) {
    const { error } = await supabase.from('module_apis').delete().eq('id', id);
    return { error };
  },

  async regenerateModuleApiKey(id: string) {
    const newKey = `sk_${Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')}`;
    const { error } = await supabase.from('module_apis').update({ api_key: newKey }).eq('id', id);
    return { error };
  },

  async getTableColumns(tableName: string) {
    const { data, error } = await supabase.rpc('get_table_columns', { p_table_name: tableName });
    return { data: (data || []).map((c: any) => c.column_name) as string[], error };
  },

  // Email OTP
  async getEmailOtpSettings() {
    const { data, error } = await supabase
      .from('system_config')
      .select('config_value')
      .eq('config_key', 'email_otp_settings')
      .maybeSingle();
    return { data: (data?.config_value || {}) as any, error };
  },

  async generateOTP(userId: string, otpHash: string) {
    const { data, error } = await supabase.rpc('generate_user_email_otp', { 
      p_user_id: userId, 
      p_otp_hash: otpHash 
    });
    return { data: data as { success: boolean, email?: string, message?: string, cooldown_remaining?: number }, error };
  },

  async verifyOTP(userId: string, otpInput: string) {
    const { data, error } = await supabase.rpc('verify_user_email_otp', { 
      p_user_id: userId, 
      p_otp_input: otpInput 
    });
    return { data: data as { success: boolean, message?: string, remaining_attempts?: number }, error };
  },

  // ── Master Fees ──────────────────────────────────────────────
  async getMasterFees(sessionYear?: string) {
    let query = supabase.from('master_fees').select('*').order('class_name');
    if (sessionYear) query = query.eq('session_year', sessionYear);
    const { data, error } = await query;
    return { data: (data || []) as MasterFee[], error };
  },

  async upsertMasterFee(classname: string, sessionYear: string, totalAmount: number) {
    const { data, error } = await supabase
      .from('master_fees')
      .upsert(
        { class_name: classname, session_year: sessionYear, total_amount: totalAmount, updated_at: new Date().toISOString() },
        { onConflict: 'class_name,session_year' }
      )
      .select()
      .maybeSingle();
    return { data: data as MasterFee | null, error };
  },

  async getMasterFeeForClass(classname: string, sessionYear: string) {
    const { data, error } = await supabase
      .from('master_fees')
      .select('*')
      .eq('class_name', classname)
      .eq('session_year', sessionYear)
      .maybeSingle();
    return { data: data as MasterFee | null, error };
  },

  // ── Fee Payments (core ledger) ────────────────────────────────
  async getStudentCorePaidTotal(studentId: string, sessionYear: string) {
    const { data, error } = await supabase
      .rpc('get_student_core_paid_total', { p_student_id: studentId, p_session_year: sessionYear });
    return { data: Number(data ?? 0), error };
  },

  async getFeePayments(studentId: string, sessionYear?: string) {
    let query = supabase
      .from('fee_payments')
      .select('*')
      .eq('student_id', studentId)
      .order('payment_date', { ascending: false });
    if (sessionYear) query = query.eq('session_year', sessionYear);
    const { data, error } = await query;
    return { data: (data || []) as FeePayment[], error };
  },

  async createFeePayment(payment: {
    student_id: string;
    session_year: string;
    payment_period: string;
    amount: number;
    payment_method: string;
    payment_date: string;
    transaction_id?: string;
    notes?: string;
    collected_by?: string;
    receipt_id?: string;
  }) {
    const { data, error } = await supabase
      .from('fee_payments')
      .insert(payment)
      .select()
      .maybeSingle();
    return { data: data as FeePayment | null, error };
  },

  // ── Extra / Other Fees ────────────────────────────────────────
  async getExtraFees(studentId?: string, sessionYear?: string) {
    let query = supabase
      .from('extra_fees')
      .select('*, students(name, login_id, class, section)')
      .order('created_at', { ascending: false });
    if (studentId) query = query.eq('student_id', studentId);
    if (sessionYear) query = query.eq('session_year', sessionYear);
    const { data, error } = await query;
    return { data: (data || []) as ExtraFee[], error };
  },

  async createExtraFee(fee: {
    student_id: string;
    fee_category: 'extra' | 'other';
    description: string;
    reason: string;
    amount: number;
    payment_method: string;
    payment_date: string;
    session_year: string;
    transaction_id?: string;
    collected_by?: string;
  }) {
    const { data, error } = await supabase
      .from('extra_fees')
      .insert(fee)
      .select('*, students(name, login_id, class, section)')
      .maybeSingle();
    return { data: data as ExtraFee | null, error };
  },

  // ── Fee Receipts ──────────────────────────────────────────────
  async getFeeReceipts(studentId?: string) {
    let query = supabase
      .from('fee_receipts')
      .select('*, students(name, login_id, class, section, profile_picture_url)')
      .order('created_at', { ascending: false });

    if (studentId) query = query.eq('student_id', studentId);
    const { data, error } = await query;
    return { data: (data || []) as any[], error };
  },

  async getFeeReceiptById(id: string) {
    const { data, error } = await supabase
      .from('fee_receipts')
      .select('*, students(name, login_id, class, section, profile_picture_url)')
      .eq('id', id)
      .maybeSingle();
    return { data: data as any, error };
  },

  async generateReceiptNumber() {
    const { data, error } = await supabase.rpc('generate_receipt_number');
    return { data: data as string, error };
  },

  // Build a deterministic hash from the student_id + sorted fee_detail_ids
  buildReceiptHash(studentId: string, feeDetailIds: string[]): string {
    const sorted = [...feeDetailIds].sort().join('|');
    const raw = `${studentId}::${sorted}`;
    // Simple djb2-style hash — no crypto dep needed
    let h = 5381;
    for (let i = 0; i < raw.length; i++) {
      h = ((h << 5) + h) ^ raw.charCodeAt(i);
    }
    return (h >>> 0).toString(16).padStart(8, '0') + '_' + btoa(raw).replace(/[^a-zA-Z0-9]/g, '').slice(0, 16);
  },

  // Check if a receipt was already generated for this exact set of fee items
  async findReceiptByHash(hash: string) {
    const { data, error } = await supabase
      .from('fee_receipts')
      .select('id, receipt_number, pdf_url, created_at, regenerated_count, is_receipt_generated')
      .eq('receipt_hash', hash)
      .maybeSingle();
    return { data: data as any, error };
  },

  async createFeeReceipt(receipt: {
    student_id: string;
    receipt_number: string;
    fee_detail_ids: string[];
    items: { description: string; amount: number; due_date?: string }[];
    total_amount: number;
    payment_method: string;
    transaction_id?: string;
    payment_date: string;
    notes?: string;
    generated_by?: string;
    pdf_url?: string;
    receipt_hash?: string;
  }) {
    const { data, error } = await supabase
      .from('fee_receipts')
      .insert({
        ...receipt,
        is_receipt_generated: true,
        generation_timestamp: new Date().toISOString(),
      })
      .select('*, students(name, login_id, class, section)')
      .maybeSingle();
    return { data: data as any, error };
  },

  async updateFeeReceiptPdfUrl(id: string, pdf_url: string) {
    const { data, error } = await supabase
      .from('fee_receipts')
      .update({ pdf_url, updated_at: new Date().toISOString() })
      .eq('id', id)
      .maybeSingle();
    return { data, error };
  },

  // Regenerate: bump counter, update pdf_url, keep same receipt_number
  async regenerateFeeReceipt(id: string, pdf_url: string) {
    const { data, error } = await supabase
      .from('fee_receipts')
      .update({
        pdf_url,
        updated_at: new Date().toISOString(),
        generation_timestamp: new Date().toISOString(),
        regenerated_count: supabase.rpc as any, // handled via raw increment below
      })
      .eq('id', id)
      .maybeSingle();
    return { data, error };
  },

  async incrementRegeneratedCount(id: string, pdf_url: string) {
    const { data, error } = await supabase.rpc('increment_receipt_regenerated', {
      p_id: id,
      p_pdf_url: pdf_url,
    });
    return { data, error };
  },

  // Upload PDF blob to Supabase Storage and return public URL
  async uploadReceiptPdf(receiptNumber: string, studentId: string, pdfBlob: Blob): Promise<string | null> {
    const path = `${studentId}/${receiptNumber}.pdf`;
    const { error: upErr } = await supabase.storage
      .from('fee-receipts')
      .upload(path, pdfBlob, { contentType: 'application/pdf', upsert: true });
    if (upErr) {
      console.error('Receipt PDF upload failed:', upErr.message);
      return null;
    }
    const { data } = await supabase.storage.from('fee-receipts').createSignedUrl(path, 60 * 60 * 24 * 365);
    return data?.signedUrl ?? null;
  },

  async deleteFeeReceipt(id: string) {
    const { error } = await supabase.from('fee_receipts').delete().eq('id', id);
    return { error };
  },

  // Parent: read receipts for all linked students
  async getFeeReceiptsForParent(parentProfileId: string) {
    // Get all linked student IDs first
    const { data: linked } = await supabase.rpc('get_parent_linked_students', {
      p_profile_id: parentProfileId,
    });
    if (!linked || linked.length === 0) return { data: [], error: null };
    const studentIds = (linked as any[]).map((s) => s.student_id);
    const { data, error } = await supabase
      .from('fee_receipts')
      .select('*, students(name, login_id, class, section)')
      .in('student_id', studentIds)
      .order('created_at', { ascending: false });
    return { data: (data || []) as any[], error };
  },
};

