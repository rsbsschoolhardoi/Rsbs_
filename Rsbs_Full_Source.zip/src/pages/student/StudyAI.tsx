import React, { useState, useEffect, useRef } from 'react';
import { useApiConfigs } from '@/hooks/useApiConfigs';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { AiChatSession, AiChatMessage, ApiConfig } from '@/types';
import { buildAdaptivePayload } from '@/lib/payloadEngine';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme } from 'next-themes';
import MarkdownRenderer from '@/components/chat/MarkdownRenderer';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Plus, MessageSquare, Trash2, Edit2, Check, X, Copy, Share2,
  Menu, Send, Loader2, Sparkles,
  AlertCircle, ShieldAlert, Lock, Search, Pin, PinOff,
  RefreshCw, Square, ChevronDown, Sun, Moon, RotateCcw,
  ArrowDown,
} from 'lucide-react';

// ─── Typing Dots ─────────────────────────────────────────────────────────────
const TypingDots: React.FC = () => (
  <div className="flex items-center gap-1.5 py-1">
    <span className="text-xs text-muted-foreground">Study AI is typing</span>
    {[0, 1, 2].map(i => (
      <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-primary inline-block"
        animate={{ y: [0, -4, 0] }} transition={{ duration: 0.55, repeat: Infinity, delay: i * 0.13 }} />
    ))}
  </div>
);

// ─── Streaming cursor ─────────────────────────────────────────────────────────
const StreamingText: React.FC<{ text: string }> = ({ text }) => (
  <span className="relative">
    <MarkdownRenderer content={text} />
    <motion.span className="inline-block w-0.5 h-3.5 bg-primary ml-0.5 align-middle rounded-sm"
      animate={{ opacity: [1, 0] }} transition={{ duration: 0.45, repeat: Infinity }} />
  </span>
);

// ─── Shimmer skeleton ─────────────────────────────────────────────────────────
const ShimmerMessage: React.FC<{ right?: boolean }> = ({ right }) => (
  <div className={cn('flex mb-2', right ? 'justify-end' : 'justify-start')}>
    <div className={cn('space-y-1.5 py-2 px-3 rounded-xl', right ? 'w-44' : 'w-60')}>
      {[100, 75, 55].map((w, i) => (
        <div key={i} className="h-2.5 rounded-full bg-muted animate-pulse" style={{ width: `${w}%` }} />
      ))}
    </div>
  </div>
);

// ─── Model Selector Dropdown ──────────────────────────────────────────────────
const ModelSelector: React.FC<{
  configs: ApiConfig[];
  selected: ApiConfig | null;
  onSelect: (c: ApiConfig) => void;
}> = ({ configs, selected, onSelect }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  if (!configs.length) return null;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(v => !v)}
        className={cn(
          'flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all',
          'border border-border/60 hover:border-primary/50 hover:bg-primary/5',
          'text-muted-foreground hover:text-foreground'
        )}
      >
        <span className="max-w-[120px] truncate">{selected?.name || 'Select model'}</span>
        <ChevronDown className={cn('w-3 h-3 shrink-0 transition-transform', open && 'rotate-180')} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.97 }}
            transition={{ duration: 0.12 }}
            className={cn(
              'absolute bottom-full mb-1.5 left-0 z-50 min-w-[180px] rounded-xl border border-border/50 shadow-lg overflow-hidden',
              'bg-background/95 backdrop-blur-xl'
            )}
          >
            <div className="py-1">
              {configs.map(c => (
                <button
                  key={c.id}
                  onClick={() => { onSelect(c); setOpen(false); }}
                  className={cn(
                    'w-full flex items-center gap-2 px-3 py-2 text-xs text-left transition-colors',
                    c.id === selected?.id
                      ? 'text-primary bg-primary/8 font-semibold'
                      : 'text-foreground hover:bg-muted/60'
                  )}
                >
                  {c.id === selected?.id && <Check className="w-3 h-3 shrink-0" />}
                  {c.id !== selected?.id && <span className="w-3 shrink-0" />}
                  <span className="truncate">{c.name}</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ─── Main component ───────────────────────────────────────────────────────────
const StudyAI: React.FC = () => {
  const { profile } = useAuth();
  const { configs, getModuleConfig, isLoaded: apiLoaded } = useApiConfigs();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  // Model selection — default to the study-ai module config, switchable
  const defaultConfig = getModuleConfig('study-ai');
  const [selectedModel, setSelectedModel] = useState<ApiConfig | null>(null);
  const activeConfig = selectedModel || defaultConfig;

  // Initialise selectedModel once configs load
  useEffect(() => {
    if (defaultConfig && !selectedModel) setSelectedModel(defaultConfig);
  }, [defaultConfig]);

  // Sessions
  const [sessions, setSessions] = useState<AiChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<AiChatSession | null>(null);
  const [sessionsLoading, setSessionsLoading] = useState(true);
  const [sidebarSearch, setSidebarSearch] = useState('');
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  // Messages
  const [messages, setMessages] = useState<AiChatMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const [streamingText, setStreamingText] = useState('');

  // Input
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isStopped, setIsStopped] = useState(false);
  const stopRef = useRef(false);

  // Conversation search
  const [convSearch, setConvSearch] = useState('');
  const [showConvSearch, setShowConvSearch] = useState(false);
  const [convSearchIdx, setConvSearchIdx] = useState(0);

  // AI config / access
  const [aiConfig, setAiConfig] = useState<any>(null);
  const [isDataLoaded, setIsDataLoaded] = useState(false);

  // Scroll
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // ─── Effects ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (profile?.student_id && profile?.role === 'student') {
      fetchAiConfig();
      fetchSessions();
    } else {
      setIsDataLoaded(true);
      setSessionsLoading(false);
    }
  }, [profile]);

  useEffect(() => {
    if (activeSession) fetchMessages(activeSession.id);
    else setMessages([]);
  }, [activeSession]);

  useEffect(() => {
    if (!showScrollBtn) scrollToBottom('smooth');
  }, [messages, streamingText]);

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  }, [inputValue]);

  // ─── Data fetch ───────────────────────────────────────────────────────────
  const fetchAiConfig = async () => {
    if (!profile?.student_id) return;
    const { data: student } = await api.getStudentById(profile.student_id);
    if (!student?.class_id) { setIsDataLoaded(true); return; }
    const config = await api.getAiConfigForStudent(profile.student_id, student.class_id);
    setAiConfig(config);
    setIsDataLoaded(true);
  };

  const fetchSessions = async () => {
    if (!profile?.student_id) return;
    setSessionsLoading(true);
    const { data, error } = await api.getAiChatSessions(profile.student_id);
    if (!error && data) {
      setSessions(data);
      if (!activeSession && data.length > 0) setActiveSession(data[0]);
    }
    setSessionsLoading(false);
  };

  const fetchMessages = async (sessionId: string) => {
    setMessagesLoading(true);
    const { data, error } = await api.getAiChatMessages(sessionId);
    if (!error) setMessages(data || []);
    setMessagesLoading(false);
  };

  // ─── Scroll ───────────────────────────────────────────────────────────────
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  // ─── Access check ─────────────────────────────────────────────────────────
  const checkAccess = () => {
    if (!aiConfig) return { allowed: true };
    const { globalSettings, studentConfig, classConfig, usage } = aiConfig;
    if (!globalSettings?.is_system_enabled)
      return { allowed: false, message: globalSettings?.system_unavailable_message, type: 'unavailable' };
    if (studentConfig?.is_enabled === false)
      return { allowed: false, message: globalSettings?.individual_disabled_message, type: 'disabled' };
    if (classConfig?.is_enabled === false)
      return { allowed: false, message: globalSettings?.class_disabled_message, type: 'disabled' };
    const limit = studentConfig?.daily_limit || classConfig?.daily_limit || globalSettings?.global_daily_limit || 50;
    if ((usage?.message_count || 0) >= limit)
      return { allowed: false, message: `${globalSettings?.limit_reached_message}\n\n${globalSettings?.reset_info_message}`, type: 'limit' };
    return { allowed: true };
  };

  // ─── Session management ───────────────────────────────────────────────────
  const handleCreateSession = async () => {
    if (!profile?.student_id) return;
    const { data, error } = await api.createAiChatSession(profile.student_id, 'New Chat');
    if (error || !data) { toast.error('Failed to create chat'); return; }
    setSessions(prev => [data, ...prev]);
    setActiveSession(data);
    setMessages([]);
  };

  const handleDeleteSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const { error } = await api.deleteAiChatSession(id);
    if (error) { toast.error('Failed to delete'); return; }
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSession?.id === id) { setActiveSession(null); setMessages([]); }
  };

  const handleRenameSession = async (id: string) => {
    if (!editingTitle.trim()) return;
    const { error } = await api.updateAiChatSession(id, { title: editingTitle.trim() });
    if (error) { toast.error('Failed to rename'); return; }
    setSessions(prev => prev.map(s => s.id === id ? { ...s, title: editingTitle.trim() } : s));
    if (activeSession?.id === id) setActiveSession(prev => prev ? { ...prev, title: editingTitle.trim() } : prev);
    setEditingSessionId(null);
  };

  const handlePinSession = async (session: AiChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    const newPin = !session.is_pinned;
    await api.updateAiChatSession(session.id, { is_pinned: newPin } as any);
    setSessions(prev => prev.map(s => s.id === session.id ? { ...s, is_pinned: newPin } : s));
  };

  // ─── Build system prompt ──────────────────────────────────────────────────
  const buildSystemPrompt = async (currentAiConfig: any): Promise<string> => {
    let studentData: any = {};
    let contextualInfo = '';
    if (profile?.student_id) {
      const { data: student } = await api.getStudentById(profile.student_id);
      if (student) {
        studentData = { name: student.name, class: student.class, section: student.section };
        const perms = currentAiConfig?.globalSettings;
        if (perms?.access_grades_enabled) studentData.rank_in_class = student.rank;
        if (perms?.access_attendance_enabled) { const { data: att } = await api.getAttendance(profile.student_id); studentData.attendance = att; }
        if (perms?.access_exams_enabled) { const { data: exams } = await api.getExams(); studentData.upcoming_exams = exams; }
        contextualInfo = `\nSTUDENT CONTEXT:\n${JSON.stringify(studentData, null, 2)}\nPERMISSIONS: Grades=${perms?.access_grades_enabled ? 'YES' : 'NO'} Attendance=${perms?.access_attendance_enabled ? 'YES' : 'NO'} Exams=${perms?.access_exams_enabled ? 'YES' : 'NO'} Fees=${perms?.access_fees_enabled ? 'YES' : 'NO'}`;
      }
    }
    return `You are Study AI, an intelligent and friendly educational assistant developed by Inolas Technologies for RSBS School. Personality: warm, encouraging, patient. Auto-detect Hindi/English/Hinglish and reply in the same language. Use markdown for structure. Subjects: Math, Science, English, Hindi, Social Science, CS, Coding, NCERT, UPMSP.${contextualInfo}`;
  };

  // ─── Word-by-word streaming ───────────────────────────────────────────────
  const streamResponse = async (fullText: string, msgId: string) => {
    setStreamingMessageId(msgId);
    setStreamingText('');
    stopRef.current = false;
    const words = fullText.split(' ');
    let built = '';
    for (let i = 0; i < words.length; i++) {
      if (stopRef.current) break;
      built += (i === 0 ? '' : ' ') + words[i];
      setStreamingText(built);
      await new Promise(r => setTimeout(r, 14 + Math.random() * 16));
    }
    if (!stopRef.current) setStreamingText(fullText);
    setStreamingMessageId(null);
  };

  // ─── Main send ────────────────────────────────────────────────────────────
  const handleSend = async (overrideText?: string) => {
    const text = (overrideText ?? inputValue).trim();
    if (!text) return;
    const access = checkAccess();
    if (!access.allowed) { toast.error(access.message || 'Access denied'); return; }
    if (!activeConfig) { toast.error('Study AI is not configured. Contact your admin.'); return; }

    // Auto-create session
    let session = activeSession;
    if (!session) {
      if (!profile?.student_id) return;
      const { data, error } = await api.createAiChatSession(profile.student_id, text.slice(0, 40) || 'New Chat');
      if (error || !data) { toast.error('Failed to start session'); return; }
      session = data;
      setActiveSession(data);
      setSessions(prev => [data, ...prev]);
    }

    setIsLoading(true);
    setIsStopped(false);
    setInputValue('');
    scrollToBottom();

    try {
      // Refresh config
      let currentAiConfig = aiConfig;
      if (profile?.student_id) {
        const { data: sr } = await api.getStudentById(profile.student_id);
        if (sr?.class_id) { currentAiConfig = await api.getAiConfigForStudent(profile.student_id, sr.class_id); setAiConfig(currentAiConfig); }
      }

      // Save user message
      const { data: savedUser, error: userErr } = await api.addAiChatMessage({
        session_id: session.id, role: 'user', content: text, attachments: []
      });
      if (userErr || !savedUser) { toast.error('Failed to save message'); return; }
      setMessages(prev => [...prev, savedUser]);

      if (profile?.student_id) { await api.incrementAiUsage(profile.student_id); fetchAiConfig(); }

      // Build payload — pass full history for context continuity across model switches
      const systemPrompt = await buildSystemPrompt(currentAiConfig);
      const selectedBody = activeConfig.bodies.find((b: any) => b.is_default) || activeConfig.bodies[0];
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      const finalBody = buildAdaptivePayload(selectedBody.content, history, text, [], systemPrompt);

      // Headers
      const subVars = (t: string) => {
        let r = t;
        (activeConfig.variables || []).forEach((v: any) => { if (v.key && v.value) r = r.replace(new RegExp(`{{${v.key}}}`, 'g'), v.value); });
        return r;
      };
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      activeConfig.headers.forEach((h: any) => { if (h.key) headers[h.key] = subVars(h.value); });
      if (activeConfig.apiKey && activeConfig.auth_type !== 'none') {
        if (activeConfig.auth_type === 'bearer') headers['Authorization'] = `Bearer ${activeConfig.apiKey}`;
        else if (activeConfig.auth_type === 'api_key') headers['X-API-Key'] = activeConfig.apiKey;
      }

      let response: Response;
      try {
        response = await fetch(subVars(activeConfig.endpoint), {
          method: activeConfig.method,
          headers,
          body: activeConfig.method !== 'GET' ? JSON.stringify(finalBody) : undefined
        });
      } catch { throw new Error('Network error — check your connection.'); }

      if (!response.ok) {
        if (response.status === 401 || response.status === 403) throw new Error('Authentication failed. Check the API key.');
        if (response.status === 429) throw new Error('Rate limit reached. Please wait a moment.');
        if (response.status >= 500) throw new Error('AI service temporarily unavailable.');
        throw new Error(`Error ${response.status}`);
      }

      const respData = await response.json();
      const getNested = (obj: any, path: string) => path.split(/[.[\]]/).filter(Boolean).reduce((a: any, p: string) => a?.[p], obj);
      const parsed = getNested(respData, activeConfig.responseField);
      const fullText = typeof parsed === 'string' ? parsed : JSON.stringify(respData, null, 2);

      // Save AI message & stream it
      const { data: savedAI } = await api.addAiChatMessage({
        session_id: session.id, role: 'assistant', content: fullText, attachments: []
      });
      if (savedAI) {
        setMessages(prev => [...prev, { ...savedAI, content: '' }]);
        await streamResponse(fullText, savedAI.id);
        setMessages(prev => prev.map(m => m.id === savedAI.id ? { ...m, content: fullText } : m));
      }

      // Auto-rename
      if (session.title === 'New Chat' && text.length > 3) {
        const newTitle = text.slice(0, 45) + (text.length > 45 ? '…' : '');
        await api.updateAiChatSession(session.id, { title: newTitle });
        setSessions(prev => prev.map(s => s.id === session!.id ? { ...s, title: newTitle } : s));
        if (activeSession?.id === session.id) setActiveSession(prev => prev ? { ...prev, title: newTitle } : prev);
      }
    } catch (err: any) {
      const msg = err?.message || 'Study AI encountered an error. Please try again.';
      toast.error(msg, { duration: 5000 });
      if (session) {
        const { data: saved } = await api.addAiChatMessage({ session_id: session.id, role: 'assistant', content: `⚠️ ${msg}`, attachments: [] });
        if (saved) setMessages(prev => [...prev, saved]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleStop = () => { stopRef.current = true; setIsStopped(true); setStreamingMessageId(null); };
  const handleRegenerate = async () => {
    const lastUser = [...messages].reverse().find(m => m.role === 'user');
    if (!lastUser) return;
    const lastAI = [...messages].reverse().find(m => m.role === 'assistant');
    if (lastAI) setMessages(prev => prev.filter(m => m.id !== lastAI.id));
    await handleSend(lastUser.content);
  };
  const handleDeleteMessage = (msgId: string) => setMessages(prev => prev.filter(m => m.id !== msgId));

  // ─── Filtered sessions ────────────────────────────────────────────────────
  const filteredSessions = sessions.filter(s =>
    !sidebarSearch || s.title.toLowerCase().includes(sidebarSearch.toLowerCase())
  );
  const pinned = filteredSessions.filter(s => s.is_pinned);
  const recent = filteredSessions.filter(s => !s.is_pinned);

  // ─── Conversation search ──────────────────────────────────────────────────
  const searchMatches = convSearch
    ? messages.reduce<number[]>((acc, m, i) => {
        if (m.content.toLowerCase().includes(convSearch.toLowerCase())) acc.push(i);
        return acc;
      }, [])
    : [];

  // ─── Guards ───────────────────────────────────────────────────────────────
  if (!apiLoaded || !isDataLoaded) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
          <Sparkles className="w-6 h-6 text-primary" />
        </motion.div>
      </div>
    );
  }

  const access = checkAccess();
  const canSend = !isLoading && !!activeConfig && access.allowed && !!inputValue.trim();

  // ─── Sidebar ──────────────────────────────────────────────────────────────
  const SessionItem = ({ session }: { session: AiChatSession }) => (
    <div
      className={cn(
        'group relative flex items-center gap-2 px-2.5 py-1.5 rounded-lg cursor-pointer transition-all duration-100 text-sm',
        activeSession?.id === session.id
          ? 'bg-primary/10 text-primary font-medium'
          : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
      )}
      onClick={() => setActiveSession(session)}
    >
      {editingSessionId === session.id ? (
        <div className="flex items-center gap-1 flex-1 min-w-0" onClick={e => e.stopPropagation()}>
          <Input value={editingTitle} onChange={e => setEditingTitle(e.target.value)}
            className="h-6 text-xs flex-1 py-0" autoFocus
            onKeyDown={e => { if (e.key === 'Enter') handleRenameSession(session.id); if (e.key === 'Escape') setEditingSessionId(null); }} />
          <button className="p-0.5 hover:text-primary" onClick={() => handleRenameSession(session.id)}><Check className="w-3 h-3" /></button>
          <button className="p-0.5 hover:text-destructive" onClick={() => setEditingSessionId(null)}><X className="w-3 h-3" /></button>
        </div>
      ) : (
        <>
          <MessageSquare className="w-3.5 h-3.5 shrink-0 opacity-60" />
          <span className="flex-1 text-xs truncate">{session.title}</span>
          {session.is_pinned && <Pin className="w-2.5 h-2.5 text-primary/50 shrink-0" />}
          <div className="absolute right-1 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-0.5 bg-background/95 rounded-md px-0.5 shadow-sm border border-border/40">
            <button className="p-1 hover:text-primary" onClick={e => handlePinSession(session, e)}>
              {session.is_pinned ? <PinOff className="w-3 h-3" /> : <Pin className="w-3 h-3" />}
            </button>
            <button className="p-1 hover:text-foreground" onClick={e => { e.stopPropagation(); setEditingSessionId(session.id); setEditingTitle(session.title); }}>
              <Edit2 className="w-3 h-3" />
            </button>
            <button className="p-1 hover:text-destructive" onClick={e => handleDeleteSession(session.id, e)}>
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </>
      )}
    </div>
  );

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-border/40">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-semibold text-sm">Study AI</span>
        </div>
        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 hover:bg-primary/10 hover:text-primary" onClick={handleCreateSession}>
          <Plus className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Search */}
      <div className="px-2 py-2 border-b border-border/30">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
          <Input value={sidebarSearch} onChange={e => setSidebarSearch(e.target.value)}
            placeholder="Search chats…" className="pl-6 h-7 text-xs" />
        </div>
      </div>

      {/* Sessions */}
      <div className="flex-1 overflow-y-auto py-1.5 px-1.5">
        {sessionsLoading ? (
          Array(4).fill(0).map((_, i) => <div key={i} className="h-7 rounded-lg bg-muted/40 animate-pulse mb-1" />)
        ) : (
          <>
            {pinned.length > 0 && (
              <div className="mb-1">
                <p className="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/70">Pinned</p>
                {pinned.map(s => <SessionItem key={s.id} session={s} />)}
              </div>
            )}
            {recent.length > 0 && (
              <div>
                {pinned.length > 0 && <p className="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground/70">Recent</p>}
                {recent.map(s => <SessionItem key={s.id} session={s} />)}
              </div>
            )}
            {filteredSessions.length === 0 && (
              <div className="text-center py-6 text-muted-foreground">
                <MessageSquare className="w-6 h-6 mx-auto mb-1.5 opacity-25" />
                <p className="text-xs">{sidebarSearch ? 'No chats found' : 'No chats yet'}</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );

  // ─── Render ───────────────────────────────────────────────────────────────
  return (
    <TooltipProvider>
      <div className="flex h-[calc(100vh-100px)] md:h-[calc(100vh-72px)] overflow-hidden max-w-6xl mx-auto gap-0 md:gap-2 px-1 md:px-3">

        {/* Desktop Sidebar */}
        <div className={cn(
          'hidden md:flex flex-col w-56 shrink-0 rounded-xl overflow-hidden border border-border/40',
          isDark ? 'bg-zinc-900/70' : 'bg-white/80'
        )}>
          <SidebarContent />
        </div>

        {/* Main column */}
        <div className="flex-1 flex flex-col overflow-hidden min-w-0">

          {/* Header — compact */}
          <div className={cn(
            'flex-none flex items-center justify-between px-3 py-1.5 mb-1.5 rounded-xl border border-border/40',
            isDark ? 'bg-zinc-900/70' : 'bg-white/80'
          )}>
            <div className="flex items-center gap-2 min-w-0">
              {/* Mobile sidebar */}
              <div className="md:hidden">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0"><Menu className="w-4 h-4" /></Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-64 p-0">
                    <div className={cn('h-full', isDark ? 'bg-zinc-900' : 'bg-white')}>
                      <SidebarContent />
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
              <div className="w-6 h-6 rounded-md bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shrink-0">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="text-sm font-semibold truncate">Study AI</span>
              {activeSession?.title && activeSession.title !== 'New Chat' && (
                <span className="text-xs text-muted-foreground truncate hidden sm:block">— {activeSession.title}</span>
              )}
            </div>

            <div className="flex items-center gap-0.5 shrink-0">
              {aiConfig?.usage && (
                <span className="text-[10px] text-muted-foreground hidden sm:block mr-1">
                  {aiConfig.usage.message_count}/{aiConfig.studentConfig?.daily_limit || aiConfig.classConfig?.daily_limit || aiConfig.globalSettings?.global_daily_limit || 50}
                </span>
              )}
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-primary"
                    onClick={() => setShowConvSearch(v => !v)}>
                    <Search className="w-3.5 h-3.5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Search in chat</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-primary"
                    onClick={() => setTheme(isDark ? 'light' : 'dark')}>
                    {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{isDark ? 'Light mode' : 'Dark mode'}</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-primary" onClick={handleCreateSession}>
                    <Plus className="w-3.5 h-3.5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>New chat</TooltipContent>
              </Tooltip>
            </div>
          </div>

          {/* Conversation search */}
          <AnimatePresence>
            {showConvSearch && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                className="flex-none mb-1.5 overflow-hidden">
                <div className={cn('flex items-center gap-2 px-2.5 py-1.5 rounded-xl border border-border/40',
                  isDark ? 'bg-zinc-900/70' : 'bg-white/80')}>
                  <Search className="w-3 h-3 text-muted-foreground shrink-0" />
                  <Input value={convSearch} onChange={e => { setConvSearch(e.target.value); setConvSearchIdx(0); }}
                    placeholder="Search messages…" className="h-6 text-xs border-0 bg-transparent p-0 focus-visible:ring-0" />
                  {searchMatches.length > 0 && (
                    <div className="flex items-center gap-1 shrink-0 text-[10px] text-muted-foreground">
                      <span>{convSearchIdx + 1}/{searchMatches.length}</span>
                      <button onClick={() => setConvSearchIdx(i => Math.max(0, i - 1))} className="hover:text-primary"><ChevronDown className="w-3 h-3 rotate-180" /></button>
                      <button onClick={() => setConvSearchIdx(i => Math.min(searchMatches.length - 1, i + 1))} className="hover:text-primary"><ChevronDown className="w-3 h-3" /></button>
                    </div>
                  )}
                  <button onClick={() => { setShowConvSearch(false); setConvSearch(''); }} className="hover:text-destructive"><X className="w-3 h-3" /></button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Message area */}
          <div className={cn(
            'flex-1 overflow-hidden flex flex-col min-h-0 rounded-xl border border-border/40 relative',
            isDark ? 'bg-zinc-900/50' : 'bg-white/70'
          )}>
            {!access.allowed ? (
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mb-3">
                  {access.type === 'limit' ? <ShieldAlert className="w-7 h-7 text-destructive" />
                    : access.type === 'unavailable' ? <AlertCircle className="w-7 h-7 text-destructive" />
                    : <Lock className="w-7 h-7 text-destructive" />}
                </div>
                <h2 className="text-base font-bold mb-2">Access Restricted</h2>
                <p className="text-xs text-muted-foreground whitespace-pre-wrap max-w-xs">{access.message}</p>
              </motion.div>

            ) : !activeSession ? (
              <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                className="flex-1 flex flex-col items-center justify-center p-6 text-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h2 className="text-base font-semibold mb-1">Hello! I'm Study AI 👋</h2>
                  <p className="text-xs text-muted-foreground max-w-xs">Ask me anything in Hindi, English, or Hinglish</p>
                </div>
                <div className="flex flex-wrap gap-1.5 justify-center">
                  {['📐 Math', '🔬 Science', '📖 English', '💻 Coding', '📝 NCERT', '🎯 MCQs'].map(s => (
                    <button key={s} onClick={() => setInputValue(`Help me with ${s.split(' ')[1]}`)}
                      className="px-2.5 py-1 rounded-full text-xs border border-border/50 hover:bg-primary/8 hover:border-primary/40 transition-colors">
                      {s}
                    </button>
                  ))}
                </div>
              </motion.div>

            ) : messagesLoading ? (
              <div className="flex-1 overflow-y-auto p-3">
                {Array(4).fill(0).map((_, i) => <ShimmerMessage key={i} right={i % 2 !== 0} />)}
              </div>

            ) : (
              <div
                ref={scrollAreaRef}
                className="flex-1 overflow-y-auto px-3 py-3"
                style={{ scrollBehavior: 'smooth', overscrollBehavior: 'contain' }}
                onScroll={e => {
                  const el = e.currentTarget;
                  setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 100);
                }}
              >
                <div className="space-y-0.5 max-w-2xl mx-auto">
                  {messages.map((msg, idx) => {
                    const isStreaming = msg.id === streamingMessageId;
                    const displayContent = isStreaming ? streamingText : msg.content;
                    const isHighlighted = !!convSearch && searchMatches[convSearchIdx] === idx;

                    return (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.2, ease: 'easeOut' }}
                        className={cn('flex mb-1.5', msg.role === 'user' ? 'justify-end' : 'justify-start')}
                      >
                        {msg.role === 'assistant' && (
                          <div className="w-5 h-5 rounded-md bg-primary/15 flex items-center justify-center shrink-0 mt-1 mr-1.5">
                            <Sparkles className="w-3 h-3 text-primary" />
                          </div>
                        )}
                        <div className="flex flex-col max-w-[75%]">
                          <div className={cn(
                            'px-3 py-2 rounded-xl text-sm leading-relaxed',
                            msg.role === 'user'
                              ? 'bg-primary text-primary-foreground rounded-br-sm'
                              : isDark
                                ? 'bg-zinc-800 text-foreground rounded-bl-sm border border-white/5'
                                : 'bg-white text-foreground rounded-bl-sm border border-border/40 shadow-sm',
                            isHighlighted && 'ring-2 ring-yellow-400'
                          )}>
                            {msg.role === 'user'
                              ? <p className="whitespace-pre-wrap break-words">{displayContent}</p>
                              : isStreaming
                                ? <StreamingText text={displayContent} />
                                : <MarkdownRenderer content={displayContent} />
                            }
                          </div>

                          {/* Inline actions — appear on hover */}
                          <div className={cn(
                            'flex items-center gap-0 mt-0.5 transition-opacity opacity-0 hover:opacity-100',
                            msg.role === 'user' ? 'justify-end' : 'justify-start'
                          )}
                            onMouseEnter={e => (e.currentTarget as HTMLElement).style.opacity = '1'}
                            onMouseLeave={e => (e.currentTarget as HTMLElement).style.opacity = '0'}
                          >
                            {[
                              { icon: Copy, tip: 'Copy', action: () => { navigator.clipboard.writeText(msg.content); toast.success('Copied'); } },
                              ...(msg.role === 'assistant' ? [{ icon: RefreshCw, tip: 'Regenerate', action: handleRegenerate }] : []),
                              ...(msg.role === 'user' ? [{ icon: Edit2, tip: 'Edit & resend', action: () => setInputValue(msg.content) }] : []),
                              {
                                icon: Share2, tip: 'Share', action: async () => {
                                  if (navigator.share) { try { await navigator.share({ text: msg.content }); } catch {} }
                                  else { navigator.clipboard.writeText(msg.content); toast.info('Copied to clipboard'); }
                                }
                              },
                              { icon: Trash2, tip: 'Delete', action: () => handleDeleteMessage(msg.id) },
                            ].map(({ icon: Icon, tip, action }) => (
                              <Tooltip key={tip}>
                                <TooltipTrigger asChild>
                                  <button onClick={action}
                                    className="p-1 rounded text-muted-foreground hover:text-foreground transition-colors">
                                    <Icon className="w-3 h-3" />
                                  </button>
                                </TooltipTrigger>
                                <TooltipContent>{tip}</TooltipContent>
                              </Tooltip>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}

                  {/* Typing indicator */}
                  <AnimatePresence>
                    {isLoading && !streamingMessageId && (
                      <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                        className="flex items-start gap-1.5 mb-1.5">
                        <div className="w-5 h-5 rounded-md bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
                          <Sparkles className="w-3 h-3 text-primary" />
                        </div>
                        <div className={cn('px-3 py-2 rounded-xl rounded-bl-sm',
                          isDark ? 'bg-zinc-800 border border-white/5' : 'bg-white border border-border/40 shadow-sm')}>
                          <TypingDots />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Continue after stop */}
                  <AnimatePresence>
                    {isStopped && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex justify-center mb-1">
                        <button onClick={() => handleSend('continue')}
                          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary border border-border/50 rounded-full px-3 py-1 hover:border-primary/40 transition-all">
                          <RotateCcw className="w-3 h-3" /> Continue
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div ref={messagesEndRef} />
                </div>
              </div>
            )}

            {/* Scroll to bottom */}
            <AnimatePresence>
              {showScrollBtn && (
                <motion.button initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.85 }}
                  className="absolute bottom-3 right-3 w-7 h-7 rounded-full bg-background border border-border shadow-md flex items-center justify-center hover:bg-muted z-10"
                  onClick={() => { scrollToBottom(); setShowScrollBtn(false); }}>
                  <ArrowDown className="w-3.5 h-3.5" />
                </motion.button>
              )}
            </AnimatePresence>
          </div>

          {/* Input area */}
          <div className="flex-none pt-1.5">
            {/* Model indicator bar */}
            <div className="flex items-center justify-between px-1 mb-1">
              <ModelSelector configs={configs} selected={selectedModel} onSelect={c => setSelectedModel(c)} />
              {selectedModel && selectedModel.id !== defaultConfig?.id && (
                <span className="text-[10px] text-muted-foreground">Context preserved — full history sent</span>
              )}
            </div>

            {/* Input box */}
            <div className={cn(
              'flex items-end gap-2 px-3 py-2 rounded-xl border border-border/40',
              isDark ? 'bg-zinc-900/70' : 'bg-white/90',
              'shadow-sm'
            )}>
              <Textarea
                ref={textareaRef}
                value={inputValue}
                onChange={e => setInputValue(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (canSend) handleSend(); } }}
                placeholder="Ask Study AI anything..."
                disabled={isLoading || !activeConfig || !access.allowed}
                rows={1}
                className="flex-1 resize-none border-0 bg-transparent p-0 text-sm leading-relaxed focus-visible:ring-0 focus-visible:ring-offset-0 min-h-[22px] max-h-[120px]"
              />

              {/* Stop / Send */}
              {isLoading && streamingMessageId ? (
                <button onClick={handleStop}
                  className="w-7 h-7 shrink-0 rounded-lg border border-border/50 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors mb-0.5">
                  <Square className="w-3 h-3" />
                </button>
              ) : (
                <button onClick={() => handleSend()} disabled={!canSend}
                  className={cn(
                    'w-7 h-7 shrink-0 rounded-lg flex items-center justify-center transition-all mb-0.5',
                    canSend
                      ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                      : 'bg-muted text-muted-foreground cursor-not-allowed'
                  )}>
                  {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default StudyAI;
