import { Link, useLocation } from "react-router-dom";
import PageMeta from "@/components/common/PageMeta";
import { useAuth } from "@/contexts/AuthContext";

export default function NotFound() {
  const { profile } = useAuth();
  const location = useLocation();
  const isPortalRoute = location.pathname.startsWith('/admin') || 
                        location.pathname.startsWith('/teacher') || 
                        location.pathname.startsWith('/student') || 
                        location.pathname.startsWith('/parent');

  const getHomeLink = () => {
    if (profile) {
      switch (profile.role) {
        case "admin": return "/admin";
        case "teacher": return "/teacher";
        case "parent": return "/parent/dashboard";
        default: return "/student";
      }
    }
    return isPortalRoute ? "/student-login" : "/";
  };

  return (
    <>
      <PageMeta title="Page Not Found" description="" />
      <div className="relative flex flex-col items-center justify-center min-h-screen p-6 overflow-hidden z-1">
        <div className="mx-auto w-full max-w-[242px] text-center sm:max-w-[472px]">
          <h1 className="mb-8 font-bold text-gray-800 text-title-md dark:text-white/90 xl:text-title-2xl">
            ERROR
          </h1>

          <img src="/images/error/404.svg" alt="404" className="dark:hidden" />
          <img
            src="/images/error/404-dark.svg"
            alt="404"
            className="hidden dark:block"
          />

          <p className="mt-10 mb-6 text-base text-gray-700 dark:text-gray-400 sm:text-lg">
            The page may have been deleted or does not exist. Please check the
            URL is correct.
          </p>

          <Link
            to={getHomeLink()}
            className="inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-5 py-3.5 text-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
          >
            {profile || isPortalRoute ? "Back to Portal Home" : "Back to Home"}
          </Link>
        </div>
        {/* <!-- Footer --> */}
        <p className="absolute text-sm text-center text-gray-500 -translate-x-1/2 bottom-6 left-1/2 dark:text-gray-400">
          &copy; {new Date().getFullYear()}
        </p>
      </div>
    </>
  );
}
