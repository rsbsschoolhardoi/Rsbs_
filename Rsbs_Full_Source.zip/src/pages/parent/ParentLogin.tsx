import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Users, User, Lock, Eye, EyeOff, CreditCard, Bell, BarChart2, ChevronLeft, Mail, Loader2, CheckCircle2 } from 'lucide-react';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { AuthBrandPanel } from '@/components/auth/AuthBrandPanel';
import { AuthFormShell } from '@/components/auth/AuthFormShell';
import { AccountPickerScreen } from '@/components/auth/AccountPickerScreen';
import { useAccountPicker } from '@/hooks/useAccountPicker';
import { useForm } from 'react-hook-form';
import type { SavedAccount } from '@/hooks/useAccountPicker';
import { Separator } from '@/components/ui/separator';

const GRADIENT = 'bg-gradient-to-br from-[hsl(24,70%,28%)] via-[hsl(26,65%,38%)] to-[hsl(30,60%,52%)]';

const ParentLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [otpEmail, setOtpEmail] = useState('');
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [isSecondaryLoginEnabled, setIsSecondaryLoginEnabled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [view, setView] = useState<'picker' | 'form' | 'reauth'>('picker');
  const [reauthAccount, setReauthAccount] = useState<SavedAccount | null>(null);
  const { signInWithUsername, signInWithGoogle, signInWithEmailOtp } = useAuth();
  const { accounts, removeAccount } = useAccountPicker('parent');

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    const { error } = await signInWithGoogle();
    if (error) { toast.error(error.message || 'Google sign-in failed'); setGoogleLoading(false); }
  };

  const handleEmailOtp = async () => {
    if (!otpEmail.includes('@')) { toast.error('Please enter a valid email address.'); return; }
    setOtpLoading(true);
    const { error } = await signInWithEmailOtp(otpEmail);
    setOtpLoading(false);
    if (error) { toast.error(error.message || 'Failed to send magic link.'); }
    else { setOtpSent(true); toast.success('Magic link sent! Check your inbox.'); }
  };

  useEffect(() => {
    api.isGlobalModuleEnabled('secondary_login_id').then(setIsSecondaryLoginEnabled);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Please enter both your Parent ID and password.');
      return;
    }
    const isEmail = username.includes('@');
    if (isEmail && !isSecondaryLoginEnabled) {
      toast.error('Email login is currently disabled. Please use your Parent ID.');
      return;
    }
    if (!isEmail && !username.startsWith('RSBSP')) {
      toast.error('Invalid Parent ID. It must start with RSBSP.');
      return;
    }
    setIsLoading(true);
    try {
      const { error } = await signInWithUsername(username, password);
      if (!error) {
        toast.success('Welcome to the Parent Portal.');
      } else {
        toast.error(error.message || 'Invalid credentials. Please try again.');
      }
    } catch {
      toast.error('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Saved account selected:
   * • Valid persisted session for this user → route to PIN (no password needed).
   * • No / expired session → fall back to inline password re-entry.
   */
  const handlePickerSelect = async (acc: SavedAccount) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user && session.user.id === acc.userId) {
      // Session active — AuthContext / RouteGuard will navigate to PIN automatically.
      return;
    }
    setReauthAccount(acc);
    setView('reauth');
  };

  const reauthForm = useForm<{ password: string }>({ defaultValues: { password: '' } });

  const onReauthSubmit = async ({ password: pw }: { password: string }) => {
    if (!reauthAccount) return;
    setIsLoading(true);
    try {
      const { error } = await signInWithUsername(reauthAccount.userId, pw);
      if (error) {
        toast.error('Incorrect password. Please try again.');
      } else {
        toast.success('Welcome back!');
      }
    } catch {
      toast.error('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (accounts.length > 0 && view === 'picker') {
    return (
      <AccountPickerScreen
        accounts={accounts}
        role="parent"
        gradientClass={GRADIENT}
        brandIcon={<Users />}
        brandTitle="Parent Portal"
        idLabel="Your Parent ID begins with RSBSP. Need access? Contact school administration."
        onSelectAccount={handlePickerSelect}
        onUseAnother={() => setView('form')}
        onRemoveAccount={removeAccount}
      />
    );
  }

  if (view === 'reauth' && reauthAccount) {
    return (
      <AuthLayout
        panel={
          <AuthBrandPanel
            gradientClass={GRADIENT}
            icon={<Users />}
            title="Parent Portal"
            tagline="Stay connected with your child's academic journey — fees, attendance, results, and more."
            features={[
              { icon: <BarChart2 />, text: 'Live attendance & progress' },
              { icon: <CreditCard />, text: 'Fee payments & statements' },
              { icon: <Bell />, text: 'School notices in real time' },
            ]}
          />
        }
      >
        <AuthFormShell
          icon={<Users />}
          heading="Confirm your password"
          subheading={`Your session for ${reauthAccount.fullName} has expired. Please enter your password to continue.`}
          footer={
            <button
              type="button"
              onClick={() => { setView('picker'); setReauthAccount(null); }}
              className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline mx-auto"
            >
              <ChevronLeft className="w-3 h-3" /> Back to accounts
            </button>
          }
        >
          <form onSubmit={reauthForm.handleSubmit(onReauthSubmit)} className="space-y-4">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/40 border border-border/50">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 ${GRADIENT}`}>
                {reauthAccount.fullName?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{reauthAccount.fullName}</p>
                <p className="text-xs font-mono text-primary truncate">{reauthAccount.verificationId}</p>
              </div>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••"
                className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-base"
                autoFocus
                {...reauthForm.register('password', { required: true })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98]"
            >
              {isLoading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                  Signing in…
                </span>
              ) : 'Continue'}
            </Button>
          </form>
        </AuthFormShell>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      panel={
        <AuthBrandPanel
          gradientClass={GRADIENT}
          icon={<Users />}
          title="Parent Portal"
          tagline="Stay connected with your child's academic journey — fees, attendance, results, and more."
          features={[
            { icon: <BarChart2 />, text: 'Live attendance & progress' },
            { icon: <CreditCard />, text: 'Fee payments & statements' },
            { icon: <Bell />, text: 'School notices in real time' },
          ]}
        />
      }
    >
      <AuthFormShell
        icon={<Users />}
        heading="Parent Sign In"
        subheading="Enter your Parent ID and password to access your child's information."
        footer={
          <div className="space-y-2 text-center">
            {accounts.length > 0 && (
              <button
                type="button"
                onClick={() => setView('picker')}
                className="text-xs font-semibold text-primary hover:underline block w-full"
              >
                ← Back to saved accounts
              </button>
            )}
            <p className="text-[11px] font-medium text-muted-foreground">
              Your Parent ID begins with <span className="font-bold text-foreground">RSBSP</span>.
              <br />Need access? Contact school administration.
            </p>
          </div>
        }
      >
        <form onSubmit={handleLogin} className="space-y-4">
          <div className="space-y-1.5">
            <label
              htmlFor="parent-username"
              className="text-xs font-semibold uppercase tracking-widest text-muted-foreground"
            >
              {isSecondaryLoginEnabled ? 'Parent ID or Email' : 'Parent ID'}
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                id="parent-username"
                placeholder={isSecondaryLoginEnabled ? 'RSBSP1001 or parent@email.com' : 'RSBSP + your number'}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="pl-10 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                autoComplete="username"
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label
              htmlFor="parent-password"
              className="text-xs font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                id="parent-password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                autoComplete="current-password"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98] mt-2"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                Signing in…
              </span>
            ) : (
              'Sign In to Parent Portal'
            )}
          </Button>

          {/* ── Divider ── */}
          <div className="flex items-center gap-3 py-1">
            <Separator className="flex-1" />
            <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">or</span>
            <Separator className="flex-1" />
          </div>

          {/* ── Google OAuth ── */}
          <Button
            type="button"
            variant="outline"
            disabled={googleLoading}
            onClick={handleGoogleSignIn}
            className="w-full h-12 rounded-xl font-bold border-border gap-2"
          >
            {googleLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
            )}
            Continue with Google
          </Button>

          {/* ── Email Magic Link ── */}
          {!otpSent ? (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  type="email"
                  placeholder="Email for magic link"
                  value={otpEmail}
                  onChange={e => setOtpEmail(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleEmailOtp(); }}}
                  className="pl-9 h-12 bg-muted/40 rounded-xl text-sm"
                />
              </div>
              <Button type="button" variant="outline" disabled={otpLoading} onClick={handleEmailOtp} className="h-12 px-4 rounded-xl font-bold shrink-0">
                {otpLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Link'}
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-400 text-sm font-medium">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              Magic link sent! Check your inbox.
              <button type="button" className="ml-auto text-xs underline" onClick={() => setOtpSent(false)}>Resend</button>
            </div>
          )}
        </form>
      </AuthFormShell>
    </AuthLayout>
  );
};

export default ParentLogin;
