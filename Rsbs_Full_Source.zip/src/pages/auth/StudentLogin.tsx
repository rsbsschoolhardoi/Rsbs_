import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { BookOpen, User, Lock, Eye, EyeOff, Calendar, Trophy, Bell, ChevronLeft, Mail, Loader2, CheckCircle2 } from 'lucide-react';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { AuthBrandPanel } from '@/components/auth/AuthBrandPanel';
import { AuthFormShell } from '@/components/auth/AuthFormShell';
import { AccountPickerScreen } from '@/components/auth/AccountPickerScreen';
import { useAccountPicker } from '@/hooks/useAccountPicker';
import type { SavedAccount } from '@/hooks/useAccountPicker';
import { Separator } from '@/components/ui/separator';

const GRADIENT = 'bg-gradient-to-br from-[hsl(158,60%,22%)] via-[hsl(160,55%,32%)] to-[hsl(165,50%,44%)]';

const formSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

export default function StudentLogin() {
  const { signInWithUsername, signOut, checkAuthStatus, signInWithGoogle, signInWithEmailOtp } = useAuth();
  const { accounts, removeAccount } = useAccountPicker('student');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [otpEmail, setOtpEmail] = useState('');
  const [otpLoading, setOtpLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [isSecondaryLoginEnabled, setIsSecondaryLoginEnabled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  // 'picker' = account picker, 'form' = full login, 'reauth' = password fallback for expired session
  const [view, setView] = useState<'picker' | 'form' | 'reauth'>('picker');
  // The account that needs re-authentication (session expired)
  const [reauthAccount, setReauthAccount] = useState<SavedAccount | null>(null);

  useEffect(() => {
    const clearState = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) signOut();
    };
    clearState();
    api.isGlobalModuleEnabled('secondary_login_id').then(setIsSecondaryLoginEnabled);
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { username: '', password: '' },
  });

  const handleGoogleSignIn = async () => {
    setGoogleLoading(true);
    const { error } = await signInWithGoogle();
    if (error) { toast.error(error.message || 'Google sign-in failed'); setGoogleLoading(false); }
  };

  const handleEmailOtp = async () => {
    if (!otpEmail.includes('@')) { toast.error('Please enter a valid email address.'); return; }
    setOtpLoading(true);
    const { error } = await signInWithEmailOtp(otpEmail);
    setOtpLoading(false);
    if (error) { toast.error(error.message || 'Failed to send magic link.'); }
    else { setOtpSent(true); toast.success('Magic link sent! Check your inbox.'); }
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    const isEmail = values.username.includes('@');
    if (isEmail && !isSecondaryLoginEnabled) {
      toast.error('Email login is currently disabled. Please use your Student ID.');
      return;
    }
    if (!isEmail && !/^RSBS\d+$/.test(values.username)) {
      toast.error('Invalid Student ID format (must be RSBS + Digits)');
      return;
    }
    setLoading(true);
    try {
      const { error } = await signInWithUsername(values.username, values.password);
      if (error) {
        toast.error('Invalid Login ID or Password');
      } else {
        toast.success('Successfully logged in');
      }
    } catch {
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Saved account selected:
   * 1. Check if a valid Supabase session already exists for this user.
   * 2. If yes → AuthContext will route to PIN automatically (no password needed).
   * 3. If no  → show inline password re-entry (session expired / revoked).
   */
  const handlePickerSelect = async (acc: SavedAccount) => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user && session.user.id === acc.userId) {
      // Valid session exists — AuthContext handles the rest (PIN route).
      // Force a small navigation event so AuthContext re-evaluates the status.
      // The onAuthStateChange listener in AuthContext will pick up the persisted session.
      // Nothing to do here — the user is already logged in; routeguard handles PIN redirect.
      return;
    }
    // Session expired or missing — fall back to password re-entry for this account.
    setReauthAccount(acc);
    setView('reauth');
  };

  /** Re-auth form submit (session expired fallback) */
  const reauthForm = useForm<{ password: string }>({
    defaultValues: { password: '' },
  });

  const onReauthSubmit = async ({ password }: { password: string }) => {
    if (!reauthAccount) return;
    setLoading(true);
    try {
      const { error } = await signInWithUsername(reauthAccount.userId, password);
      if (error) {
        toast.error('Incorrect password. Please try again.');
      } else {
        toast.success('Welcome back!');
      }
    } catch {
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  // Show Account Picker
  if (accounts.length > 0 && view === 'picker') {
    return (
      <AccountPickerScreen
        accounts={accounts}
        role="student"
        gradientClass={GRADIENT}
        brandIcon={<BookOpen />}
        brandTitle="Student Portal"
        idLabel="No account? Contact school administration to get your Student ID."
        onSelectAccount={handlePickerSelect}
        onUseAnother={() => setView('form')}
        onRemoveAccount={removeAccount}
      />
    );
  }

  // Re-auth view — session expired, need password for this specific account
  if (view === 'reauth' && reauthAccount) {
    return (
      <AuthLayout
        panel={
          <AuthBrandPanel
            gradientClass={GRADIENT}
            icon={<BookOpen />}
            title="Student Portal"
            tagline="Access your grades, timetable, notices, and everything you need for school."
            features={[
              { icon: <Calendar />, text: 'Live timetable & attendance' },
              { icon: <Trophy />, text: 'Exam results & reports' },
              { icon: <Bell />, text: 'Instant school notices' },
            ]}
          />
        }
      >
        <AuthFormShell
          icon={<BookOpen />}
          heading="Confirm your password"
          subheading={`Your session for ${reauthAccount.fullName} has expired. Please enter your password to continue.`}
          footer={
            <button
              type="button"
              onClick={() => { setView('picker'); setReauthAccount(null); }}
              className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline mx-auto"
            >
              <ChevronLeft className="w-3 h-3" /> Back to accounts
            </button>
          }
        >
          <form onSubmit={reauthForm.handleSubmit(onReauthSubmit)} className="space-y-4">
            {/* Read-only account chip */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/40 border border-border/50">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0 ${GRADIENT}`}>
                {reauthAccount.fullName?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '?'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-foreground truncate">{reauthAccount.fullName}</p>
                <p className="text-xs font-mono text-primary truncate">{reauthAccount.verificationId}</p>
              </div>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••"
                className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-base"
                autoFocus
                {...reauthForm.register('password', { required: true })}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98]"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                  Verifying…
                </span>
              ) : 'Continue'}
            </Button>
          </form>
        </AuthFormShell>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      panel={
        <AuthBrandPanel
          gradientClass={GRADIENT}
          icon={<BookOpen />}
          title="Student Portal"
          tagline="Access your grades, timetable, notices, and everything you need for school."
          features={[
            { icon: <Calendar />, text: 'Live timetable & attendance' },
            { icon: <Trophy />, text: 'Exam results & reports' },
            { icon: <Bell />, text: 'Instant school notices' },
          ]}
        />
      }
    >
      <AuthFormShell
        icon={<BookOpen />}
        heading="Student Sign In"
        subheading="Enter your school-provided Student ID and password to continue."
        footer={
          <div className="space-y-2 text-center">
            {accounts.length > 0 && (
              <button
                type="button"
                onClick={() => setView('picker')}
                className="text-xs font-semibold text-primary hover:underline block w-full"
              >
                ← Back to saved accounts
              </button>
            )}
            <p className="text-[11px] font-medium text-muted-foreground">
              No account? Contact school administration to get your Student ID.
            </p>
          </div>
        }
      >
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    {isSecondaryLoginEnabled ? 'Student ID or Email' : 'Student ID'}
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <Input
                        placeholder={isSecondaryLoginEnabled ? 'RSBS1001 or email@school.edu' : 'RSBS + your number'}
                        className="pl-10 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                        autoComplete="username"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    Password
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••••"
                        className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                        autoComplete="current-password"
                        {...field}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(v => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98] mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                  Verifying…
                </span>
              ) : (
                'Sign In to Student Portal'
              )}
            </Button>

            {/* ── Divider ── */}
            <div className="flex items-center gap-3 py-1">
              <Separator className="flex-1" />
              <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">or</span>
              <Separator className="flex-1" />
            </div>

            {/* ── Google OAuth ── */}
            <Button
              type="button"
              variant="outline"
              disabled={googleLoading}
              onClick={handleGoogleSignIn}
              className="w-full h-12 rounded-xl font-bold border-border gap-2"
            >
              {googleLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : (
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
              )}
              Continue with Google
            </Button>

            {/* ── Email Magic Link ── */}
            {!otpSent ? (
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  <Input
                    type="email"
                    placeholder="Email for magic link"
                    value={otpEmail}
                    onChange={e => setOtpEmail(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); handleEmailOtp(); }}}
                    className="pl-9 h-12 bg-muted/40 rounded-xl text-sm"
                  />
                </div>
                <Button type="button" variant="outline" disabled={otpLoading} onClick={handleEmailOtp} className="h-12 px-4 rounded-xl font-bold shrink-0">
                  {otpLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send Link'}
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-400 text-sm font-medium">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                Magic link sent! Check your inbox.
                <button type="button" className="ml-auto text-xs underline" onClick={() => setOtpSent(false)}>Resend</button>
              </div>
            )}
          </form>
        </Form>
      </AuthFormShell>
    </AuthLayout>
  );
}
