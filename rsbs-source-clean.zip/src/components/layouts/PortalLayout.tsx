import { useLocation, Outlet, Navigate, Link } from 'react-router-dom';
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { BottomNav } from "./BottomNav";
import { Separator } from "@/components/ui/separator";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { motion, AnimatePresence } from "motion/react";
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from '@/components/ui/button';
import { Bell, User, LogOut, Settings } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

interface PortalLayoutProps {
  role: 'student' | 'teacher' | 'parent' | 'admin';
  title: string;
}

import { ROUTES } from '@/constants/routes';

export function PortalLayout({ role, title }: PortalLayoutProps) {
  const location = useLocation();
  const { profile, loading, signOut } = useAuth();

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );

  if (!profile || String(profile.role) !== String(role)) {
    const loginPath = role === 'admin' ? ROUTES.AUTH.ADMIN_LOGIN : 
                    role === 'teacher' ? ROUTES.AUTH.TEACHER_LOGIN : 
                    role === 'parent' ? ROUTES.AUTH.PARENT_LOGIN : ROUTES.AUTH.STUDENT_LOGIN;
    return <Navigate to={loginPath} replace />;
  }

  const userInitial = profile.username ? profile.username[0].toUpperCase() : 'U';

  // Helper to get routes based on role
  const getRoleRoutes = () => {
    switch(role) {
      case 'student': return ROUTES.STUDENT;
      case 'teacher': return ROUTES.TEACHER;
      case 'parent': return ROUTES.PARENT;
      default: return ROUTES.STUDENT; // Fallback
    }
  };

  const roleRoutes = getRoleRoutes();

  return (
    <SidebarProvider>
      {/* Sidebar - Desktop Only (md and up) */}
      <AppSidebar role={role === 'admin' ? 'admin' : role === 'teacher' ? 'teacher' : 'student'} /> 
      
      <SidebarInset className="pb-20 flex flex-col h-screen overflow-hidden">
        {/* Fixed Header (Requirement 1) */}
        <header className="flex h-16 shrink-0 items-center justify-between gap-2 transition-[width,height] ease-linear border-b bg-background/80 backdrop-blur-md sticky top-0 z-40 px-4">
          <div className="flex items-center gap-2">
            <div className="md:block hidden">
              <SidebarTrigger className="-ml-1" />
            </div>
            <Separator orientation="vertical" className="mr-2 h-4 md:block hidden" />
            
            {/* Desktop Breadcrumb */}
            <Breadcrumb className="md:block hidden">
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink href={`/${role}`}>
                    {title}
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>
                    {location.pathname.split('/').pop()?.charAt(0).toUpperCase()}{location.pathname.split('/').pop()?.slice(1) || 'Dashboard'}
                  </BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
            
            {/* Mobile Title View (Requirement 1) */}
            <div className="md:hidden flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
                <span className="text-white font-black text-xs">RS</span>
              </div>
              <span className="font-black text-sm uppercase tracking-[0.15em] text-primary">{title}</span>
            </div>
          </div>

          {/* User Info and Notifications (Requirement 1) */}
          <div className="flex items-center gap-2 md:gap-4">
            <Button variant="ghost" size="icon" onClick={() => {}} className="rounded-full relative hover:bg-muted active:scale-95 transition-all">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-background" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-1 h-auto rounded-full hover:bg-muted active:scale-95 transition-all border border-muted">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={profile.avatar_url || ''} />
                    <AvatarFallback className="bg-primary/10 text-primary font-black text-xs">
                      {userInitial}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 rounded-2xl p-2 mt-2">
                <DropdownMenuLabel className="p-3">
                  <p className="text-sm font-black truncate uppercase tracking-widest">{profile.username}</p>
                  <p className="text-[10px] text-muted-foreground truncate font-bold uppercase mt-0.5 tracking-wider">{role} ACCOUNT</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild className="rounded-xl p-3 cursor-pointer">
                  <Link to={(roleRoutes as any).PROFILE || `/${role}`} className="flex items-center gap-3">
                    <User className="w-4 h-4" />
                    <span className="font-bold text-xs uppercase">Profile</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild className="rounded-xl p-3 cursor-pointer">
                  <Link to={(roleRoutes as any).SETTINGS || `/${role}`} className="flex items-center gap-3">
                    <Settings className="w-4 h-4" />
                    <span className="font-bold text-xs uppercase">Settings</span>
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={() => signOut()} 
                  className="rounded-xl p-3 cursor-pointer text-destructive focus:text-destructive focus:bg-destructive/5"
                >
                  <LogOut className="w-4 h-4 mr-3" />
                  <span className="font-black text-xs uppercase tracking-widest">Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Content Area with Transitions (Requirement 1) */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar bg-slate-50/50 dark:bg-background/50 scroll-smooth">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              className="mx-auto w-full max-w-7xl p-4 md:p-10 pt-6 md:pt-10"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </SidebarInset>

      {/* Persistent Bottom Nav for all screens (Requirement 1, 5) */}
      <BottomNav role={role} />
    </SidebarProvider>
  );
}
