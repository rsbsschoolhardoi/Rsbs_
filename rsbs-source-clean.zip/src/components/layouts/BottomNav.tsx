import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, CheckCircle2, CreditCard, Megaphone, User, Clock, Search, CalendarCheck, UserPlus, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'motion/react';

import { ROUTES } from '@/constants/routes';

export function BottomNav({ role }: { role: 'admin' | 'student' | 'teacher' | 'parent' }) {
  const location = useLocation();
  const { isModuleEnabled } = useAuth();

  const studentItems = [
    { label: 'Home', icon: LayoutDashboard, url: ROUTES.STUDENT.DASHBOARD, id: 'dashboard' },
    { label: 'Attendance', icon: CheckCircle2, url: ROUTES.STUDENT.ATTENDANCE, id: 'attendance' },
    { label: 'Study AI', icon: Sparkles, url: ROUTES.STUDENT.STUDY_AI, id: 'study-ai' },
    { label: 'Fees', icon: CreditCard, url: ROUTES.STUDENT.FEES, id: 'fees' },
    { label: 'Menu', icon: User, url: ROUTES.STUDENT.MORE, id: 'more' },
  ];

  const adminItems = [
    { label: 'Home', icon: LayoutDashboard, url: ROUTES.ADMIN.DASHBOARD, id: 'dashboard' },
    { label: 'Admissions', icon: UserPlus, url: ROUTES.ADMIN.ADMISSIONS, id: 'students' },
    { label: 'Appointments', icon: CalendarCheck, url: ROUTES.ADMIN.APPOINTMENTS, id: 'queries' },
    { label: 'Notices', icon: Megaphone, url: ROUTES.ADMIN.NOTICES, id: 'notices' },
    { label: 'Search', icon: Search, url: ROUTES.ADMIN.SEARCH, id: 'dashboard' },
  ];

  const teacherItems = [
    { label: 'Dashboard', icon: LayoutDashboard, url: ROUTES.TEACHER.DASHBOARD, id: 'dashboard' },
    { label: 'Attendance', icon: CheckCircle2, url: ROUTES.TEACHER.ATTENDANCE, id: 'attendance' },
    { label: 'Timetable', icon: Clock, url: ROUTES.TEACHER.TIMETABLE, id: 'timetable' },
    { label: 'Profile', icon: User, url: ROUTES.TEACHER.PROFILE, id: 'profile' },
  ];

  const parentItems = [
    { label: 'Home', icon: LayoutDashboard, url: ROUTES.PARENT.DASHBOARD, id: 'dashboard' },
    { label: 'Attendance', icon: CheckCircle2, url: ROUTES.PARENT.ATTENDANCE, id: 'attendance' },
    { label: 'Fees', icon: CreditCard, url: ROUTES.PARENT.FEES, id: 'fees' },
    { label: 'Profile', icon: User, url: ROUTES.PARENT.PROFILE, id: 'profile' },
  ];

  const items = (role === 'student' ? studentItems : role === 'teacher' ? teacherItems : role === 'admin' ? adminItems : parentItems).filter(i => {
    if (i.id === 'profile' || i.id === 'dashboard' || i.id === 'search' || i.id === 'study-ai' || i.id === 'more') return true;
    return isModuleEnabled(i.id);
  });

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/80 backdrop-blur-lg border-t z-50 px-2 pb-safe">
      <div className="flex justify-around items-center h-16 max-w-7xl mx-auto">
        {items.map((item) => {
          const isActive = location.pathname === item.url;
          return (
            <Link
              key={item.url}
              to={item.url}
              className={cn(
                "flex flex-col items-center justify-center flex-1 h-full gap-1 transition-all duration-300 relative",
                isActive ? "text-primary scale-110" : "text-muted-foreground hover:text-primary/70"
              )}
            >
              <item.icon className={cn("w-5 h-5", isActive && "stroke-[2.5px]")} />
              <span className="text-[10px] font-bold uppercase tracking-wider">{item.label}</span>
              {isActive && (
                <motion.div 
                  layoutId="bottom-nav-indicator"
                  className="absolute top-0 w-8 h-1 bg-primary rounded-full" 
                />
              )}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
