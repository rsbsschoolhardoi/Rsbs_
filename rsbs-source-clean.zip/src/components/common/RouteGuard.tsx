import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { AuthContext } from '@/contexts/AuthContext';
import { useContext } from 'react';
import { toast } from 'sonner';

interface RouteGuardProps {
  children: React.ReactNode;
}

// Please add the pages that can be accessed without logging in to PUBLIC_ROUTES.
const PUBLIC_ROUTES = [
  '/', 
  '/gallery', 
  '/notices', 
  '/leadership', 
  '/about', 
  '/contact', 
  '/student-login', 
  '/teacher-login', 
  '/parent/login',
  '/rsbs-admin-access', 
  '/login',
  '/auth/verify',
  '/admin/verify',
  '/403', 
  '/404',
  '/verify',
  '/verify-pin',
  '/verify-otp',
  '/admin/verify-request',
];

function matchPublicRoute(path: string, patterns: string[]) {
  const normalizedPath = path.split('?')[0].replace(/\/$/, '') || '/';
  return patterns.some(pattern => {
    const normalizedPattern = pattern.split('?')[0].replace(/\/$/, '') || '/';
    if (normalizedPattern.includes('*')) {
      const regex = new RegExp('^' + normalizedPattern.replace('*', '.*') + '$');
      return regex.test(normalizedPath);
    }
    return normalizedPath === normalizedPattern;
  });
}

export function RouteGuard({ children }: RouteGuardProps) {
  const context = useContext(AuthContext);
  const user = context?.user;
  const profile = context?.profile;
  const loading = context?.loading;
  const checkAuthStatus = context?.checkAuthStatus;
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (loading || context === undefined || !checkAuthStatus) return;

    const isPublic = matchPublicRoute(location.pathname, PUBLIC_ROUTES) || location.pathname === '/verify';
    const status = checkAuthStatus();

    // 0. Restricted Accounts
    if (status === 'restricted' && !isPublic) {
      toast.error('Your account is not yet activated. Please contact the system administrator.');
      context?.signOut(); // Auto sign out
      return;
    }

    // 1. Unauthenticated Users
    if (status === 'unauthenticated' && !isPublic) {
      if (location.pathname.startsWith('/admin')) {
        navigate('/rsbs-admin-access', { replace: true });
      } else if (location.pathname.startsWith('/teacher')) {
        navigate('/teacher-login', { replace: true });
      } else if (location.pathname.startsWith('/parent')) {
        navigate('/parent/login', { replace: true });
      } else if (location.pathname.startsWith('/student')) {
        navigate('/student-login', { replace: true });
      } else {
        navigate('/', { replace: true });
      }
      return;
    }

    // 2. Authenticated Users logic
    if (user && profile) {
      const normalizedPath = location.pathname.replace(/\/$/, '') || '/';
      const isLoginRoute = normalizedPath === '/student-login' || 
                          normalizedPath === '/teacher-login' || 
                          normalizedPath === '/parent/login' ||
                          normalizedPath === '/rsbs-admin-access' || 
                          normalizedPath === '/login';

      const isVerifyPinRoute = normalizedPath === '/verify-pin';
      const isVerifyOtpRoute = normalizedPath === '/verify-otp';

      // Redirect if on login route but already logged in
      if (isLoginRoute) {
        if (profile.role === 'admin') navigate('/admin', { replace: true });
        else if (profile.role === 'teacher') navigate('/teacher', { replace: true });
        else if (profile.role === 'parent') navigate('/parent/dashboard', { replace: true });
        else navigate('/student', { replace: true });
        return;
      }

      // Sequential Verification Redirects
      if (status === 'need-verification') {
        navigate('/admin/verify-request', { replace: true });
        return;
      }

      if (status === 'need-pin' && !isVerifyPinRoute) {
        navigate('/verify-pin', { replace: true });
        return;
      }

      if (status === 'need-otp' && !isVerifyOtpRoute) {
        navigate('/verify-otp', { replace: true });
        return;
      }

      // If verified, but on a verify page, move to dashboard
      if (status === 'authenticated' && (isVerifyPinRoute || isVerifyOtpRoute)) {
        if (profile.role === 'admin') navigate('/admin', { replace: true });
        else if (profile.role === 'teacher') navigate('/teacher', { replace: true });
        else if (profile.role === 'parent') navigate('/parent/dashboard', { replace: true });
        else navigate('/student', { replace: true });
        return;
      }

      // 3. Role-based Path Protection
      if (location.pathname.startsWith('/admin') && profile.role !== 'admin') {
        navigate('/403', { replace: true });
        return;
      }

      if (location.pathname.startsWith('/student') && profile.role !== 'student') {
        navigate('/403', { replace: true });
        return;
      }

      if (location.pathname.startsWith('/teacher') && profile.role !== 'teacher') {
        navigate('/403', { replace: true });
        return;
      }

      if (location.pathname.startsWith('/parent') && profile.role !== 'parent') {
        navigate('/403', { replace: true });
        return;
      }
    }
  }, [user, profile, loading, location.pathname, navigate, checkAuthStatus]);

  const isPublic = matchPublicRoute(location.pathname, PUBLIC_ROUTES) || location.pathname === '/verify';
  const status = checkAuthStatus ? checkAuthStatus() : 'loading';

  // Strict loading control
  if (loading && !isPublic) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Prevent rendering protected content if verification is incomplete
  if (user && status !== 'authenticated' && !isPublic) {
    const normalizedPath = location.pathname.replace(/\/$/, '') || '/';
    const isVerifyPinRoute = normalizedPath === '/verify-pin';
    const isVerifyOtpRoute = normalizedPath === '/verify-otp';
    
    if (status === 'need-pin' && !isVerifyPinRoute) return null;
    if (status === 'need-otp' && !isVerifyOtpRoute) return null;
  }

  return <>{children}</>;
}
