import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldAlert, ShieldCheck, RefreshCw, KeyRound, CheckCircle2 } from 'lucide-react';

interface PINSetupProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const PINSetup: React.FC<PINSetupProps> = ({ onSuccess, onCancel }) => {
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);
  const { profile, updatePIN } = useAuth();

  const isFirstTime = !profile?.pin;
  const title = isFirstTime ? "Create Your PIN" : "Change Your PIN";
  const description = isFirstTime 
    ? "Please create a secure 4-digit PIN for your account." 
    : "Your PIN has been reset. Please choose a new secure 4-digit PIN.";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length !== 4 || isNaN(Number(newPin))) {
      toast.error('New PIN must be a 4-digit numeric code');
      return;
    }

    if (newPin !== confirmPin) {
      toast.error('New PIN and confirmation do not match');
      return;
    }

    setLoading(true);
    const { error } = await updatePIN(newPin);
    setLoading(false);

    if (error) {
      toast.error(error.message || 'Failed to update PIN');
    } else {
      toast.success('PIN successfully updated');
      onSuccess();
    }
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-primary/20 bg-card/95 backdrop-blur">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary border-4 border-primary/5 ring-8 ring-primary/5">
              <KeyRound className="w-8 h-8" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">{title}</CardTitle>
          <CardDescription>
            {description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">New PIN</label>
                <Input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="Enter 4-digit PIN"
                  className="text-center text-xl tracking-[0.8em] h-12 font-bold border-2 focus-visible:ring-primary/20"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider ml-1">Confirm New PIN</label>
                <Input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="Re-enter 4-digit PIN"
                  className="text-center text-xl tracking-[0.8em] h-12 font-bold border-2 focus-visible:ring-primary/20"
                />
              </div>
            </div>
            <Button type="submit" className="w-full h-12 text-lg font-semibold rounded-xl" disabled={loading || newPin.length !== 4 || confirmPin.length !== 4}>
              {loading ? <RefreshCw className="mr-2 h-5 w-5 animate-spin" /> : "Complete Setup"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button variant="ghost" onClick={onCancel} className="w-full text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all text-xs uppercase tracking-widest font-bold">
            Cancel & Sign Out
          </Button>
          <div className="flex items-center space-x-2 text-[10px] text-muted-foreground uppercase tracking-widest font-bold justify-center">
            <CheckCircle2 className="w-3 h-3 text-primary" />
            <span>PIN must be 4 numeric digits</span>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};
