import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { ShieldAlert, ShieldCheck, LogOut, RefreshCw } from 'lucide-react';

interface PINVerificationProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export const PINVerification: React.FC<PINVerificationProps> = ({ onSuccess, onCancel }) => {
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);
  const { verifyPIN } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length !== 4 || isNaN(Number(pin))) {
      toast.error('Please enter a valid 4-digit numeric PIN');
      return;
    }

    setLoading(true);
    const result = await verifyPIN(pin);
    setLoading(false);

    if (result.success) {
      toast.success('PIN verified successfully');
      onSuccess();
    } else {
      toast.error(result.message || 'Incorrect PIN');
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl border-primary/20 bg-card/95 backdrop-blur">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary border-4 border-primary/5 ring-8 ring-primary/5">
              <ShieldCheck className="w-8 h-8" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">Secondary Verification</CardTitle>
          <CardDescription>
            For your security, please enter your 4-digit numeric PIN to access your panel.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="password"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/[^0-9]/g, ''))}
                placeholder="Enter 4-digit PIN"
                className="text-center text-2xl tracking-[1em] h-14 font-bold border-2 focus-visible:ring-primary/20"
                autoFocus
              />
            </div>
            <Button type="submit" className="w-full h-12 text-lg font-semibold rounded-xl" disabled={loading || pin.length !== 4}>
              {loading ? <RefreshCw className="mr-2 h-5 w-5 animate-spin" /> : "Verify PIN"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button variant="ghost" onClick={onCancel} className="w-full text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all">
            <LogOut className="mr-2 h-4 w-4" /> Cancel & Logout
          </Button>
          <div className="flex items-center space-x-2 text-[10px] text-muted-foreground uppercase tracking-widest font-bold justify-center">
            <ShieldAlert className="w-3 h-3 text-primary" />
            <span>Non-negotiable security step</span>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};
