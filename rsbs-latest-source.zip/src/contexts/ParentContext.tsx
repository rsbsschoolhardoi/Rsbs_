import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { api } from '@/db/api';

interface ParentContextType {
  students: any[];
  selectedStudent: any | null;
  setSelectedStudent: (student: any) => void;
  loading: boolean;
  refreshStudents: () => Promise<void>;
}

const ParentContext = createContext<ParentContextType | undefined>(undefined);

export const ParentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { profile } = useAuth();
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshStudents = async () => {
    if (profile?.id) {
      setLoading(true);
      const { data } = await api.getParentLinkedStudents(profile.id);
      const studentList = data || [];
      setStudents(studentList);
      
      // If we have students and none is selected, or the selected one isn't in the list
      if (studentList.length > 0) {
        if (!selectedStudent || !studentList.find((s: any) => s.student_id === selectedStudent.student_id)) {
          setSelectedStudent(studentList[0]);
        }
      } else {
        setSelectedStudent(null);
      }
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshStudents();
  }, [profile?.id]);

  return (
    <ParentContext.Provider value={{ students, selectedStudent, setSelectedStudent, loading, refreshStudents }}>
      {children}
    </ParentContext.Provider>
  );
};

export const useParent = () => {
  const context = useContext(ParentContext);
  if (context === undefined) {
    throw new Error('useParent must be used within a ParentProvider');
  }
  return context;
};
