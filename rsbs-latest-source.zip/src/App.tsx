import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { AuthProvider, AuthContext } from '@/contexts/AuthContext';
import { LanguageProvider } from '@/contexts/LanguageContext';
import { RouteGuard } from '@/components/common/RouteGuard';
import { ThemeProvider } from '@/components/common/ThemeProvider';
import { ThemeSync } from '@/components/common/ThemeSync';
import { PublicSettingsProvider } from '@/contexts/PublicSettingsContext';

// Layouts
const PublicLayoutIsolated = lazy(() => import('@/components/layouts/PublicLayoutIsolated'));
import AdminLayout from '@/components/layouts/AdminLayout';
import StudentLayout from '@/components/layouts/StudentLayout';
import TeacherLayout from '@/components/layouts/TeacherLayout';
import ParentLayout from '@/components/layouts/ParentLayout';

// Pages
const AdminLogin = lazy(() => import('@/pages/auth/AdminLogin'));
const VerificationRequest = lazy(() => import('@/pages/auth/VerificationRequest'));
const Verify = lazy(() => import('@/pages/auth/Verify'));
const AdminVerify = Verify; // Reuse the same component for /admin/verify
const Home = lazy(() => import('@/pages/public/Home'));
const PublicNotices = lazy(() => import('@/pages/public/Notices'));
const PublicLeadership = lazy(() => import('@/pages/public/Leadership'));
const PublicAbout = lazy(() => import('@/pages/public/About'));
const PublicContact = lazy(() => import('@/pages/public/Contact'));
const Gallery = lazy(() => import('@/pages/public/Gallery'));
const VerifyStudent = lazy(() => import('@/pages/public/VerifyStudent'));
const ChatInterfacePage = lazy(() => import('@/pages/public/ChatInterfacePage'));
const ApiConfigPage = lazy(() => import('@/pages/public/ApiConfigPage'));

const StudentLogin = lazy(() => import('@/pages/auth/StudentLogin'));
const AdminResetPassword = lazy(() => import('@/pages/auth/AdminResetPassword'));
const StudentVerifyOTP = lazy(() => import('@/pages/auth/StudentVerifyOTP'));
const StudentDashboard = lazy(() => import('@/pages/student/Dashboard'));
const AdminDashboard = lazy(() => import('@/pages/admin/Dashboard'));
const Classes = lazy(() => import('@/pages/admin/Classes'));
const Students = lazy(() => import('@/pages/admin/Students'));
const Alumni = lazy(() => import('@/pages/admin/Alumni'));
const Fees = lazy(() => import('@/pages/admin/Fees'));
const Attendance = lazy(() => import('@/pages/admin/Attendance'));
const Exams = lazy(() => import('@/pages/admin/Exams'));
const Notices = lazy(() => import('@/pages/admin/Notices'));
const AdminGallery = lazy(() => import('@/pages/admin/Gallery'));
const Templates = lazy(() => import('@/pages/admin/Templates'));
const AdminManagement = lazy(() => import('@/pages/admin/AdminManagement'));
const SchoolHome = lazy(() => import('@/pages/admin/SchoolHome'));
const AdminQueries = lazy(() => import('@/pages/admin/Queries'));
const AdminAdmissions = lazy(() => import('@/pages/admin/AdminAdmissions'));
const AdminAppointments = lazy(() => import('@/pages/admin/AdminAppointments'));
const AdminSearch = lazy(() => import('@/pages/admin/AdminSearch'));
const CertificateGenerator = lazy(() => import('@/pages/admin/CertificateGenerator'));
const BrandingSettings = lazy(() => import('@/pages/admin/BrandingSettings'));
const Timetable = lazy(() => import('@/pages/admin/Timetable'));
const AiManagement = lazy(() => import('@/pages/admin/AiManagement'));
const SystemBackup = lazy(() => import('@/pages/admin/SystemBackup'));
const ApiManagement = lazy(() => import('@/pages/admin/api-management/ApiManagement'));
const LoginIntegration = lazy(() => import('@/pages/admin/LoginIntegration'));
const StudentTimetable = lazy(() => import('@/pages/student/Timetable'));
const TeacherTimetable = lazy(() => import('@/pages/teacher/Timetable'));
const StudentAttendance = lazy(() => import('@/pages/student/Attendance'));
const StudentFees = lazy(() => import('@/pages/student/Fees'));
const StudentExams = lazy(() => import('@/pages/student/Exams'));
const StudentNotices = lazy(() => import('@/pages/student/Notices'));
const StudentGallery = lazy(() => import('@/pages/student/Gallery'));
const StudentMore = lazy(() => import('@/pages/student/More'));
const StudentQueries = lazy(() => import('@/pages/student/Queries'));
const StudentStudyAI = lazy(() => import('@/pages/student/StudyAI'));
const StudentVerifyPIN = lazy(() => import('@/pages/auth/StudentVerifyPIN'));
const TeacherLogin = lazy(() => import('@/pages/auth/TeacherLogin'));
const TeacherDashboard = lazy(() => import('@/pages/teacher/Dashboard'));
const MarkAttendance = lazy(() => import('@/pages/teacher/MarkAttendance'));
const TeacherProfile = lazy(() => import('@/pages/teacher/Profile'));
const TeacherAttendance = lazy(() => import('@/pages/teacher/Attendance'));
const TeacherNotices = lazy(() => import('@/pages/teacher/Notices'));
const TeacherQueries = lazy(() => import('@/pages/teacher/Queries'));
const Teachers = lazy(() => import('@/pages/admin/Teachers'));
const Parents = lazy(() => import('@/pages/admin/Parents'));
const ParentDetail = lazy(() => import('@/pages/admin/ParentDetail'));
const ParentLogin = lazy(() => import('@/pages/parent/ParentLogin'));
const ParentDashboard = lazy(() => import('@/pages/parent/ParentDashboard'));
const ParentFees = lazy(() => import('@/pages/parent/ParentFees'));
const ParentAttendance = lazy(() => import('@/pages/parent/ParentAttendance'));
const ParentProfile = lazy(() => import('@/pages/parent/ParentProfile'));
const ParentMore = lazy(() => import('@/pages/parent/ParentMore'));
const Forbidden = lazy(() => import('@/pages/Forbidden'));
const NotFound = lazy(() => import('@/pages/NotFound'));
import { useLocation } from 'react-router-dom';

const PATH_PERMISSIONS: Record<string, string> = {
  '/admin': 'dashboard',
  '/admin/': 'dashboard',
  '/admin/classes': 'classes',
  '/admin/school-home': 'school_home',
  '/admin/students': 'students',
  '/admin/alumni': 'students',
  '/admin/fees': 'fees',
  '/admin/attendance': 'attendance',
  '/admin/timetable': 'timetable',
  '/admin/exams': 'exams',
  '/admin/notices': 'notices',
  '/admin/queries': 'queries',
  '/admin/gallery': 'gallery',
  '/admin/certificates': 'certificates',
  '/admin/templates': 'templates',
  '/admin/branding': 'certificates',
  '/admin/ai-management': 'dashboard',
  '/admin/backup': 'system_backup',
  '/admin/api-management': 'api_management',
  '/admin/admin-management': 'admin_management',
  '/admin/admissions': 'students',
  '/admin/appointments': 'queries',
  '/admin/search': 'dashboard',
  '/admin/login-integration': 'admin_management',
  '/admin/teachers': 'teachers',
  '/admin/parents': 'parents',
  '/admin/parents/': 'parents',
  '/teacher/attendance': 'attendance',
  '/teacher/timetable': 'timetable',
  '/teacher/notices': 'notices',
  '/teacher/queries': 'queries',
};

const PermissionGuard: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const context = React.useContext(AuthContext);
  const profile = context?.profile;
  const isModuleEnabled = context?.isModuleEnabled;
  const location = useLocation();

  const path = location.pathname;
  const requiredPermission = PATH_PERMISSIONS[path];

  if (context === undefined) return <>{children}</>;

  // Master Admin Priority Bypass (Requirement 5)
  if (profile?.is_master) return <>{children}</>;

  if (requiredPermission && profile?.role === 'admin') {
    // Check global module status
    if (requiredPermission !== 'admin_management' && isModuleEnabled && !isModuleEnabled(requiredPermission)) {
      return <Navigate to="/404" replace />;
    }

    // Requirements update: Granular permission control for Master Admin accounts.
    // Permissions are toggled individually and persist as the source of truth.
    if (profile?.permissions?.includes(requiredPermission)) return <>{children}</>;
    
    // Special case for Admin Management which now holds Admissions and Appointments
    if (requiredPermission === 'admin_management') {
      if (profile?.permissions?.includes('students') || profile?.permissions?.includes('queries')) {
        return <>{children}</>;
      }
    }

    return <Navigate to="/403" replace />;
  }

  // Handle student module routes
  if (path.startsWith('/student/') && isModuleEnabled && profile?.role === 'student') {
    const studentModuleId = path.split('/')[2];
    if (studentModuleId && studentModuleId !== '' && studentModuleId !== 'more' && studentModuleId !== 'study-ai' && !isModuleEnabled(studentModuleId)) {
      return <Navigate to="/404" replace />;
    }
  }

  // Handle teacher module routes
  if (path.startsWith('/teacher/') && isModuleEnabled && profile?.role === 'teacher') {
    const teacherModuleId = path.split('/')[2];
    if (teacherModuleId && teacherModuleId !== '' && teacherModuleId !== 'profile' && !isModuleEnabled(teacherModuleId)) {
      return <Navigate to="/404" replace />;
    }
  }

  return <>{children}</>;
};

const RedirectToDefault: React.FC = () => {
  const context = React.useContext(AuthContext);
  const profile = context?.profile;

  if (!profile) return <Navigate to="/" replace />;
  if (profile.role === 'admin') return <Navigate to="/admin" replace />;
  if (profile.role === 'student') return <Navigate to="/student" replace />;
  if (profile.role === 'teacher') return <Navigate to="/teacher" replace />;
  if (profile.role === 'parent') return <Navigate to="/parent/dashboard" replace />;
  return <Navigate to="/" replace />;
};

const App: React.FC = () => {
  return (
    <Router>
      <ThemeProvider
          attribute="class"
          storageKey="theme"
          defaultTheme={localStorage.getItem('theme') ?? 'light'}
          enableSystem={false}
        >
        <AuthProvider>
          <LanguageProvider>
            <ThemeSync />
            <RouteGuard>
              <IntersectObserver />
              <Suspense fallback={
                <div className="flex items-center justify-center min-h-screen">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              }>
              <Routes>
                <Route path="/verify" element={<VerifyStudent />} />
                {/* Public Section - Isolated via UI and Provider */}
                <Route element={<PublicSettingsProvider><PublicLayoutIsolated /></PublicSettingsProvider>}>
                  <Route index element={<Home />} />
                  <Route path="gallery" element={<Gallery />} />
                  <Route path="api-config" element={<ApiConfigPage />} />
                  <Route path="ai-chat" element={<ChatInterfacePage />} />
                  <Route path="notices" element={<PublicNotices />} />
                  <Route path="leadership" element={<PublicLeadership />} />
                  <Route path="about" element={<PublicAbout />} />

                  <Route path="contact" element={<PublicContact />} />
                </Route>


                {/* Auth Section */}
                <Route path="student-login" element={<StudentLogin />} />
                <Route path="teacher-login" element={<TeacherLogin />} />
                <Route path="parent/login" element={<ParentLogin />} />
                <Route path="rsbs-admin-access" element={<AdminLogin />} />
                <Route path="admin/verify-request" element={<VerificationRequest />} />
                <Route path="admin/verify" element={<AdminVerify />} />
                <Route path="admin/reset-password" element={<AdminResetPassword />} />
                <Route path="auth/verify" element={<Verify />} />
                <Route path="verify-pin" element={<StudentVerifyPIN />} />
                <Route path="verify-otp" element={<StudentVerifyOTP />} />

                {/* Parent Portal */}
                <Route path="parent" element={<PermissionGuard><ParentLayout /></PermissionGuard>}>
                  <Route index element={<Navigate to="dashboard" replace />} />
                  <Route path="dashboard" element={<ParentDashboard />} />
                  <Route path="attendance" element={<ParentAttendance />} />
                  <Route path="fees" element={<ParentFees />} />
                  <Route path="profile" element={<ParentProfile />} />
                  <Route path="more" element={<ParentMore />} />
                </Route>

                {/* Admin Panel */}
                <Route path="admin" element={<PermissionGuard><AdminLayout /></PermissionGuard>}>
                  <Route index element={<AdminDashboard />} />
                  <Route path="classes" element={<Classes />} />
                  <Route path="school-home" element={<SchoolHome />} />
                  <Route path="students" element={<Students />} />
                  <Route path="alumni" element={<Alumni />} />
                  <Route path="teachers" element={<Teachers />} />
                  <Route path="parents" element={<Parents />} />
                  <Route path="parents/:id" element={<ParentDetail />} />
                  <Route path="fees" element={<Fees />} />
                  <Route path="attendance" element={<Attendance />} />
                  <Route path="timetable" element={<Timetable />} />
                  <Route path="exams" element={<Exams />} />
                  <Route path="notices" element={<Notices />} />
                  <Route path="queries" element={<AdminQueries />} />
                  <Route path="gallery" element={<AdminGallery />} />
                  <Route path="templates" element={<Templates />} />
                  <Route path="certificates" element={<CertificateGenerator />} />
                  <Route path="branding" element={<BrandingSettings />} />
                  <Route path="ai-management" element={<AiManagement />} />
                  <Route path="backup" element={<SystemBackup />} />
                  <Route path="api-management" element={<ApiManagement />} />
                  <Route path="admin-management" element={<AdminManagement />} />
                  <Route path="admissions" element={<AdminAdmissions />} />
                  <Route path="appointments" element={<AdminAppointments />} />
                  <Route path="search" element={<AdminSearch />} />
                  <Route path="login-integration" element={<LoginIntegration />} />
                </Route>

                {/* Student Portal */}
                <Route path="student" element={<PermissionGuard><StudentLayout /></PermissionGuard>}>
                  <Route index element={<StudentDashboard />} />
                  <Route path="attendance" element={<StudentAttendance />} />
                  <Route path="timetable" element={<StudentTimetable />} />
                  <Route path="study-ai" element={<StudentStudyAI />} />
                  <Route path="fees" element={<StudentFees />} />
                  <Route path="exams" element={<StudentExams />} />
                  <Route path="notices" element={<StudentNotices />} />
                  <Route path="gallery" element={<StudentGallery />} />
                  <Route path="queries" element={<StudentQueries />} />
                  <Route path="more" element={<StudentMore />} />
                  <Route path="verify-pin" element={<StudentVerifyPIN />} />
                </Route>

                {/* Teacher Portal */}
                <Route path="teacher" element={<PermissionGuard><TeacherLayout /></PermissionGuard>}>
                  <Route index element={<TeacherDashboard />} />
                  <Route path="attendance" element={<TeacherAttendance />} />
                  <Route path="timetable" element={<TeacherTimetable />} />
                  <Route path="notices" element={<TeacherNotices />} />
                  <Route path="queries" element={<TeacherQueries />} />
                  <Route path="profile" element={<TeacherProfile />} />
                  <Route path="mark-attendance/:classId/:sectionId" element={<MarkAttendance />} />
                </Route>

                {/* Errors */}
                <Route path="403" element={<Forbidden />} />
                <Route path="404" element={<NotFound />} />
                <Route path="*" element={<RedirectToDefault />} />
              </Routes>
            </Suspense>
            <Toaster />
          </RouteGuard>
          </LanguageProvider>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
};

export default App;
