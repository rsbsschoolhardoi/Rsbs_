export type PlaceholderCategory = 
  | 'Student Data'
  | 'School Branding'
  | 'Authority & Validation'
  | 'Admission Details'
  | 'Certificate Data'
  | 'Academic Results'
  | 'General System';

export type PlaceholderDataType = 'String' | 'Date' | 'Image URL' | 'Number';

export interface PlaceholderMetadata {
  key: string;
  label: string;
  category: PlaceholderCategory;
  dataType: PlaceholderDataType;
  description: string;
  fallback: string;
}

export const DOCUMENT_PLACEHOLDERS: PlaceholderMetadata[] = [
  // Student Data
  {
    key: '{{student_full_name}}',
    label: 'Student Full Name',
    category: 'Student Data',
    dataType: 'String',
    description: 'The complete legal name of the student.',
    fallback: '[Student Name Not Found]'
  },
  {
    key: '{{student_verification_id}}',
    label: 'Student Verification ID',
    category: 'Student Data',
    dataType: 'String',
    description: 'Unique identifier assigned by the school.',
    fallback: '[ID Not Found]'
  },
  {
    key: '{{student_class}}',
    label: 'Student Class',
    category: 'Student Data',
    dataType: 'String',
    description: 'Current grade level of the student.',
    fallback: '[Class Not Found]'
  },
  {
    key: '{{student_section}}',
    label: 'Student Section',
    category: 'Student Data',
    dataType: 'String',
    description: 'Assigned classroom section.',
    fallback: '[Section Not Found]'
  },
  {
    key: '{{academic_session}}',
    label: 'Academic Session',
    category: 'Student Data',
    dataType: 'String',
    description: 'Current academic year (e.g., 2024-2025).',
    fallback: '[Session Not Found]'
  },
  {
    key: '{{date_of_birth}}',
    label: 'Date of Birth',
    category: 'Student Data',
    dataType: 'Date',
    description: 'Student DOB formatted as DD/MM/YYYY.',
    fallback: '[DOB Not Found]'
  },
  {
    key: '{{student_roll_number}}',
    label: 'Student Roll Number',
    category: 'Student Data',
    dataType: 'String',
    description: 'Assigned classroom roll number.',
    fallback: ''
  },

  // School Branding & Information
  {
    key: '{{school_official_name}}',
    label: 'School Official Name',
    category: 'School Branding',
    dataType: 'String',
    description: 'Full official registered name of the school.',
    fallback: '[School Name Not Found]'
  },
  {
    key: '{{school_logo_url}}',
    label: 'School Logo URL',
    category: 'School Branding',
    dataType: 'Image URL',
    description: 'Public URL to the school official logo.',
    fallback: ''
  },
  {
    key: '{{school_complete_address}}',
    label: 'School Complete Address',
    category: 'School Branding',
    dataType: 'String',
    description: 'Full registered address of the school.',
    fallback: '[Address Not Found]'
  },
  {
    key: '{{school_contact_phone}}',
    label: 'School Contact Phone',
    category: 'School Branding',
    dataType: 'String',
    description: 'Primary contact number of the school.',
    fallback: ''
  },
  {
    key: '{{school_contact_email}}',
    label: 'School Contact Email',
    category: 'School Branding',
    dataType: 'String',
    description: 'Primary official email of the school.',
    fallback: ''
  },

  // Authority & Validation
  {
    key: '{{principal_full_name}}',
    label: 'Principal Full Name',
    category: 'Authority & Validation',
    dataType: 'String',
    description: 'Full name of the current school principal.',
    fallback: '[Principal Name Not Found]'
  },
  {
    key: '{{principal_signature_image_url}}',
    label: 'Principal Signature URL',
    category: 'Authority & Validation',
    dataType: 'Image URL',
    description: 'Public URL to the scanned principal signature.',
    fallback: ''
  },
  {
    key: '{{school_official_seal_image_url}}',
    label: 'School Official Seal URL',
    category: 'Authority & Validation',
    dataType: 'Image URL',
    description: 'Public URL to the official school stamp/seal.',
    fallback: ''
  },

  // Admission Details
  {
    key: '{{admission_reference_number}}',
    label: 'Admission Ref. Number',
    category: 'Admission Details',
    dataType: 'String',
    description: 'Unique reference code for the admission application.',
    fallback: '[Ref No. Not Found]'
  },
  {
    key: '{{admission_date}}',
    label: 'Admission Date',
    category: 'Admission Details',
    dataType: 'Date',
    description: 'Date of admission formatted as DD/MM/YYYY.',
    fallback: '[Date Not Found]'
  },

  // Certificate-Specific Data
  {
    key: '{{certificate_title}}',
    label: 'Certificate Title',
    category: 'Certificate Data',
    dataType: 'String',
    description: 'Title of the certificate (e.g., Certificate of Merit).',
    fallback: 'Certificate'
  },
  {
    key: '{{certificate_issue_date}}',
    label: 'Certificate Issue Date',
    category: 'Certificate Data',
    dataType: 'Date',
    description: 'Date when the certificate was issued (DD/MM/YYYY).',
    fallback: '[Issue Date Not Found]'
  },

  // Academic Result Data
  {
    key: '{{marks_obtained}}',
    label: 'Marks Obtained',
    category: 'Academic Results',
    dataType: 'Number',
    description: 'Total marks secured by the student.',
    fallback: '0'
  },
  {
    key: '{{marks_total}}',
    label: 'Total Marks',
    category: 'Academic Results',
    dataType: 'Number',
    description: 'Maximum possible marks for the exam.',
    fallback: '100'
  },
  {
    key: '{{grade_awarded}}',
    label: 'Grade Awarded',
    category: 'Academic Results',
    dataType: 'String',
    description: 'Letter grade awarded (e.g., A+, B).',
    fallback: '[Grade Not Found]'
  },
  {
    key: '{{overall_result_status}}',
    label: 'Overall Result Status',
    category: 'Academic Results',
    dataType: 'String',
    description: 'Status (e.g., Pass, Promoted, Distinction).',
    fallback: '[Status Not Found]'
  },

  // General System Data
  {
    key: '{{document_generation_date}}',
    label: 'Generation Date',
    category: 'General System',
    dataType: 'Date',
    description: 'Auto-populated system date (DD/MM/YYYY).',
    fallback: '[Current Date]'
  }
];

export const getPlaceholderByKey = (key: string) => 
  DOCUMENT_PLACEHOLDERS.find(p => p.key === key);

export const getPlaceholdersByCategory = () => {
  const categories: Record<PlaceholderCategory, PlaceholderMetadata[]> = {
    'Student Data': [],
    'School Branding': [],
    'Authority & Validation': [],
    'Admission Details': [],
    'Certificate Data': [],
    'Academic Results': [],
    'General System': []
  };
  
  DOCUMENT_PLACEHOLDERS.forEach(p => {
    categories[p.category].push(p);
  });
  
  return categories;
};

/**
 * INTEGRATION & VALIDATION RULES:
 * 
 * 1. Template Editor (Frontend):
 *    - Uses DOCUMENT_PLACEHOLDERS to populate selection dropdowns.
 *    - Metadata (label, description) helps administrators choose correct variables.
 * 
 * 2. Data Backend / Edge Functions:
 *    - When generating a document, the backend identifies all placeholders used in the template.
 *    - A "Replacement Dictionary" is created by mapping placeholder keys to database fields.
 *    - Example: {{student_full_name}} -> student.first_name + ' ' + student.last_name
 * 
 * 3. Fallback Behavior:
 *    - If a data source for a placeholder is missing, the `fallback` value from metadata is used.
 *    - For critical data (names, IDs), a clearly visible error string is used (e.g., [Data Not Found]).
 *    - For non-critical data (emails, roll numbers), it may fallback to an empty string.
 * 
 * 4. Data Types & Formatting:
 *    - String: Used directly as plain text.
 *    - Date: Formatted as DD/MM/YYYY by the backend before replacement.
 *    - Image URL: Rendered as an image element by the PDF generator.
 *    - Number: Converted to string for display.
 */
