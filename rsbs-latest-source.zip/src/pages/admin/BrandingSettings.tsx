import { useState, useEffect } from 'react';
import { api } from '@/db/api';
import { BrandingSettings } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { Settings, Save, Building2, UserCircle, Stamp, Loader2, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/db/supabase';

const brandingSchema = z.object({
  school_name: z.string().min(2, 'School name is required'),
  principal_name: z.string().min(2, 'Principal name is required'),
  school_logo_url: z.string().optional(),
  principal_signature_url: z.string().optional(),
  school_seal_url: z.string().optional(),
});

type BrandingFormValues = z.infer<typeof brandingSchema>;

export default function BrandingSettingsPage() {
  const [settings, setSettings] = useState<BrandingSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState<string | null>(null);

  const form = useForm<BrandingFormValues>({
    resolver: zodResolver(brandingSchema),
    defaultValues: {
      school_name: '',
      principal_name: '',
      school_logo_url: '',
      principal_signature_url: '',
      school_seal_url: '',
    },
  });

  const fetchData = async () => {
    setLoading(true);
    const { data } = await api.getBrandingSettings();
    if (data) {
      setSettings(data);
      form.reset({
        school_name: data.school_name,
        principal_name: data.principal_name,
        school_logo_url: data.school_logo_url || '',
        principal_signature_url: data.principal_signature_url || '',
        school_seal_url: data.school_seal_url || '',
      });
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: keyof BrandingFormValues) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(field);
    try {
      let fileToUpload = file;

      // Special handling for School Logo validation and preprocessing
      if (field === 'school_logo_url') {
        const reader = new FileReader();
        const base64Promise = new Promise<string>((resolve) => {
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
        const base64 = await base64Promise;

        const { data: preprocessData, error: preprocessError } = await supabase.functions.invoke('preprocess-logo', {
          body: { imageBase64: base64 }
        });

        if (preprocessError) {
          const errorMsg = await preprocessError.context?.text() || preprocessError.message;
          throw new Error(errorMsg);
        }

        if (preprocessData?.error) {
          throw new Error(preprocessData.error);
        }

        if (preprocessData?.success && preprocessData?.processedImage) {
          // Convert base64 back to Blob for storage upload
          const resp = await fetch(preprocessData.processedImage);
          const blob = await resp.blob();
          fileToUpload = new File([blob], `processed-logo-${Date.now()}.png`, { type: 'image/png' });
          toast.info(preprocessData.message || 'Logo preprocessed to meet standards');
        }
      }

      const fileExt = fileToUpload.name.split('.').pop();
      const fileName = `${field}-${Math.random()}.${fileExt}`;
      const filePath = `branding/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('app_aho9bv0iqbr5_school_images')
        .upload(filePath, fileToUpload);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('app_aho9bv0iqbr5_school_images')
        .getPublicUrl(filePath);

      form.setValue(field, publicUrl);
      toast.success('Image uploaded successfully');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Failed to upload image');
    } finally {
      setUploading(null);
    }
  };

  const onSubmit = async (values: BrandingFormValues) => {
    if (!settings) return;
    try {
      const { error } = await api.updateBrandingSettings(settings.id, values);
      if (error) throw error;
      toast.success('Branding settings updated successfully');
      fetchData();
    } catch (error: any) {
      toast.error(error.message || 'Failed to update settings');
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
      <p className="text-muted-foreground animate-pulse">Loading settings...</p>
    </div>
  );

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3 text-primary">
          <Settings className="w-8 h-8" />
          School Branding Settings
        </h1>
        <p className="text-muted-foreground mt-1">Configure global assets for certificates and official documents.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="rounded-3xl border-none shadow-sm bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl font-bold">
                <Building2 className="w-5 h-5 text-primary" />
                Basic School Information
              </CardTitle>
              <CardDescription>Main identification details of the institution.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="school_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-bold">School Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter school name" className="h-11 rounded-xl" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="school_logo_url"
                render={() => (
                  <FormItem className="space-y-3">
                    <FormLabel className="font-bold">School Logo</FormLabel>
                    <div className="flex flex-col md:flex-row md:items-start gap-4 p-4 rounded-2xl bg-muted/30 border border-dashed">
                      <div className="w-24 h-24 rounded-2xl border overflow-hidden bg-background flex items-center justify-center p-2 shrink-0 shadow-inner">
                        {form.watch('school_logo_url') ? (
                          <img src={form.watch('school_logo_url')} alt="Logo Preview" className="max-w-full max-h-full object-contain" />
                        ) : (
                          <Building2 className="w-8 h-8 text-muted-foreground opacity-20" />
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="relative">
                          <Input 
                            type="file" 
                            accept="image/*" 
                            className="h-11 rounded-xl cursor-pointer file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                            onChange={(e) => handleFileUpload(e, 'school_logo_url')} 
                            disabled={!!uploading}
                          />
                          {uploading === 'school_logo_url' && (
                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                              <Loader2 className="w-4 h-4 animate-spin text-primary" />
                            </div>
                          )}
                        </div>
                        <p className="text-xs font-bold text-primary flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Strict Standard: 800x600px (4:3 ratio) PNG with transparent background.
                        </p>
                        <p className="text-xs text-muted-foreground">System will automatically resize and center high-resolution images to match template standards (min 150 DPI).</p>
                      </div>
                    </div>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-none shadow-sm bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl font-bold">
                <UserCircle className="w-5 h-5 text-primary" />
                Principal & Authority
              </CardTitle>
              <CardDescription>Authentication details for certificates.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="principal_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-bold">Principal Name</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter principal name" className="h-11 rounded-xl" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="principal_signature_url"
                render={() => (
                  <FormItem className="space-y-3">
                    <FormLabel className="font-bold">Principal Digital Signature</FormLabel>
                    <div className="flex flex-col md:flex-row md:items-start gap-4 p-4 rounded-2xl bg-muted/30 border border-dashed">
                      <div className="w-32 h-16 rounded-2xl border overflow-hidden bg-background flex items-center justify-center p-2 shrink-0 shadow-inner">
                        {form.watch('principal_signature_url') ? (
                          <img src={form.watch('principal_signature_url')} alt="Signature Preview" className="max-w-full max-h-full object-contain" />
                        ) : (
                          <Save className="w-6 h-6 text-muted-foreground opacity-20" />
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="relative">
                          <Input 
                            type="file" 
                            accept="image/*" 
                            className="h-11 rounded-xl cursor-pointer file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                            onChange={(e) => handleFileUpload(e, 'principal_signature_url')} 
                            disabled={!!uploading}
                          />
                          {uploading === 'principal_signature_url' && (
                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                              <Loader2 className="w-4 h-4 animate-spin text-primary" />
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">Recommended: Horizontal PNG with transparent background.</p>
                      </div>
                    </div>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-none shadow-sm bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl font-bold">
                <Stamp className="w-5 h-5 text-primary" />
                Official Seal
              </CardTitle>
              <CardDescription>Optional school seal for document validation.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="school_seal_url"
                render={() => (
                  <FormItem className="space-y-3">
                    <FormLabel className="font-bold">School Seal (Image)</FormLabel>
                    <div className="flex flex-col md:flex-row md:items-start gap-4 p-4 rounded-2xl bg-muted/30 border border-dashed">
                      <div className="w-24 h-24 rounded-2xl border overflow-hidden bg-background flex items-center justify-center p-2 shrink-0 shadow-inner">
                        {form.watch('school_seal_url') ? (
                          <img src={form.watch('school_seal_url')} alt="Seal Preview" className="max-w-full max-h-full object-contain" />
                        ) : (
                          <Stamp className="w-8 h-8 text-muted-foreground opacity-20" />
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="relative">
                          <Input 
                            type="file" 
                            accept="image/*" 
                            className="h-11 rounded-xl cursor-pointer file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                            onChange={(e) => handleFileUpload(e, 'school_seal_url')} 
                            disabled={!!uploading}
                          />
                          {uploading === 'school_seal_url' && (
                            <div className="absolute right-3 top-1/2 -translate-y-1/2">
                              <Loader2 className="w-4 h-4 animate-spin text-primary" />
                            </div>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">Optional: Circular PNG/SVG with transparent background.</p>
                      </div>
                    </div>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end pt-4">
            <Button type="submit" size="lg" className="h-12 px-10 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-primary/20 active:scale-95 transition-all">
              <Save className="w-5 h-5 mr-2" />
              Update Branding
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
