import { useEffect, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ModuleApiActivity from '@/components/admin/ModuleApiActivity';
import { api } from '@/db/api';
import { Student, FeeDetail } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { Search, Edit, CreditCard, Plus, Trash2 } from 'lucide-react';

const feeSchema = z.object({
  fee_status: z.enum(['Paid', 'Pending', 'Overdue']),
  fee_details: z.array(z.object({
    id: z.string(),
    amount: z.coerce.number().min(0),
    description: z.string().min(1, 'Description is required'),
    due_date: z.string().min(1, 'Due date is required'),
  })),
});

import { getLocalDateString } from '@/lib/utils';

export default function Fees() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const form = useForm<z.infer<typeof feeSchema>>({
    resolver: zodResolver(feeSchema),
    defaultValues: {
      fee_status: 'Pending',
      fee_details: [],
    },
  });

  const fetchStudents = async () => {
    setLoading(true);
    const { data } = await api.getStudents();
    setStudents(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const handleEditFees = (student: Student) => {
    setEditingStudent(student);
    form.reset({
      fee_status: student.fee_status,
      fee_details: Array.isArray(student.fee_details) ? student.fee_details : [],
    });
    setIsDialogOpen(true);
  };

  const onSubmit = async (values: z.infer<typeof feeSchema>) => {
    if (!editingStudent) return;
    try {
      const { error } = await api.updateStudent(editingStudent.id, {
        fee_status: values.fee_status,
        fee_details: values.fee_details,
      });
      if (error) throw error;
      toast.success('Fees updated successfully');
      setIsDialogOpen(false);
      fetchStudents();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const addFeeLine = () => {
    const current = form.getValues('fee_details');
    form.setValue('fee_details', [
      ...current,
      { id: Math.random().toString(36).substr(2, 9), amount: 0, description: '', due_date: getLocalDateString() }
    ]);
  };

  const removeFeeLine = (id: string) => {
    const current = form.getValues('fee_details');
    form.setValue('fee_details', current.filter(f => f.id !== id));
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.login_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Fee Management</h1>
        <p className="text-muted-foreground">Manage student fee records, status, and due dates.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-4 w-4" />
        <Input 
          placeholder="Search students..." 
          className="pl-10" 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="border rounded-lg bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Student</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Total Fee Count</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Loading fee records...</TableCell>
              </TableRow>
            ) : filteredStudents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No records found.</TableCell>
              </TableRow>
            ) : (
              filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.name}</TableCell>
                  <TableCell>{student.class} - {student.section}</TableCell>
                  <TableCell>{student.fee_details?.length || 0} entries</TableCell>
                  <TableCell>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      student.fee_status === 'Paid' ? 'bg-green-100 text-green-700' : 
                      student.fee_status === 'Pending' ? 'bg-amber-100 text-amber-700' : 
                      'bg-red-100 text-red-700'
                    }`}>
                      {student.fee_status}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" onClick={() => handleEditFees(student)}>
                      <CreditCard className="w-4 h-4 mr-2" /> Manage Fees
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Fees: {editingStudent?.name}</DialogTitle>
            <DialogDescription>Update fee status and detailed records.</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 py-4">
              <FormField
                control={form.control}
                name="fee_status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Overall Fee Status</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Paid">Paid</SelectItem>
                        <SelectItem value="Pending">Pending</SelectItem>
                        <SelectItem value="Overdue">Overdue</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-sm">Fee Breakdown</h3>
                  <Button type="button" variant="outline" size="sm" onClick={addFeeLine}>
                    <Plus className="w-4 h-4 mr-2" /> Add Item
                  </Button>
                </div>
                
                {form.watch('fee_details').map((fee, index) => (
                  <div key={fee.id} className="grid grid-cols-1 md:grid-cols-4 gap-3 p-3 border rounded-lg bg-muted/30 relative">
                    <FormField
                      control={form.control}
                      name={`fee_details.${index}.description`}
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel className="text-xs">Description</FormLabel>
                          <FormControl><Input placeholder="e.g. Tuition Fee Q1" {...field} /></FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`fee_details.${index}.amount`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs">Amount (₹)</FormLabel>
                          <FormControl><Input type="number" {...field} /></FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name={`fee_details.${index}.due_date`}
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-xs">Due Date</FormLabel>
                          <FormControl><Input type="date" {...field} /></FormControl>
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-destructive text-white hover:bg-destructive/80"
                      onClick={() => removeFeeLine(fee.id)}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
                {form.watch('fee_details').length === 0 && (
                  <p className="text-sm text-center text-muted-foreground py-4 border border-dashed rounded-lg">No fee items added yet.</p>
                )}
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit">Save Fee Records</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
