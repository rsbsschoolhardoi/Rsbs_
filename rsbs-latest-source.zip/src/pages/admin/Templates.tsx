import { useEffect, useState } from 'react';
import { api } from '@/db/api';
import { DocumentTemplate, TemplateElement } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Edit2, 
  Save, 
  Layout, 
  PanelTop as HeaderIcon, 
  PanelBottom as FooterIcon, 
  Type, 
  Database,
  ArrowLeft,
  Settings2,
  X,
  CheckCircle2,
  Layers,
  Search
} from 'lucide-react';
import { toast } from 'sonner';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue,
  SelectGroup,
  SelectLabel 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import { DOCUMENT_PLACEHOLDERS, getPlaceholdersByCategory, getPlaceholderByKey } from '@/constants/placeholders';

const CATEGORIZED_PLACEHOLDERS = getPlaceholdersByCategory();

export default function Templates() {
  const [templates, setTemplates] = useState<DocumentTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingTemplate, setEditingTemplate] = useState<DocumentTemplate | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states for new/editing template
  const [name, setName] = useState('');
  const [type, setType] = useState<DocumentTemplate['type']>('Certificate');
  const [headerEnabled, setHeaderEnabled] = useState(true);
  const [bodyEnabled, setBodyEnabled] = useState(true);
  const [footerEnabled, setFooterEnabled] = useState(true);
  const [headerElements, setHeaderElements] = useState<TemplateElement[]>([]);
  const [bodyElements, setBodyElements] = useState<TemplateElement[]>([]);
  const [footerElements, setFooterElements] = useState<TemplateElement[]>([]);

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    setLoading(true);
    const { data, error } = await api.getDocumentTemplates();
    if (error) {
      toast.error('Failed to fetch templates');
    } else {
      setTemplates(data || []);
    }
    setLoading(false);
  };

  const handleCreate = () => {
    setEditingTemplate(null);
    setName('');
    setType('Certificate');
    setHeaderEnabled(true);
    setBodyEnabled(true);
    setFooterEnabled(true);
    setHeaderElements([]);
    setBodyElements([]);
    setFooterElements([]);
    setIsEditorOpen(true);
  };

  const handleEdit = (template: DocumentTemplate) => {
    setEditingTemplate(template);
    setName(template.name);
    setType(template.type);
    setHeaderEnabled(template.layout_config.header_enabled);
    setBodyEnabled(template.layout_config.body_enabled);
    setFooterEnabled(template.layout_config.footer_enabled);
    setHeaderElements(template.content_config.header);
    setBodyElements(template.content_config.body);
    setFooterElements(template.content_config.footer);
    setIsEditorOpen(true);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      toast.error('Template name is required');
      return;
    }

    const templateData = {
      name,
      type,
      layout_config: {
        header_enabled: headerEnabled,
        body_enabled: bodyEnabled,
        footer_enabled: footerEnabled
      },
      content_config: {
        header: headerElements,
        body: bodyElements,
        footer: footerElements
      }
    };

    if (editingTemplate) {
      const { error } = await api.updateDocumentTemplate(editingTemplate.id, templateData);
      if (error) {
        toast.error('Failed to update template: ' + error.message);
      } else {
        toast.success('Template updated successfully');
        setIsEditorOpen(false);
        fetchTemplates();
      }
    } else {
      const { error } = await api.createDocumentTemplate(templateData);
      if (error) {
        toast.error('Failed to create template: ' + error.message);
      } else {
        toast.success('Template created successfully');
        setIsEditorOpen(false);
        fetchTemplates();
      }
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await api.deleteDocumentTemplate(deleteId);
    if (error) {
      toast.error('Failed to delete template');
    } else {
      toast.success('Template deleted successfully');
      fetchTemplates();
    }
    setDeleteId(null);
  };

  const addElement = (section: 'header' | 'body' | 'footer', elementType: 'static' | 'dynamic') => {
    const newElement: TemplateElement = {
      id: Math.random().toString(36).substr(2, 9),
      type: elementType,
      text: elementType === 'static' ? 'New Text' : '',
      placeholder: elementType === 'dynamic' ? DOCUMENT_PLACEHOLDERS[0].key : '',
      x: 0,
      y: 0
    };

    if (section === 'header') setHeaderElements([...headerElements, newElement]);
    else if (section === 'body') setBodyElements([...bodyElements, newElement]);
    else if (section === 'footer') setFooterElements([...footerElements, newElement]);
  };

  const updateElement = (section: 'header' | 'body' | 'footer', id: string, updates: Partial<TemplateElement>) => {
    const mapper = (el: TemplateElement) => el.id === id ? { ...el, ...updates } : el;
    if (section === 'header') setHeaderElements(headerElements.map(mapper));
    else if (section === 'body') setBodyElements(bodyElements.map(mapper));
    else if (section === 'footer') setFooterElements(footerElements.map(mapper));
  };

  const removeElement = (section: 'header' | 'body' | 'footer', id: string) => {
    if (section === 'header') setHeaderElements(headerElements.filter(el => el.id !== id));
    else if (section === 'body') setBodyElements(bodyElements.filter(el => el.id !== id));
    else if (section === 'footer') setFooterElements(footerElements.filter(el => el.id !== id));
  };

  const filteredTemplates = templates.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isEditorOpen) {
    return (
      <div className="space-y-6 max-w-6xl mx-auto pb-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => setIsEditorOpen(false)} className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-2xl font-black text-primary uppercase tracking-tighter">
                {editingTemplate ? 'Edit Template' : 'Create Template'}
              </h1>
              <p className="text-sm text-muted-foreground font-medium italic">Configure layout and content for your school documents.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => setIsEditorOpen(false)} className="font-bold">Cancel</Button>
            <Button onClick={handleSave} className="font-black px-8 bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 rounded-xl">
              <Save className="w-4 h-4 mr-2" />
              Save Template
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Panel: Settings */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-none shadow-xl rounded-[2rem] overflow-hidden">
              <CardHeader className="bg-primary/5 border-b border-primary/10">
                <CardTitle className="text-sm font-black uppercase tracking-widest text-primary flex items-center gap-2">
                  <Settings2 className="w-4 h-4" />
                  General Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Template Name</Label>
                  <Input 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    placeholder="e.g., Merit Certificate 2026"
                    className="rounded-xl border-none bg-muted/50 h-11 font-medium"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Document Type</Label>
                  <Select value={type} onValueChange={(v: any) => setType(v)}>
                    <SelectTrigger className="rounded-xl border-none bg-muted/50 h-11 font-medium">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl border-none shadow-2xl">
                      <SelectItem value="Certificate">Certificate</SelectItem>
                      <SelectItem value="ID Card">ID Card</SelectItem>
                      <SelectItem value="Admission Certificate">Admission Certificate</SelectItem>
                      <SelectItem value="Result">Result</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl rounded-[2rem] overflow-hidden">
              <CardHeader className="bg-primary/5 border-b border-primary/10">
                <CardTitle className="text-sm font-black uppercase tracking-widest text-primary flex items-center gap-2">
                  <Layout className="w-4 h-4" />
                  Layout Sections
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
                  <div className="flex items-center gap-3">
                    <HeaderIcon className="w-4 h-4 text-primary" />
                    <span className="text-sm font-bold">Header Section</span>
                  </div>
                  <Switch checked={headerEnabled} onCheckedChange={setHeaderEnabled} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
                  <div className="flex items-center gap-3">
                    <Layers className="w-4 h-4 text-primary" />
                    <span className="text-sm font-bold">Body Section</span>
                  </div>
                  <Switch checked={bodyEnabled} onCheckedChange={setBodyEnabled} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl bg-muted/30">
                  <div className="flex items-center gap-3">
                    <FooterIcon className="w-4 h-4 text-primary" />
                    <span className="text-sm font-bold">Footer Section</span>
                  </div>
                  <Switch checked={footerEnabled} onCheckedChange={setFooterEnabled} />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel: Content Editor */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="header" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-muted/50 p-1 rounded-2xl h-14 border mb-6">
                <TabsTrigger value="header" disabled={!headerEnabled} className="rounded-xl font-bold flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-lg">
                  <HeaderIcon className="w-4 h-4" /> Header
                </TabsTrigger>
                <TabsTrigger value="body" disabled={!bodyEnabled} className="rounded-xl font-bold flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-lg">
                  <Layers className="w-4 h-4" /> Body
                </TabsTrigger>
                <TabsTrigger value="footer" disabled={!footerEnabled} className="rounded-xl font-bold flex items-center gap-2 data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-lg">
                  <FooterIcon className="w-4 h-4" /> Footer
                </TabsTrigger>
              </TabsList>

              <TabsContent value="header">
                <SectionEditor 
                  section="header" 
                  elements={headerElements} 
                  onAdd={addElement} 
                  onUpdate={updateElement} 
                  onRemove={removeElement} 
                />
              </TabsContent>
              <TabsContent value="body">
                <SectionEditor 
                  section="body" 
                  elements={bodyElements} 
                  onAdd={addElement} 
                  onUpdate={updateElement} 
                  onRemove={removeElement} 
                />
              </TabsContent>
              <TabsContent value="footer">
                <SectionEditor 
                  section="footer" 
                  elements={footerElements} 
                  onAdd={addElement} 
                  onUpdate={updateElement} 
                  onRemove={removeElement} 
                />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12 px-4 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl md:text-4xl font-black text-primary uppercase tracking-tighter flex items-center gap-3">
            <FileText className="w-10 h-10" />
            Document Templates
          </h1>
          <p className="text-muted-foreground font-medium italic mt-1 ml-1">Manage and design school certificates, ID cards, and reports.</p>
        </div>
        <Button onClick={handleCreate} className="h-12 px-8 font-black bg-primary hover:bg-primary/90 shadow-xl shadow-primary/20 rounded-2xl transition-all active:scale-95">
          <Plus className="w-5 h-5 mr-2" />
          Create New Template
        </Button>
      </div>

      <div className="relative group">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
        <Input 
          placeholder="Search templates by name or type..." 
          className="h-14 pl-12 rounded-2xl border-none bg-muted/40 font-medium text-lg shadow-inner"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 rounded-[2rem] bg-muted/20 animate-pulse border-2 border-dashed border-muted" />
          ))}
        </div>
      ) : filteredTemplates.length === 0 ? (
        <Card className="border-2 border-dashed border-muted bg-transparent rounded-[3rem] py-20 text-center">
          <CardContent className="space-y-4">
            <div className="w-20 h-20 bg-muted/20 rounded-full flex items-center justify-center mx-auto">
              <FileText className="w-10 h-10 text-muted-foreground" />
            </div>
            <div className="space-y-1">
              <p className="text-xl font-black text-muted-foreground uppercase tracking-tight">No Templates Found</p>
              <p className="text-sm text-muted-foreground italic font-medium">Start by creating a new document template.</p>
            </div>
            <Button variant="outline" onClick={handleCreate} className="mt-4 rounded-xl font-bold">
              <Plus className="w-4 h-4 mr-2" />
              Add Your First Template
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map(template => (
            <Card key={template.id} className="group border-none shadow-xl hover:shadow-2xl transition-all duration-300 rounded-[2rem] overflow-hidden flex flex-col hover:-translate-y-1 bg-background">
              <div className={`h-3 bg-gradient-to-r ${
                template.type === 'Certificate' ? 'from-amber-400 to-orange-500' :
                template.type === 'ID Card' ? 'from-blue-400 to-indigo-500' :
                template.type === 'Result' ? 'from-emerald-400 to-teal-500' :
                'from-primary to-primary-glow'
              }`} />
              <CardHeader className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <Badge variant="outline" className="mb-2 rounded-lg font-black uppercase tracking-widest text-[10px] bg-muted/50 text-muted-foreground border-none">
                      {template.type}
                    </Badge>
                    <CardTitle className="text-xl font-black text-primary leading-tight group-hover:text-primary-glow transition-colors">
                      {template.name}
                    </CardTitle>
                  </div>
                  <div className="p-3 bg-muted/30 rounded-2xl">
                    <FileText className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="px-6 py-2 flex-grow">
                <div className="grid grid-cols-3 gap-2">
                  <LayoutBadge label="Header" enabled={template.layout_config.header_enabled} />
                  <LayoutBadge label="Body" enabled={template.layout_config.body_enabled} />
                  <LayoutBadge label="Footer" enabled={template.layout_config.footer_enabled} />
                </div>
                <div className="mt-4 p-3 bg-muted/20 rounded-xl flex items-center justify-between">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Elements</span>
                  <span className="text-xs font-bold font-mono">
                    {template.content_config.header.length + template.content_config.body.length + template.content_config.footer.length} Items
                  </span>
                </div>
              </CardContent>
              <CardFooter className="p-6 bg-muted/10 border-t border-muted/20 grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={() => handleEdit(template)} className="rounded-xl font-bold hover:bg-background h-10">
                  <Edit2 className="w-4 h-4 mr-2" /> Edit
                </Button>
                <Button variant="destructive" onClick={() => setDeleteId(template.id)} className="rounded-xl font-bold bg-destructive/10 text-destructive hover:bg-destructive hover:text-white transition-all border-none h-10 shadow-sm shadow-destructive/20">
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent className="rounded-[2rem] border-none shadow-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-2xl font-black text-destructive uppercase tracking-tighter">Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground font-medium italic">
              This action cannot be undone. This will permanently delete the template and remove it from the system.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2 sm:gap-0 mt-4">
            <AlertDialogCancel className="rounded-xl font-bold border-none bg-muted hover:bg-muted/80">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="rounded-xl font-black bg-destructive hover:bg-destructive/90 shadow-lg shadow-destructive/20">
              Delete Forever
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SectionEditor({ section, elements, onAdd, onUpdate, onRemove }: any) {
  return (
    <Card className="border-none shadow-xl rounded-[2rem] overflow-hidden bg-background">
      <CardHeader className="p-6 border-b flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-sm font-black uppercase tracking-widest text-primary flex items-center gap-2 italic">
            <Type className="w-4 h-4" />
            {section} Content
          </CardTitle>
          <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-1">Add and position elements</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => onAdd(section, 'static')} className="rounded-xl font-bold h-9">
            <Plus className="w-4 h-4 mr-1" /> Static Text
          </Button>
          <Button size="sm" variant="secondary" onClick={() => onAdd(section, 'dynamic')} className="rounded-xl font-bold h-9 bg-primary/10 text-primary hover:bg-primary/20">
            <Database className="w-4 h-4 mr-1" /> Placeholder
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {elements.length === 0 ? (
          <div className="py-12 text-center text-muted-foreground bg-muted/10 rounded-3xl border-2 border-dashed border-muted/50">
            <Plus className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-xs font-bold uppercase tracking-widest opacity-50">No elements in this section</p>
          </div>
        ) : (
          <div className="space-y-4">
            {elements.map((el: TemplateElement) => (
              <div key={el.id} className="p-4 rounded-2xl bg-muted/30 border border-muted flex flex-col md:flex-row items-start md:items-center gap-4 animate-in slide-in-from-left-4 duration-300">
                <div className={`p-2 rounded-lg ${el.type === 'static' ? 'bg-amber-500/10 text-amber-600' : 'bg-primary/10 text-primary'}`}>
                  {el.type === 'static' ? <Type className="w-4 h-4" /> : <Database className="w-4 h-4" />}
                </div>
                <div className="flex-grow grid grid-cols-1 md:grid-cols-4 gap-4 w-full">
                  <div className="md:col-span-2">
                    {el.type === 'static' ? (
                      <Input 
                        value={el.text} 
                        onChange={(e) => onUpdate(section, el.id, { text: e.target.value })} 
                        placeholder="Enter static text"
                        className="rounded-xl border-none bg-background h-10 font-medium"
                      />
                    ) : (
                      <div className="space-y-1">
                        <Select value={el.placeholder} onValueChange={(v) => onUpdate(section, el.id, { placeholder: v })}>
                          <SelectTrigger className="rounded-xl border-none bg-background h-10 font-medium">
                            <SelectValue placeholder="Select placeholder" />
                          </SelectTrigger>
                          <SelectContent className="rounded-xl border-none shadow-2xl max-h-[400px]">
                            {Object.entries(CATEGORIZED_PLACEHOLDERS).map(([category, items]) => (
                              <SelectGroup key={category}>
                                <SelectLabel className="px-2 py-1.5 text-[10px] font-black uppercase tracking-widest text-primary bg-primary/5 rounded-md my-1 mx-1">
                                  {category}
                                </SelectLabel>
                                {items.map(p => (
                                  <SelectItem key={p.key} value={p.key} title={p.description}>
                                    <div className="flex flex-col py-0.5">
                                      <span className="font-bold text-sm tracking-tight">{p.label}</span>
                                      <span className="text-[10px] text-muted-foreground font-mono opacity-70">{p.key}</span>
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectGroup>
                            ))}
                          </SelectContent>
                        </Select>
                        {el.placeholder && (
                          <div className="flex items-center gap-1.5 px-2">
                             <span className="text-[9px] font-medium text-muted-foreground italic truncate max-w-full">
                               {getPlaceholderByKey(el.placeholder)?.description}
                             </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] font-black uppercase text-muted-foreground">X</Label>
                    <Input 
                      type="number" 
                      value={el.x} 
                      onChange={(e) => onUpdate(section, el.id, { x: parseInt(e.target.value) || 0 })} 
                      className="rounded-xl border-none bg-background h-10 w-16 text-center font-mono"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] font-black uppercase text-muted-foreground">Y</Label>
                    <Input 
                      type="number" 
                      value={el.y} 
                      onChange={(e) => onUpdate(section, el.id, { y: parseInt(e.target.value) || 0 })} 
                      className="rounded-xl border-none bg-background h-10 w-16 text-center font-mono"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] font-black uppercase text-muted-foreground">W</Label>
                    <Input 
                      type="number" 
                      value={el.width || 0} 
                      onChange={(e) => onUpdate(section, el.id, { width: parseInt(e.target.value) || 0 })} 
                      className="rounded-xl border-none bg-background h-10 w-16 text-center font-mono"
                      placeholder="Auto"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] font-black uppercase text-muted-foreground">H</Label>
                    <Input 
                      type="number" 
                      value={el.height || 0} 
                      onChange={(e) => onUpdate(section, el.id, { height: parseInt(e.target.value) || 0 })} 
                      className="rounded-xl border-none bg-background h-10 w-16 text-center font-mono"
                      placeholder="Auto"
                    />
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => onRemove(section, el.id)} className="text-destructive hover:bg-destructive/10 rounded-xl">
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function LayoutBadge({ label, enabled }: { label: string, enabled: boolean }) {
  return (
    <div className={`flex flex-col items-center gap-1 p-2 rounded-xl border transition-all ${
      enabled ? 'bg-primary/5 border-primary/20 text-primary' : 'bg-muted/30 border-muted text-muted-foreground opacity-50'
    }`}>
      {enabled ? <CheckCircle2 className="w-3 h-3" /> : <X className="w-3 h-3" />}
      <span className="text-[9px] font-black uppercase tracking-tighter">{label}</span>
    </div>
  );
}
