import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { PINVerification } from '@/components/auth/PINVerification';
import { PINSetup } from '@/components/auth/PINSetup';
import { useNavigate } from 'react-router-dom';

export default function StudentVerifyPIN() {
  const { profile, isPinVerified, refreshProfile, signOut, shouldRequireOTP } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(false);

  if (!profile) return null;

  const onSuccess = async () => {
    setLoading(true);
    try {
      await refreshProfile();
      // RouteGuard will handle redirection based on updated state
    } finally {
      setLoading(false);
    }
  };

  const onCancel = async () => {
    await signOut();
  };

  if (profile.pin_setup_required || !profile.pin) {
    return <PINSetup onSuccess={onSuccess} onCancel={onCancel} />;
  }

  if (!isPinVerified) {
    return <PINVerification onSuccess={onSuccess} onCancel={onCancel} />;
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen space-y-4">
      <div className="text-xl font-bold">PIN already verified.</div>
      <button onClick={() => navigate('/student')} className="text-primary underline">Go to Dashboard</button>
    </div>
  );
}
