import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { supabase } from '@/db/supabase';
import { useNavigate } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { BookOpen, User, Lock, Eye, EyeOff, Calendar, Trophy, Bell } from 'lucide-react';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { AuthBrandPanel } from '@/components/auth/AuthBrandPanel';
import { AuthFormShell } from '@/components/auth/AuthFormShell';

const formSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

export default function StudentLogin() {
  const { signInWithUsername, signOut, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isSecondaryLoginEnabled, setIsSecondaryLoginEnabled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    const clearState = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) signOut();
    };
    clearState();
    api.isGlobalModuleEnabled('secondary_login_id').then(setIsSecondaryLoginEnabled);
  }, []);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    // Format validation (Allow email or RSBS ID)
    const isEmail = values.username.includes('@');
    if (isEmail && !isSecondaryLoginEnabled) {
      toast.error('Email login is currently disabled. Please use your Student ID.');
      return;
    }
    
    if (!isEmail && !/^RSBS\d+$/.test(values.username)) {
      toast.error('Invalid Student ID format (must be RSBS + Digits)');
      return;
    }

    setLoading(true);
    try {
      const { error } = await signInWithUsername(values.username, values.password);
      if (error) {
        toast.error('Invalid Login ID or Password');
      } else {
        toast.success('Successfully logged in');
        
        // 1. Refresh profile to get current auth state
        await refreshProfile();
        // Redirection is now handled centrally by RouteGuard
      }
    } catch (err) {
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      panel={
        <AuthBrandPanel
          gradientClass="bg-gradient-to-br from-[hsl(158,60%,22%)] via-[hsl(160,55%,32%)] to-[hsl(165,50%,44%)]"
          icon={<BookOpen />}
          title="Student Portal"
          tagline="Access your grades, timetable, notices, and everything you need for school."
          features={[
            { icon: <Calendar />, text: 'Live timetable & attendance' },
            { icon: <Trophy />, text: 'Exam results & reports' },
            { icon: <Bell />, text: 'Instant school notices' },
          ]}
        />
      }
    >
      <AuthFormShell
        icon={<BookOpen />}
        heading="Student Sign In"
        subheading="Enter your school-provided Student ID and password to continue."
        footer={
          <p className="text-center text-[11px] font-medium text-muted-foreground">
            No account? Contact school administration to get your Student ID.
          </p>
        }
      >
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    {isSecondaryLoginEnabled ? 'Student ID or Email' : 'Student ID'}
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <Input
                        placeholder={isSecondaryLoginEnabled ? 'RSBS1001 or email@school.edu' : 'RSBS + your number'}
                        className="pl-10 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                        autoComplete="username"
                        {...field}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    Password
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••••"
                        className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                        autoComplete="current-password"
                        {...field}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(v => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98] mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                  Verifying…
                </span>
              ) : (
                'Sign In to Student Portal'
              )}
            </Button>
          </form>
        </Form>
      </AuthFormShell>
    </AuthLayout>
  );
}
