import React, { useState, useEffect } from 'react';
import { useApiConfigs } from '@/hooks/useApiConfigs';
import { ApiConfig } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import type { AiChatSession, AiChatMessage } from '@/types';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Sparkles, AlertCircle, ShieldAlert, Lock, Plus, MessageSquare, Trash2, Edit2, Check, X, Copy, Share2 } from 'lucide-react';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';

const StudyAI: React.FC = () => {
  const { profile } = useAuth();
  const { getModuleConfig, isLoaded: apiLoaded } = useApiConfigs();
  const activeConfig = getModuleConfig('study-ai');
  const [sessions, setSessions] = useState<AiChatSession[]>([]);
  const [activeSession, setActiveSession] = useState<AiChatSession | null>(null);
  const [messages, setMessages] = useState<AiChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [aiConfig, setAiConfig] = useState<any>(null);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  useEffect(() => {
    if (profile?.student_id && profile?.role === 'student') {
      fetchAiConfig();
      fetchSessions();
    } else {
      setIsDataLoaded(true);
    }
  }, [profile]);

  useEffect(() => {
    if (activeSession) {
      fetchMessages(activeSession.id);
    }
  }, [activeSession]);

  const fetchAiConfig = async () => {
    if (!profile?.student_id) return;
    
    const { data: student } = await api.getStudentById(profile.student_id);
    if (!student?.class_id) {
      setIsDataLoaded(true);
      return;
    }

    const config = await api.getAiConfigForStudent(profile.student_id, student.class_id);
    setAiConfig(config);
    setIsDataLoaded(true);
  };

  const fetchSessions = async () => {
    if (!profile?.student_id) return;
    const { data, error } = await api.getAiChatSessions(profile.student_id);
    if (error) {
      toast.error('Failed to load chat sessions');
      return;
    }
    setSessions(data || []);
    
    // Auto-select first session if none selected
    if (!activeSession && data && data.length > 0) {
      setActiveSession(data[0]);
    }
  };

  const fetchMessages = async (sessionId: string) => {
    const { data, error } = await api.getAiChatMessages(sessionId);
    if (error) {
      toast.error('Failed to load messages');
      return;
    }
    setMessages(data || []);
  };

  const handleCreateSession = async () => {
    if (!profile?.student_id) return;
    const { data, error } = await api.createAiChatSession(profile.student_id, `Chat ${sessions.length + 1}`);
    if (error) {
      toast.error('Failed to create chat');
      return;
    }
    toast.success('New chat created');
    fetchSessions();
    if (data) setActiveSession(data);
  };

  const handleDeleteSession = async (id: string) => {
    const { error } = await api.deleteAiChatSession(id);
    if (error) {
      toast.error('Failed to delete chat');
      return;
    }
    toast.success('Chat deleted');
    fetchSessions();
    if (activeSession?.id === id) {
      setActiveSession(null);
      setMessages([]);
    }
  };

  const handleRenameSession = async (id: string, newTitle: string) => {
    const { error } = await api.updateAiChatSession(id, { title: newTitle });
    if (error) {
      toast.error('Failed to rename chat');
      return;
    }
    toast.success('Chat renamed');
    fetchSessions();
    setEditingSessionId(null);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied successfully');
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          text: text,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback: Copy to clipboard if sharing is not supported
      handleCopy(text);
      toast.info('Sharing not supported, text copied to clipboard instead');
    }
  };

  const getNestedValue = (obj: any, path: string) => {
    return path.split(/[.[\]]/).filter(Boolean).reduce((acc, part) => acc?.[part], obj);
  };

  const substituteVariables = (text: string) => {
    let result = text;
    (activeConfig?.variables || []).forEach(v => {
      if (v.key && v.value) {
        const regex = new RegExp(`{{${v.key}}}`, 'g');
        result = result.replace(regex, v.value);
      }
    });
    return result;
  };

  const checkAccess = () => {
    if (!aiConfig) return { allowed: true };
    const { globalSettings, studentConfig, classConfig, usage } = aiConfig;

    if (!globalSettings?.is_system_enabled) {
      return { allowed: false, message: globalSettings?.system_unavailable_message, type: 'unavailable' };
    }

    if (studentConfig?.is_enabled === false) {
      return { allowed: false, message: globalSettings?.individual_disabled_message, type: 'disabled' };
    }

    if (classConfig?.is_enabled === false) {
      return { allowed: false, message: globalSettings?.class_disabled_message, type: 'disabled' };
    }

    const limit = studentConfig?.daily_limit || classConfig?.daily_limit || globalSettings?.global_daily_limit || 50;
    const used = usage?.message_count || 0;

    if (used >= limit) {
      return { 
        allowed: false, 
        message: `${globalSettings?.limit_reached_message}\n\n${globalSettings?.reset_info_message}`, 
        type: 'limit' 
      };
    }

    return { allowed: true };
  };

  const handleSend = async () => {
    const access = checkAccess();
    if (!access.allowed) {
      toast.error(access.message || 'Access Denied');
      return;
    }

    if (!activeConfig || !activeSession) {
      toast.error('Please select or create a chat session first.');
      return;
    }

    if (!inputValue.trim()) return;

    setIsLoading(true);

    // Fetch latest AI settings and student config to ensure real-time enforcement
    let currentAiConfig = aiConfig;
    if (profile?.student_id) {
      const studentRecord = await api.getStudentById(profile.student_id);
      if (studentRecord.data?.class_id) {
        currentAiConfig = await api.getAiConfigForStudent(profile.student_id, studentRecord.data.class_id);
        setAiConfig(currentAiConfig);
      }
    }

    // 1. Fetch current student record and related data based on permissions
    let studentData: any = {};
    let contextualInfo = "";

    if (profile?.student_id) {
      const { data: student } = await api.getStudentById(profile.student_id);
      if (student) {
        // Basic allowed data (not explicitly prohibited)
        studentData.name = student.name;
        studentData.class = student.class;
        studentData.section = student.section;
        studentData.student_type = student.student_type;
        studentData.gender = student.gender;
        studentData.status = student.status;

        const perms = currentAiConfig?.globalSettings;

        // Conditional Data points
        if (perms?.access_grades_enabled) {
          studentData.rank_in_class = student.rank;
          studentData.promotion_date = student.promotion_date;
          studentData.academic_session = student.session_info;
        }

        if (perms?.access_fees_enabled) {
          studentData.fee_details = student.fee_details;
          studentData.fee_status = student.fee_status;
        }

        if (perms?.access_attendance_enabled) {
          const { data: attendance } = await api.getAttendance(profile.student_id);
          studentData.attendance_history = attendance;
        }

        if (perms?.access_exams_enabled) {
          const { data: exams } = await api.getExams();
          studentData.upcoming_exams = exams;
        }

        contextualInfo = `
CURRENT STUDENT CONTEXT (CONFIDENTIAL):
${JSON.stringify(studentData, null, 2)}

DATA ACCESS PERMISSIONS:
- Grades & Performance: ${perms?.access_grades_enabled ? 'ENABLED' : 'DISABLED'}
- Attendance Records: ${perms?.access_attendance_enabled ? 'ENABLED' : 'DISABLED'}
- Exam Schedule: ${perms?.access_exams_enabled ? 'ENABLED' : 'DISABLED'}
- Fee Status: ${perms?.access_fees_enabled ? 'ENABLED' : 'DISABLED'}

IMPORTANT INSTRUCTIONS:
1. You are a strictly regulated policy follower.
2. If the student asks about a data point that is marked as DISABLED above or if the information is not present in the CURRENT STUDENT CONTEXT, you MUST respond exactly with: "Is jankari ko dekhne ki anumati nahi hai."
3. Do not infer, guess, or fabricate any data.
4. If a permission is DISABLED, you must refuse even if you think you know the answer from context.
5. NEVER disclose sensitive data like DOB, Phone numbers, Login IDs, or Parent details.
`;
      }
    }

    // Save user message
    const userMsg: Omit<AiChatMessage, 'id' | 'created_at'> = {
      session_id: activeSession.id,
      role: 'user',
      content: inputValue,
      attachments: []
    };

    const { data: savedUserMsg, error: userError } = await api.addAiChatMessage(userMsg);
    if (userError) {
      toast.error('Failed to save message');
      setIsLoading(false);
      return;
    }

    setMessages(prev => [...prev, savedUserMsg!]);
    setInputValue('');

    try {
      // Increment usage
      if (profile?.student_id) {
        await api.incrementAiUsage(profile.student_id);
        fetchAiConfig();
      }

      let selectedBody = activeConfig.bodies.find(b => b.is_default) || activeConfig.bodies[0];
      const baseBodyString = JSON.stringify(selectedBody.content);
      
      // Prepare context: recent messages + current input
      // Requirement 6: AI context strictly confined to available messages
      const history = messages.map(m => ({ role: m.role, content: m.content }));
      
      const systemMessage = {
        role: 'system',
        content: `You are the Study AI Assistant for RSBS School.
${contextualInfo}
Operational Mandate: Strictly follow the data access policies above.
`
      };

      const contextWithCurrent = [systemMessage, ...history, { role: 'user', content: inputValue }];
      
      const escapedInput = JSON.stringify(inputValue).slice(1, -1);
      const jsonMessages = JSON.stringify(contextWithCurrent);
      
      let substitutedBodyString = baseBodyString
        .replace(/{{user_input}}/g, () => escapedInput)
        .replace(/{{messages}}/g, () => jsonMessages);

      let finalBody: any;
      try {
        finalBody = JSON.parse(substitutedBodyString);
      } catch (e) {
        throw new Error('Request preparation failed.');
      }

      const substitutedEndpoint = substituteVariables(activeConfig.endpoint);
      const headersObj = activeConfig.headers.reduce((acc: any, h) => {
        if (h.key) acc[h.key] = substituteVariables(h.value);
        return acc;
      }, {});

      if (activeConfig.apiKey && activeConfig.auth_type !== 'none') {
        if (activeConfig.auth_type === 'bearer') {
          headersObj['Authorization'] = `Bearer ${activeConfig.apiKey}`;
        } else if (activeConfig.auth_type === 'api_key') {
          headersObj['X-API-Key'] = activeConfig.apiKey;
        }
      }

      const response = await fetch(substitutedEndpoint, {
        method: activeConfig.method,
        headers: headersObj,
        body: activeConfig.method !== 'GET' ? JSON.stringify(finalBody) : undefined,
      });

      if (!response.ok) {
        throw new Error(`Connection Error: ${response.status}`);
      }

      const data = await response.json();
      const parsedResponse = getNestedValue(data, activeConfig.responseField);

      const assistantContent = typeof parsedResponse === 'string' ? parsedResponse : JSON.stringify(data, null, 2);

      const assistantMsg: Omit<AiChatMessage, 'id' | 'created_at'> = {
        session_id: activeSession.id,
        role: 'assistant',
        content: assistantContent,
        attachments: []
      };

      const { data: savedAssistantMsg, error: assistantError } = await api.addAiChatMessage(assistantMsg);
      if (assistantError) {
        toast.error('Failed to save AI response');
      } else {
        setMessages(prev => [...prev, savedAssistantMsg!]);
      }
    } catch (error: any) {
      toast.error('Study Assistant is having trouble responding. Please try again later.');
      console.error('Study AI Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!apiLoaded || !isDataLoaded) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  const access = checkAccess();

  const ChatSidebar = () => (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="p-4 border-b flex justify-between items-center">
        <h2 className="font-bold text-sm uppercase tracking-widest">Chats</h2>
        <Button size="sm" variant="ghost" onClick={handleCreateSession} className="h-7 w-7 p-0">
          <Plus className="w-4 h-4" />
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {sessions.map(session => (
            <div 
              key={session.id} 
              className={cn(
                "group flex items-center justify-between p-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors",
                activeSession?.id === session.id && "bg-primary/10 border border-primary/20"
              )}
              onClick={() => setActiveSession(session)}
            >
              {editingSessionId === session.id ? (
                <div className="flex items-center gap-1 flex-1">
                  <Input 
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    className="h-6 text-xs"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleRenameSession(session.id, editingTitle);
                      if (e.key === 'Escape') setEditingSessionId(null);
                    }}
                  />
                  <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => handleRenameSession(session.id, editingTitle)}>
                    <Check className="w-3 h-3" />
                  </Button>
                  <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => setEditingSessionId(null)}>
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <MessageSquare className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    <span className="text-xs font-medium truncate">{session.title}</span>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 md:opacity-0 transition-opacity">
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-6 w-6 p-0" 
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingSessionId(session.id);
                        setEditingTitle(session.title);
                      }}
                    >
                      <Edit2 className="w-3 h-3" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-6 w-6 p-0 text-destructive" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteSession(session.id);
                      }}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-140px)] md:h-[calc(100vh-100px)] overflow-hidden max-w-7xl mx-auto px-4 gap-4">
      {/* Sidebar: Desktop */}
      <Card className="hidden md:flex w-64 flex-shrink-0 flex-col border-muted-foreground/20 overflow-hidden">
        <ChatSidebar />
      </Card>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-none pt-4 pb-2 border-b mb-4 flex justify-between items-end">
          <div className="flex items-center gap-2">
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="sm" className="h-9 w-9 p-0">
                    <Menu className="w-5 h-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-72 p-0">
                  <SheetHeader className="p-4 border-b">
                    <SheetTitle>Chat History</SheetTitle>
                  </SheetHeader>
                  <ChatSidebar />
                </SheetContent>
              </Sheet>
            </div>
            <div className="bg-primary/10 p-2 rounded-lg">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight truncate max-w-[150px] md:max-w-none">{activeSession?.title || 'Study AI'}</h1>
              <p className="text-xs text-muted-foreground">Your academic assistant</p>
            </div>
          </div>
          
          {aiConfig?.usage && profile?.role === 'student' && (
            <div className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground bg-muted px-2 py-1 rounded">
              Used: {aiConfig.usage.message_count}/{aiConfig.studentConfig?.daily_limit || aiConfig.classConfig?.daily_limit || aiConfig.globalSettings?.global_daily_limit || 50}
            </div>
          )}
        </div>

        <div className="flex-1 overflow-hidden relative flex flex-col mb-4">
          {!access.allowed ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center animate-in fade-in zoom-in duration-300">
              <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mb-6 ring-8 ring-destructive/5">
                {access.type === 'limit' ? <ShieldAlert className="w-10 h-10 text-destructive" /> : 
                 access.type === 'unavailable' ? <AlertCircle className="w-10 h-10 text-destructive" /> :
                 <Lock className="w-10 h-10 text-destructive" />}
              </div>
              <h2 className="text-2xl font-bold mb-4 tracking-tight">Access Restricted</h2>
              <div className="max-w-md bg-destructive/5 border border-destructive/10 p-6 rounded-2xl">
                <p className="text-muted-foreground whitespace-pre-wrap leading-relaxed">{access.message}</p>
              </div>
            </div>
          ) : !activeSession ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
              <MessageSquare className="w-16 h-16 text-muted-foreground/30 mb-4" />
              <h2 className="text-xl font-bold mb-2">No Chat Selected</h2>
              <p className="text-muted-foreground mb-4">Create a new chat or select an existing one to start.</p>
              <Button onClick={handleCreateSession}>
                <Plus className="w-4 h-4 mr-2" /> New Chat
              </Button>
            </div>
          ) : (
            <ScrollArea className="flex-1 px-4">
              <div className="space-y-4 py-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={cn(
                    "flex flex-col gap-1",
                    msg.role === 'user' ? 'items-end' : 'items-start'
                  )}>
                    <div className={cn(
                      "max-w-[80%] rounded-2xl px-4 py-3 shadow-sm",
                      msg.role === 'user' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted border border-muted-foreground/10'
                    )}>
                      <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
                    </div>
                    {msg.role === 'assistant' && (
                      <div className="flex gap-2 ml-1">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 p-2 text-muted-foreground hover:text-primary transition-colors" 
                          onClick={() => handleCopy(msg.content)}
                        >
                          <Copy className="w-4 h-4 mr-1" />
                          <span className="text-[10px]">Copy</span>
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 p-2 text-muted-foreground hover:text-primary transition-colors" 
                          onClick={() => handleShare(msg.content)}
                        >
                          <Share2 className="w-4 h-4 mr-1" />
                          <span className="text-[10px]">Share</span>
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="bg-muted border border-muted-foreground/10 rounded-2xl px-4 py-3">
                      <Loader2 className="w-4 h-4 animate-spin" />
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </div>

        <div className="flex-none pb-4">
          <Card className="bg-background/80 backdrop-blur shadow-lg border-muted-foreground/10 overflow-hidden rounded-2xl ring-1 ring-black/5 dark:ring-white/5">
            <div className="flex gap-2 p-3">
              <Input 
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Ask me anything..."
                disabled={isLoading || !activeConfig || !access.allowed || !activeSession}
                className="flex-1"
              />
              <Button onClick={handleSend} disabled={isLoading || !activeConfig || !access.allowed || !activeSession}>
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send'}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default StudyAI;
