import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Student } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CreditCard, CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function StudentFees() {
  const { profile } = useAuth();
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudent = async () => {
      if (!profile?.student_id) return;
      setLoading(true);
      const { data } = await api.getStudents();
      const studentData = data.find(s => s.id === profile.student_id);
      setStudent(studentData || null);
      setLoading(false);
    };
    fetchStudent();
  }, [profile]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'pending': return <Clock className="w-5 h-5 text-orange-600" />;
      case 'overdue': return <AlertCircle className="w-5 h-5 text-red-600" />;
      default: return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { bg: string; text: string }> = {
      paid: { bg: 'bg-green-100', text: 'text-green-700' },
      pending: { bg: 'bg-orange-100', text: 'text-orange-700' },
      overdue: { bg: 'bg-red-100', text: 'text-red-700' },
    };
    const variant = variants[status] || { bg: 'bg-gray-100', text: 'text-gray-700' };
    return (
      <Badge className={`${variant.bg} ${variant.text} border-0`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-40 w-full bg-muted" />
        <Skeleton className="h-60 w-full bg-muted" />
      </div>
    );
  }

  if (!student) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-12 text-center text-muted-foreground">
          Student data not found.
        </CardContent>
      </Card>
    );
  }

  const totalAmount = student.fee_details.reduce((sum, fee) => sum + fee.amount, 0);

  return (
    <div className="space-y-6 pb-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
          <CreditCard className="w-7 h-7 md:w-8 md:h-8 text-primary" />
          My Fees
        </h1>
        <p className="text-muted-foreground text-sm md:text-base">View your fee details and payment status.</p>
      </div>

      {/* Fee Status Summary */}
      <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Fee Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs md:text-sm text-muted-foreground mb-1">Overall Status</p>
              <div className="flex items-center gap-2">
                {getStatusIcon(student.fee_status)}
                {getStatusBadge(student.fee_status)}
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs md:text-sm text-muted-foreground mb-1">Total Amount</p>
              <p className="text-2xl md:text-3xl font-bold text-primary">₹{totalAmount.toLocaleString('en-IN')}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fee Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg md:text-xl">Fee Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          {student.fee_details.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No fee details available.</p>
          ) : (
            <div className="space-y-3">
              {student.fee_details.map((fee, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 md:p-4 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <div className="space-y-1">
                    <p className="font-medium text-sm md:text-base">{fee.description}</p>
                    {fee.due_date && (
                      <p className="text-xs text-muted-foreground">
                        Due: {new Date(fee.due_date).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <p className="text-lg md:text-xl font-bold text-primary">₹{fee.amount.toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
