import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useParent } from '@/contexts/ParentContext';
import { api } from '@/db/api';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, CreditCard, CheckCircle2, AlertCircle, Clock, Info } from 'lucide-react';
import { StudentSwitcher } from '@/components/parent/StudentSwitcher';

const ParentFees: React.FC = () => {
  const { profile } = useAuth();
  const { selectedStudent, loading: parentLoading } = useParent();
  const [loadingDetails, setLoadingDetails] = useState(false);

  useEffect(() => {
    // We could fetch fee history if available
  }, [selectedStudent, profile?.id]);

  if (parentLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary/30" />
        <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Updating fee status...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <StudentSwitcher />

      <div className="space-y-2 text-center md:text-left">
        <h2 className="text-3xl font-black text-slate-900 leading-tight">School Fees</h2>
        <p className="text-slate-500 font-medium">Monitoring payment status for {selectedStudent?.student_name}.</p>
      </div>

      {/* Main Status Card */}
      <div className={`p-10 rounded-[3rem] border-4 text-center space-y-6 shadow-2xl transition-all ${
        selectedStudent?.fee_status === 'Paid' 
        ? 'bg-green-50 border-green-100 shadow-green-200/20' 
        : 'bg-amber-50 border-amber-100 shadow-amber-200/20'
      }`}>
        <div className={`w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto shadow-lg ${
          selectedStudent?.fee_status === 'Paid' ? 'bg-green-500 text-white shadow-green-500/30' : 'bg-amber-500 text-white shadow-amber-500/30'
        }`}>
          {selectedStudent?.fee_status === 'Paid' ? <CheckCircle2 className="h-10 w-10" /> : <AlertCircle className="h-10 w-10" />}
        </div>
        <div className="space-y-2">
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">Current Billing Cycle</p>
          <h4 className="text-4xl font-black text-slate-900 leading-none">
            {selectedStudent?.fee_status === 'Paid' ? 'Fully Paid' : 'Pending Dues'}
          </h4>
          <p className="text-slate-500 font-medium max-w-sm mx-auto leading-relaxed">
            {selectedStudent?.fee_status === 'Paid' 
              ? 'All school fees are fully settled for the current session. Thank you for your cooperation!' 
              : 'There are pending dues associated with this student profile. Please settle them at the school office to avoid late fees.'}
          </p>
        </div>
      </div>

      {/* Summary Section */}
      <div className="space-y-4">
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest px-4 text-center md:text-left">Financial Details</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 px-2">
          <div className="bg-white p-6 rounded-3xl border shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <CreditCard className="h-5 w-5 text-primary" />
              </div>
              <p className="text-sm font-black text-slate-900 uppercase tracking-tight">Fee Category</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Student Type</span>
              <span className="text-sm font-black text-slate-900">{selectedStudent?.student_type || 'Regular'}</span>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl border flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Class Level</span>
              <span className="text-sm font-black text-slate-900">{selectedStudent?.student_class}</span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border shadow-sm space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-50 rounded-xl">
                <Clock className="h-5 w-5 text-amber-500" />
              </div>
              <p className="text-sm font-black text-slate-900 uppercase tracking-tight">Payment Portal</p>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
              We are currently in the process of integrating an online payment gateway. 
            </p>
            <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100/50 flex items-start gap-3">
              <Info className="h-4 w-4 text-amber-500 mt-0.5 shrink-0" />
              <p className="text-[10px] text-amber-600 font-bold leading-relaxed uppercase tracking-wider">
                All transactions must currently be completed in-person at the School Accounts Department.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 text-center bg-white rounded-[2.5rem] border border-dashed flex flex-col items-center gap-4">
        <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
          <CheckCircle2 className="h-8 w-8 text-slate-300" />
        </div>
        <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Payment history history coming soon</p>
      </div>
    </div>
  );
};

export default ParentFees;
