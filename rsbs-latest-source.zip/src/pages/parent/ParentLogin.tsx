import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/db/api';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Users, User, Lock, Eye, EyeOff, CreditCard, Bell, BarChart2 } from 'lucide-react';
import { AuthLayout } from '@/components/auth/AuthLayout';
import { AuthBrandPanel } from '@/components/auth/AuthBrandPanel';
import { AuthFormShell } from '@/components/auth/AuthFormShell';

const ParentLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSecondaryLoginEnabled, setIsSecondaryLoginEnabled] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { signInWithUsername } = useAuth();

  useEffect(() => {
    api.isGlobalModuleEnabled('secondary_login_id').then(setIsSecondaryLoginEnabled);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Please enter both your Parent ID and password.');
      return;
    }

    const isEmail = username.includes('@');

    if (isEmail && !isSecondaryLoginEnabled) {
      toast.error('Email login is currently disabled. Please use your Parent ID.');
      return;
    }
    if (!isEmail && !username.startsWith('RSBSP')) {
      toast.error('Invalid Parent ID. It must start with RSBSP.');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await signInWithUsername(username, password);
      if (!error) {
        toast.success('Welcome to the Parent Portal.');
      } else {
        toast.error(error.message || 'Invalid credentials. Please try again.');
      }
    } catch {
      toast.error('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthLayout
      panel={
        <AuthBrandPanel
          gradientClass="bg-gradient-to-br from-[hsl(24,70%,28%)] via-[hsl(26,65%,38%)] to-[hsl(30,60%,52%)]"
          icon={<Users />}
          title="Parent Portal"
          tagline="Stay connected with your child's academic journey — fees, attendance, results, and more."
          features={[
            { icon: <BarChart2 />, text: 'Live attendance & progress' },
            { icon: <CreditCard />, text: 'Fee payments & statements' },
            { icon: <Bell />, text: 'School notices in real time' },
          ]}
        />
      }
    >
      <AuthFormShell
        icon={<Users />}
        heading="Parent Sign In"
        subheading="Enter your Parent ID and password to access your child's information."
        footer={
          <p className="text-center text-[11px] font-medium text-muted-foreground">
            Your Parent ID begins with <span className="font-bold text-foreground">RSBSP</span>.
            <br />Need access? Contact school administration.
          </p>
        }
      >
        <form onSubmit={handleLogin} className="space-y-4">
          {/* Parent ID */}
          <div className="space-y-1.5">
            <label
              htmlFor="parent-username"
              className="text-xs font-semibold uppercase tracking-widest text-muted-foreground"
            >
              {isSecondaryLoginEnabled ? 'Parent ID or Email' : 'Parent ID'}
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                id="parent-username"
                placeholder={isSecondaryLoginEnabled ? 'RSBSP1001 or parent@email.com' : 'RSBSP + your number'}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="pl-10 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                autoComplete="username"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <label
              htmlFor="parent-password"
              className="text-xs font-semibold uppercase tracking-widest text-muted-foreground"
            >
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                id="parent-password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-11 h-12 bg-muted/40 border-border focus-visible:ring-primary rounded-xl text-sm"
                autoComplete="current-password"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(v => !v)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 rounded-xl font-bold text-base shadow-lg shadow-primary/20 transition-all duration-200 active:scale-[0.98] mt-2"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" />
                Signing in…
              </span>
            ) : (
              'Sign In to Parent Portal'
            )}
          </Button>
        </form>
      </AuthFormShell>
    </AuthLayout>
  );
};

export default ParentLogin;
